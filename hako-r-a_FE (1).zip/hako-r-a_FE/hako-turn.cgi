#----------------------------------------------------------------------
# Ȣ������ ver2.30
# ������ʹԥ⥸�塼��(ver1.02)
# ���Ѿ�������ˡ���ϡ�hako-readme.txt�ե�����򻲾�
#
# Ȣ������Υڡ���: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. Final Edition
# �ᥤ�󥹥���ץ�(Ȣ������ ver2.30)
# ���Ѿ�������ˡ���ϡ�read-renas.txt�ե�����򻲾�
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------

#����2�إå����κ�ɸ
my(@ax) = (0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
my(@ay) = (0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

#----------------------------------------------------------------------
# ��ο��������⡼��
#----------------------------------------------------------------------
# �ᥤ��
sub newIslandMain {
    # �礬���äѤ��Ǥʤ��������å�
    if($HislandNumber >= $HmaxIsland) {
	unlock();
	tempNewIslandFull();
	return;
    }

    # ̾�������뤫�����å�
    if($HcurrentName eq '') {
	unlock();
	tempNewIslandNoName();
	return;
    }

    # ̾�������뤫�����å�
    if($HcurrentOwnerName eq '') {
	unlock();
	tempNewIslandNoName();
	return;
    }

    # ̾�������뤫�����å�
    if($Hmessage eq '') {
	unlock();
	tempNewIslandNoName();
	return;
    }

    # ̾���������������å�
    if($HcurrentName =~ /[,\?\(\)\<\>\$]|^̵��$/) {
	# �Ȥ��ʤ�̾��
	unlock();
	tempNewIslandBadName();
	return;
    }

    # ̾���ν�ʣ�����å�
    if(nameToNumber($HcurrentName) != -1) {
	# ���Ǥ�ȯ������
	unlock();
	tempNewIslandAlready();
	return;
    }

    # password��¸��Ƚ��
    if($HinputPassword eq '') {
	# password̵��
	unlock();
	tempNewIslandNoPassword();
	return;
    }

    # ��ǧ�ѥѥ����
    if($HinputPassword2 ne $HinputPassword) {
	# password�ְ㤤
	unlock();
	tempWrongPassword();
	return;
    }

	# IP���å�
	$speaker = $ENV{'REMOTE_HOST'};
	$speaker = $ENV{'REMOTE_ADDR'} if ($speaker eq '');

    # IP�ν�ʣ�����å�
    if($IPcut == 1) {
    if(ipToNumber($speaker) != -1) {
	# ���Ǥ�ȯ������
	unlock();
	tempIPIslandAlready();
	return;
    }
    }

    # ����������ֹ�����
    $HcurrentNumber = $HislandNumber;
    $HislandNumber++;
    $Hislands[$HcurrentNumber] = makeNewIsland();
    my($island) = $Hislands[$HcurrentNumber];

    # �Ƽ���ͤ�����
    $island->{'name'} = $HcurrentName;
    $island->{'id'} = $HislandNextID;
    $HislandNextID ++;
    $island->{'absent'} = $HgiveupTurn - 3;
    $island->{'comment'} = htmlEscape($Hmessage);
    $island->{'password'} = encode($HinputPassword);
    $island->{'eisei1'} = 0;
    $island->{'eisei2'} = 0;
    $island->{'eisei3'} = '0,0,0,0,0';
    $island->{'eisei4'} = '0,0,0,0,0,0,0,0,0,0,0';
    $island->{'eisei5'} = '0,0,0,0,0,0,0';
    $island->{'eisei6'} = '0,0,0,0,0,0,0,0,0,0,0,0';
    $island->{'eis1'} = 0;
    $island->{'eis2'} = 0;
    $island->{'eis3'} = 0;
    $island->{'eis4'} = 0;
    $island->{'eis5'} = 0;
    $island->{'eis6'} = 0;
    $island->{'eis7'} = 0;
    $island->{'eis8'} = '(̤��Ͽ)';
    $island->{'taiji'} = 0;
    $island->{'onm'} = htmlEscape($HcurrentOwnerName);
    $island->{'ownername'} = htmlEscape($HcurrentOwnerName);
    $island->{'id1'} = $HislandNextID;
    $island->{'totoyoso'} = '(̤��Ͽ)';
    $island->{'totoyoso2'}= 555;
    $island->{'kei'} = 0;
    $island->{'rena'} = 0;
    $island->{'momotan'} = 0;
    $island->{'fore'} = 0;
    $island->{'pika'} = 0;
    $island->{'hamu'} = 0;
    $island->{'monta'} = 0;
    $island->{'tare'} = 0;
    $island->{'zipro'} = 0;
    $island->{'leje'} = 0;

    $island->{'ipname'} = $HcurrentName;
    $island->{'ip0'} = "$speaker";
    $island->{'ip1'} = "$speaker";
    $island->{'ip2'} = "$speaker";
    $island->{'ip3'} = "$speaker";
    $island->{'ip4'} = "$speaker";
    $island->{'ip5'} = "$speaker";
    $island->{'ip6'} = 0;
    $island->{'ip7'} = 0;
    $island->{'ip8'} = 0;
    $island->{'ip9'} = 0;
    $island->{'etc0'} = 0;
    $island->{'etc1'} = 0;
    $island->{'etc2'} = 0;
    $island->{'etc3'} = 0;
    $island->{'etc4'} = 0;
    $island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
    $island->{'etc6'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
    $island->{'etc7'} = '0,0,0';
    $island->{'etc8'} = '0,0,0,0,0,0,0';
    $island->{'etc9'} = '0,0,0,0,0,0,0';
    $island->{'auc0'} = '0,0,0,0,0';
    $island->{'auc1'} = 0;
    $island->{'auc2'} = 0;
    $island->{'auc3'} = 0;
    $island->{'auc4'} = '0,0,0';
    $island->{'auc5'} = '0,0,0,0,0';
    $island->{'auc6'} = '0,0,0';
    $island->{'auc7'} = 0;
    $island->{'auc8'} = 0;
    $island->{'auc9'} = '0,0,0,0,0';

    if($anothermood == 1) {
	my($onm);
	$onm = $island->{'onm'};
	$island->{'totoyoso2'} = "$onm���ƥ���";
	$island->{'shu'}++;
	$island->{'eisei1'} = 7;
    }

	    if(random(100) < 50) {
	       $island->{'eis1'} = 200;
	    } else {
	       $island->{'eis2'} = 200;
	    }

    # �͸�����¾����
    estimate($HcurrentNumber);

    # �ǡ����񤭽Ф�
    writeIslandsFile($island->{'id'});
    logDiscover($HcurrentName); # ����

    # ����
    unlock();

    # ȯ������
    tempNewIslandHead($HcurrentName); # ȯ�����ޤ���!!
    islandInfo(); # ��ξ���
    islandMap(1); # ����Ͽޡ�owner�⡼��
}

# ����������������
sub makeNewIsland {
    # �Ϸ�����
    my($land, $landValue) = makeNewLand();

    # ������ޥ�ɤ�����
    my(@command, $i);
    for($i = 0; $i < $HcommandMax; $i++) {
	 $command[$i] = {
	     'kind' => $HcomDoNothing,
	     'target' => 0,
	     'x' => 0,
	     'y' => 0,
	     'arg' => 0
	 };
    }

    # ����Ǽ��Ĥ����
    my(@lbbs);
    for($i = 0; $i < $HlbbsMax; $i++) {
         $lbbs[$i] = "0<<0>>";
    }

    # ��ˤ����֤�
    return {
	'land' => $land,
	'landValue' => $landValue,
	'command' => \@command,
	'lbbs' => \@lbbs,
	'money' => $HinitialMoney,
	'food' => $HinitialFood,
	'prize' => '0,0,',
        'monsterlive' => 0,
        'monsterlivetype' => 0,
    };
}

# ����������Ϸ����������
sub makeNewLand {
    # ���ܷ������
    my(@land, @landValue, $x, $y, $i);

    # ���˽����
    for($y = 0; $y < $HislandSize; $y++) {
	 for($x = 0; $x < $HislandSize; $x++) {
	     $land[$x][$y] = $HlandSea;
	     $landValue[$x][$y] = 0;
	 }
    }

    # �����4*4�˹��Ϥ�����
    my($center) = $HislandSize / 2 - 1;
    for($y = $center - 1; $y < $center + 3; $y++) {
	 for($x = $center - 1; $x < $center + 3; $x++) {
	     $land[$x][$y] = $HlandWaste;
	 }
    }

    # 8*8�ϰ����Φ�Ϥ�����
    for($i = 0; $i < 120; $i++) {
	 # �������ɸ
	 $x = random(8) + $center - 3;
	 $y = random(8) + $center - 3;

	 my($tmp) = countAround(\@land, $x, $y, $HlandSea, 7);
	 if(countAround(\@land, $x, $y, $HlandSea, 7) != 7){
	     # �����Φ�Ϥ������硢�����ˤ���
	     # �����Ϲ��Ϥˤ���
	     # ���Ϥ�ʿ�Ϥˤ���
	     if($land[$x][$y] == $HlandWaste) {
		 $land[$x][$y] = $HlandPlains;
		 $landValue[$x][$y] = 0;
	     } else {
		 if($landValue[$x][$y] == 1) {
                     $land[$x][$y] = $HlandWaste;
                     $landValue[$x][$y] = 0;
		 } else {
		     $landValue[$x][$y] = 1;
		 }
	     }
	 }
    }

    # ������
    my($count) = 0;
    while($count < 4) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ���������Ǥ˿��Ǥʤ���С�������
	 if($land[$x][$y] != $HlandForest) {
	     $land[$x][$y] = $HlandForest;
	     $landValue[$x][$y] = 5; # �ǽ��500��
	     $count++;
	 }
    }

    # Į����
    $count = 0;
    while($count < 2) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�Ǥʤ���С�Į����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest)) {
	     $land[$x][$y] = $HlandTown;
	     $landValue[$x][$y] = 5; # �ǽ��500��
	     $count++;
	 }
    }

    # ������
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�Ǥʤ���С�Į����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest)) {
	     $land[$x][$y] = $HlandMountain;
	     $landValue[$x][$y] = 0; # �ǽ�Ϻη���ʤ�
	     $count++;
	 }
    }

    # ���Ϥ���
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�����Ǥʤ���С�����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest) &&
	    ($land[$x][$y] != $HlandMountain)) {
	     $land[$x][$y] = $HlandBase;
	     $landValue[$x][$y] = 0;
	     $count++;
	 }
    }

    # �˥塼���������
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�����Ǥʤ���С�����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest) &&
	    ($land[$x][$y] != $HlandBase) &&
	    ($land[$x][$y] != $HlandMountain)) {
	     $land[$x][$y] = $HlandNewtown;
	     $landValue[$x][$y] = 10;
	     $count++;
	 }
    }

    # ��ؤ���
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�����Ǥʤ���С�����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest) &&
	    ($land[$x][$y] != $HlandBase) &&
	    ($land[$x][$y] != $HlandNewtown) &&
	    ($land[$x][$y] != $HlandMountain)) {
	     $land[$x][$y] = $HlandCollege;
	     $landValue[$x][$y] = random(3);

	     $count++;
	 }
    }

    # ������
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	# �����Φ�����뤫�����å�
	my($seaCount) =
	    countAround($land, $x, $y, $HlandSea, 7);

        if($seaCount == 0) {

	 } else {
	 # ����������Į�����Ǥʤ���С�����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest) &&
	    ($land[$x][$y] != $HlandBase) &&
	    ($land[$x][$y] != $HlandNewtown) &&
	    ($land[$x][$y] != $HlandCollege) &&
	    ($land[$x][$y] != $HlandMountain)) {
	     $land[$x][$y] = $HlandMinato;
	     $landValue[$x][$y] = 5;
	     $count++;
	 }
	 }
    }

    # ȯ�Ž����
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�����Ǥʤ���С�����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest) &&
	    ($land[$x][$y] != $HlandBase) &&
	    ($land[$x][$y] != $HlandNewtown) &&
	    ($land[$x][$y] != $HlandCollege) &&
	    ($land[$x][$y] != $HlandMinato) &&
	    ($land[$x][$y] != $HlandMountain)) {
	     $land[$x][$y] = $HlandEneWd;
	     $landValue[$x][$y] = 50;
	     $count++;
	 }
    }

    # ȯ�Ž����
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�����Ǥʤ���С�����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest) &&
	    ($land[$x][$y] != $HlandBase) &&
	    ($land[$x][$y] != $HlandNewtown) &&
	    ($land[$x][$y] != $HlandCollege) &&
	    ($land[$x][$y] != $HlandMinato) &&
	    ($land[$x][$y] != $HlandEneWd) &&
	    ($land[$x][$y] != $HlandMountain)) {
	     $land[$x][$y] = $HlandConden;
	     $landValue[$x][$y] = 100;

		if(random(100) < 10) {
	     	$land[$x][$y] = $HlandConden3;
	     	$landValue[$x][$y] = 0;
		}

	     $count++;
	 }
    }

    if($anothermood == 1) {
    # ȯ�Ž����
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�����Ǥʤ���С�����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest) &&
	    ($land[$x][$y] != $HlandBase) &&
	    ($land[$x][$y] != $HlandNewtown) &&
	    ($land[$x][$y] != $HlandCollege) &&
	    ($land[$x][$y] != $HlandMinato) &&
	    ($land[$x][$y] != $HlandEneWd) &&
	    ($land[$x][$y] != $HlandConden) &&
	    ($land[$x][$y] != $HlandConden3) &&
	    ($land[$x][$y] != $HlandMountain)) {
	     $land[$x][$y] = $HlandShuto;
	     $landValue[$x][$y] = 50;
	     $count++;
	 }
    }
    # ȯ�Ž����
    $count = 0;
    while($count < 1) {
	 # �������ɸ
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # ����������Į�����Ǥʤ���С�����
	 if(($land[$x][$y] != $HlandTown) &&
	    ($land[$x][$y] != $HlandForest) &&
	    ($land[$x][$y] != $HlandBase) &&
	    ($land[$x][$y] != $HlandNewtown) &&
	    ($land[$x][$y] != $HlandCollege) &&
	    ($land[$x][$y] != $HlandMinato) &&
	    ($land[$x][$y] != $HlandEneWd) &&
	    ($land[$x][$y] != $HlandConden) &&
	    ($land[$x][$y] != $HlandConden3) &&
	    ($land[$x][$y] != $HlandShuto) &&
	    ($land[$x][$y] != $HlandMountain)) {
	     $land[$x][$y] = $HlandHouse;
	     $landValue[$x][$y] = 0;
	     $count++;
	 }
    }
    }


    return (\@land, \@landValue);
}

#----------------------------------------------------------------------
# �����ѹ��⡼��
#----------------------------------------------------------------------
# �ᥤ��
sub changeMain {
    # id����������
    $HcurrentNumber = $HidToNumber{$HcurrentID};
    my($island) = $Hislands[$HcurrentNumber];
    my($flag) = 0;

    # �ѥ���ɥ����å�
    if($HoldPassword eq $HspecialPassword) {
	# �ü�ѥ����
	$island->{'money'} = 999999;
	$island->{'food'} = 99999;
    } elsif($HoldPassword eq $HshutoPassword) {
	$island->{'totoyoso2'} = htmlEscape($HcurrentOwnerName);
	$flag = 1;
    } elsif($HoldPassword eq $HomamoriPassword) {
	    $etc8 = $island->{'etc8'};
	    $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
	    $toto2++;
	    $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	$flag = 1;
    } elsif($HoldPassword eq $HijiriPassword) {
	$sthenko = htmlEscape($HcurrentOwnerName);

	if($sthenko eq id) {
	    rename("${HdirName}/island.$island->{'id'}", "${HdirName}/island.$HcurrentName");
	}

	    $eisei5 = $island->{'eisei5'};
	    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);

	if($sthenko eq msexe) {
	    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$HcurrentName,$tetsub";
	} elsif($sthenko eq mshp) {
	    $island->{'eisei5'} = "$HcurrentName,$msap,$msdp,$mssp,$mswin,$msexe,$tetsub";
	} elsif($sthenko eq msap) {
	    $island->{'eisei5'} = "$mshp,$HcurrentName,$msdp,$mssp,$mswin,$msexe,$tetsub";
	} elsif($sthenko eq msdp) {
	    $island->{'eisei5'} = "$mshp,$msap,$HcurrentName,$mssp,$mswin,$msexe,$tetsub";
	} elsif($sthenko eq mssp) {
	    $island->{'eisei5'} = "$mshp,$msap,$msdp,$HcurrentName,$mswin,$msexe,$tetsub";
	} else {
	    $island->{"$sthenko"} = "$HcurrentName";
	}

	writeIslandsFile($HcurrentID);
	unlock();
	tempChange();
	return;
    } elsif($HoldPassword eq $HipPassword) {
	$island->{'ip0'} = 0;
	$island->{'ip1'} = 0;
	$island->{'ip2'} = 0;
	$island->{'ip3'} = 0;
	$island->{'ip4'} = 0;
	$island->{'ip5'} = 0;
	$island->{'ip6'} = 0;
	$island->{'ip7'} = 0;
	$island->{'ip8'} = 0;
	$island->{'ip9'} = 0;
	$flag = 1;
    } elsif(!checkPassword($island->{'password'},$HoldPassword)) {
	# password�ְ㤤
	unlock();
	tempWrongPassword();
	return;
    }

    # ��ǧ�ѥѥ����
    if($HinputPassword2 ne $HinputPassword) {
	# password�ְ㤤
	unlock();
	tempWrongPassword();
	return;
    }

    if($HcurrentName ne '') {
	# ̾���ѹ��ξ��	
	# ̾���������������å�
	if($HcurrentName =~ /[,\?\(\)\<\>]|^̵��$/) {
	    # �Ȥ��ʤ�̾��
	    unlock();
	    tempNewIslandBadName();
	    return;
	}

	# ̾���ν�ʣ�����å�
	if(nameToNumber($HcurrentName) != -1) {
	    # ���Ǥ�ȯ������
	    unlock();
	    tempNewIslandAlready();
	    return;
	}

	if($island->{'money'} < $HcostChangeName) {
	    # �⤬­��ʤ�
	    unlock();
	    tempChangeNoMoney();
	    return;
	}

	# ���
	if($HoldPassword ne $HspecialPassword) {
	    $island->{'money'} -= $HcostChangeName;
	}

	# ̾�����ѹ�
	logChangeName($island->{'name'}, $HcurrentName);
	$island->{'name'} = $HcurrentName;
	$flag = 1;
    }

    # password�ѹ��ξ��
    if($HinputPassword ne '') {
	# �ѥ���ɤ��ѹ�
	$island->{'password'} = encode($HinputPassword);
	$flag = 1;
    }

    if($HcurrentOwnerName ne '') {
	$island->{'onm'} = htmlEscape($HcurrentOwnerName);
	$flag = 1;
    }

    if(($flag == 0) && ($HoldPassword ne $HspecialPassword)) {
	# �ɤ�����ѹ�����Ƥ��ʤ�
	unlock();
	tempChangeNothing();
	return;
    }

    # �ǡ����񤭽Ф�
    writeIslandsFile($HcurrentID);
    unlock();

    # �ѹ�����
    tempChange();
}

sub changeOwner {
  # id����������
  $HcurrentNumber = $HidToNumber{$HcurrentID};
  my($island) = $Hislands[$HcurrentNumber];
  my($flag) = 0;

  if(!checkPassword($island->{'password'},$HoldPassword)) {
    # password�ְ㤤
    unlock();
    tempWrongPassword();
    return;
  }
  # �����ʡ�̾���ѹ�
  $island->{'ownername'} = htmlEscape($HcurrentOwnerName);
  $flag = 1;

  # �ǡ����񤭽Ф�
  writeIslandsOwner($HcurrentID);
  unlock();

  # �ѹ�����
  tempChange();
}

#----------------------------------------------------------------------
# ������ʹԥ⡼��
#----------------------------------------------------------------------
# �ᥤ��
sub turnMain {
    # �ǽ��������֤򹹿�
    $HislandLastTime += $HunitTime;

    # �����ե���������ˤ��餹
    my($i, $j, $s, $d);
    for($i = ($HlogMax - 1); $i >= 0; $i--) {
	$j = $i + 1;
	my($s) = "${HdirName}/hakojima.log$i";
	my($d) = "${HdirName}/hakojima.log$j";
	unlink($d);
	rename($s, $d);
    }

    # ��ɸ�������
    makeRandomPointArray();

    # �������ֹ�
    $HislandTurn++;

    # ���ַ��
    my(@order) = randomArray($HislandNumber);

    # ����������ե�����
    for($i = 0; $i < $HislandNumber; $i++) {

	estimate($order[$i]);
	income($Hislands[$order[$i]]);

	# �����󳫻����ο͸������
	$Hislands[$order[$i]]->{'oldPop'} = $Hislands[$order[$i]]->{'pop'};
	$Hislands[$order[$i]]->{'oldMoney'} = $Hislands[$order[$i]]->{'money'};
	$Hislands[$order[$i]]->{'oldPts'} = $Hislands[$order[$i]]->{'pts'};
    }

    $island->{'Typhoonflag'} = 0;

    # ���ޥ�ɽ���
    for($i = 0; $i < $HislandNumber; $i++) {
	# �����1�ˤʤ�ޤǷ����֤�
	while(doCommand($Hislands[$order[$i]]) == 0){};
    }

    # ��Ĺ�����ñ�إå����ҳ�
    for($i = 0; $i < $HislandNumber; $i++) {
	doEachHex($Hislands[$order[$i]]);
    }

    # �����ν���
    my($remainNumber) = $HislandNumber;
    my($island);
    for($i = 0; $i < $HislandNumber; $i++) {
	$island = $Hislands[$order[$i]];
	doIslandProcess($order[$i], $island); 

	doIslandunemployed($order[$i], $island); 

    }

    if(($HislandTurn % 100) == 41) {
	islandSortHC();

	for($i = 0; $i < 8; $i++) {
	$island = $Hislands[$i];
	$eisei4 = $island->{'eisei4'};
	$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);

	if($stshoka != 0) {

	$stshoka = 6;
	$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	$stsin .= "$island->{'name'}�硢";
	    }
	    }
	logHCsin($id, $name, $stsin);
    }

	islandSortPop();
            my($islandp) = $Hislands[0];
	islandSortFarm();
            my($islandfm) = $Hislands[0];
	islandSortFactory();
            my($islandfc) = $Hislands[0];
	islandSortMountain();
            my($islandm) = $Hislands[0];
	islandSortMonument();
            my($islandf) = $Hislands[0];
	islandSortLive();
            my($islandl) = $Hislands[0];
	islandSortRena();
            my($islandr) = $Hislands[0];
	islandSortKill();
            my($islandk) = $Hislands[0];
	islandSortFore();
            my($islandw) = $Hislands[0];
	islandSortTare();
            my($islandtare) = $Hislands[0];
	islandSortZipro();
            my($islandzipro) = $Hislands[0];
	islandSortLeje();
            my($islandleje) = $Hislands[0];
	islandSortForce();
            my($islandforce) = $Hislands[0];
	islandSortEisei2();
            my($islandeisei2) = $Hislands[0];
	islandSortUni();
            my($islanduni) = $Hislands[0];

	islandSorthck();
            my($islandhck) = $Hislands[0];
	islandSorthckt();
            my($islandhckt) = $Hislands[0];
	islandSorthcr();
            my($islandhcr) = $Hislands[0];
	islandSorthcy();
            my($islandhcy) = $Hislands[0];
	islandSorthct();
            my($islandhct) = $Hislands[0];

	    $islandp->{'bumon'} ++;
	    $islandfm->{'bumon'} ++;
	    $islandfc->{'bumon'} ++;
	    $islandm->{'bumon'} ++;
	    $islandf->{'bumon'} ++;
	    $islandl->{'bumon'} ++;
	    $islandr->{'bumon'} ++;
	    $islandk->{'bumon'} ++;
	    $islandw->{'bumon'} ++;
	    $islandtare->{'bumon'} ++;
	    $islandzipro->{'bumon'} ++;
	    $islandleje->{'bumon'} ++;
	    $islandforce->{'bumon'} ++;
	    $islandeisei2->{'bumon'} ++;
	    $islanduni->{'bumon'} ++;
	    $islandhck->{'bumon'} ++;
	    $islandhckt->{'bumon'} ++;
	    $islandhcr->{'bumon'} ++;
	    $islandhcy->{'bumon'} ++;
	    $islandhct->{'bumon'} ++;

    my($remainNumber) = $HislandNumber;
    my($island);
    for($i = 0; $i < $HislandNumber; $i++) {
	estimate($order[$i]);

	$island = $Hislands[$order[$i]];
	# ����Ƚ��
	if($island->{'dead'} == 1) {
	    $island->{'pop'} = 0;
	    $island->{'pts'} = 0;
	    $remainNumber--;
	} elsif($island->{'pop'} == 0) {
	    $island->{'dead'} = 1;
	    $island->{'pts'} = 0;
	    $remainNumber--;
	    # ���ǥ�å�����
	    my($tmpid) = $island->{'id'};
	    logDead($tmpid, $island->{'name'});
	    unlink("island.$tmpid");
	}

    }

    if(($HislandTurn % $HturnPrizeUnit) == 0) {

	islandSortac4();

	my($island, $ii, $j);
	for($ii = 0; $ii < $HislandNumber; $ii++) {
	    $j = $ii + 1;
	    $island = $Hislands[$ii];
	    $auc0 = $island->{'auc0'};
	    $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
	    $island->{'auc0'} = "$auc0a,$auc0b,$auc0c,$auc0d,$j";

		    $auc4 = $island->{'auc4'};
		    $auc4 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
		    ($auc4a, $auc4b, $auc4c) = ($1, $2, $3);

		if($ii == 0) {
		    $auc4a++;
		    $auc4b++;
			if($auc4b >= $aucshouhin) {
			    $auc4b = $aucshouhin;
			}
		    $island->{'auc4'} = "$auc4a,$auc4b,$auc4c";
		} else {
		    $island->{'auc4'} = "$auc4a,0,0";
		}

	}

	my($island) = $Hislands[0];
	    my($value, $str);
	    $value = $HislandTurn + random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";

		    $str .= "/�����1��";
		    $etc8 = $island->{'etc8'};
		    $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
		    $toto2+=1;
		    $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

	    logPrizeAuc($island->{'id'}, $island->{'name'}, "$HislandTurn${Hprize[0]}", $str);

    }

    # �͸���˥�����
    islandSort();

    # ���������оݥ�������ä��顢���ν���
    if(($HislandTurn % $HturnPrizeUnit) == 0) {
	my($island) = $Hislands[0];
	    my($value, $str);
	    $value = $HislandTurn + random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	logPrizet($island->{'id'}, $island->{'name'}, "$HislandTurn${Hprize[0]}", $str);
	    if($island->{'sin'} > 0) {
	    my($value, $str);
	    $value = $HislandTurn + random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logSinMoney($island->{'id'}, $island->{'name'}, $str);
	    }
	    if($island->{'jin'} > 0) {
	    my($value, $str);
	    $value = $HislandTurn + random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logJinMoney($island->{'id'}, $island->{'name'}, $str);
	    }
	$island->{'prize'} .= "${HislandTurn},";
    }

    if(($HislandTurn % $HturnPrizeUnit) == 0) {

	$auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);

	$shuppin = random(28)+1;
	    $value = 0;
	    if($shuppin == 9) {
		$value = 1 + random(5);
	    } elsif($shuppin == 10) {
		$value = 1000 + random(1500);
	    } elsif($shuppin == 11) {
		$value = 500 + random(1000);
	    } elsif($shuppin == 12) {
		$value = 2000 + random(2000);
	    } elsif($shuppin == 17) {
		$value = 500 + random(750);
	    } elsif($shuppin == 18) {
		$value = 300 + random(500);
	    } elsif($shuppin == 22) {
		$value = 1 + random(4);
	    } elsif($shuppin == 23) {
		$value = 1 + random(4);
	    } elsif($shuppin == 24) {
		$value = 1 + random(999);
	    } elsif($shuppin == 25) {
		$value = 80 + random(3);
	    } elsif($shuppin == 27) {
		$value = 500 + random(2000);
	    } elsif($shuppin == 28) {
		$value = 500 + random(2000);
	    }

	    $ajoutai = 0;

	    if(($aucflag1 < 90) && ($shuppin1 != 29)) {
		$shuppin = 29;
		$ajoutai = 15;
	    }

		$motone = random($shuppin);

	$auction1 = "$shuppin,$value,$ajoutai,$motone,0";


	$auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);

	$shuppin = random(28)+1;
	    $value = 0;
	    if($shuppin == 9) {
		$value = 1 + random(5);
	    } elsif($shuppin == 10) {
		$value = 1000 + random(1500);
	    } elsif($shuppin == 11) {
		$value = 500 + random(1000);
	    } elsif($shuppin == 12) {
		$value = 2000 + random(2000);
	    } elsif($shuppin == 17) {
		$value = 500 + random(750);
	    } elsif($shuppin == 18) {
		$value = 300 + random(500);
	    } elsif($shuppin == 22) {
		$value = 1 + random(4);
	    } elsif($shuppin == 23) {
		$value = 1 + random(4);
	    } elsif($shuppin == 24) {
		$value = 1 + random(999);
	    } elsif($shuppin == 25) {
		$value = 80 + random(3);
	    } elsif($shuppin == 27) {
		$value = 500 + random(2000);
	    } elsif($shuppin == 28) {
		$value = 500 + random(2000);
	    }

	    if($HislandNumber < 20) {
		$shuppin = 29;
	    }
	    if(random(1000) < 100-$HislandNumber+$oyasumiritu*25) {
		$shuppin = 29;
	    }

	    $ajoutai = 0;
	    if($shuppin == 29) {
		$ajoutai = 15;
	    }

	    if(($aucflag2 < 120) && ($shuppin2 != 29)) {
		$shuppin = 29;
		$ajoutai = 15;
	    }

		$motone = random($shuppin)*2;

	$auction2 = "$shuppin,$value,$ajoutai,$motone,0";


	$auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

	$shuppin = random(28)+1;
	    $value = 0;
	    if($shuppin == 9) {
		$value = 1 + random(5);
	    } elsif($shuppin == 10) {
		$value = 1000 + random(1500);
	    } elsif($shuppin == 11) {
		$value = 500 + random(1000);
	    } elsif($shuppin == 12) {
		$value = 2000 + random(2000);
	    } elsif($shuppin == 17) {
		$value = 500 + random(750);
	    } elsif($shuppin == 18) {
		$value = 300 + random(500);
	    } elsif($shuppin == 22) {
		$value = 1 + random(4);
	    } elsif($shuppin == 23) {
		$value = 1 + random(4);
	    } elsif($shuppin == 24) {
		$value = 1 + random(999);
	    } elsif($shuppin == 25) {
		$value = 80 + random(3);
	    } elsif($shuppin == 27) {
		$value = 500 + random(2000);
	    } elsif($shuppin == 28) {
		$value = 500 + random(2000);
	    }

	    if($HislandNumber < 30) {
		$shuppin = 29;
	    }

	    if(random(1000) < $oyasumiritu*12.5) {
		$shuppin = 29;
	    }

	    $ajoutai = 0;
	    if($shuppin == 29) {
		$ajoutai = 15;
	    }

	    if(($aucflag3 < 60) && ($shuppin3 != 29)) {
		$shuppin = 29;
		$ajoutai = 15;
	    }

		$motone = random($shuppin);

	$auction3 = "$shuppin,$value,$ajoutai,$motone,0";
    }

    $auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);
	if($ajoutai1 < 15) {
	    $ajoutai1++;
	}
	if((($HislandTurn % $HturnPrizeUnit) > 74) && (random(100) < 5)) {
	    $ajoutai1 = 15;
	}
    $auction1 = "$shuppin1,$avalue1,$ajoutai1,$topvalue1,$topid1";

    $auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);
	if($ajoutai2 < 15) {
	    $ajoutai2++;
	}
	if((($HislandTurn % $HturnPrizeUnit) > 74) && (random(100) < 5)) {
	    $ajoutai2 = 15;
	}
    $auction2 = "$shuppin2,$avalue2,$ajoutai2,$topvalue2,$topid2";

    $auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);
	if($ajoutai3 < 15) {
	    $ajoutai3++;
	}
	if((($HislandTurn % $HturnPrizeUnit) > 74) && (random(100) < 5)) {
	    $ajoutai3 = 15;
	}
    $auction3 = "$shuppin3,$avalue3,$ajoutai3,$topvalue3,$topid3";

    # ������å�
    $HislandNumber = $remainNumber;

##### ��������
    # toto �ν���
    unless ($HislandTurn % $HturnPrizeUnit) {
      # �������դΥ�����ʤ�

      # toto �������׻�����
      my(@totoAns, $island);
      foreach $island (@Hislands[0..4, 9, 19, 29]) {
        push(@totoAns, (defined $island->{'id'} ? $island->{'id'} : '0'));
      }

      # ����Υ�������
      logHistory("${HtagName_}��${HislandTurn}������ �������${H_tagName} <B>�� @totoAns</B>");

      # toto ��Ū��Ƚ��򤹤�
      my($allBet, @totoID);
      my(@totoBet, $i, $j, $n);
      for ($i = 0; $i < $HislandNumber; $i++) {
        $island = $Hislands[$i];
        next unless (@totoBet = ($island->{'eis8'} =~ /\(toto\@(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\)/));

        # toto ������˾�ʤ�
        my $betCost = 1000; # �������� 1000 ����
        if ($island->{'money'} < $betCost) {
          # �������Ѥ��ʤ�
          logNoMoney($island->{'id'}, $island->{'name'}, '����������');
        } else {
          # �������Ѥ�����
          $island->{'money'} -= $betCost;
          $allBet += $betCost;

          # Ū��������Ƚ��
          for ($n = 0, $j = 0; $j <= $#totoAns; $j++) {
            $n++ if ($totoAns[$j] == $totoBet[$j]);
          }

          # ������̤򵭲�
          $totoID[$n] .= "$i,";
        }
      }

      # Ū���������Ȥ�ʧ���ᤷΨ
      my @rate;
      $rate[8] = 20;
      $rate[7] =  8;
      $rate[6] =  2;

      # toto ��ʧ���ᤷ�򤹤�
      # �ʣ���Ū�������Ū���
      my(@id, $bet);
      foreach $i (6..8) {
        if ($totoID[$i] ne '') {
          # ����Ԥ�����
          @id  = split(/,/, $totoID[$i]);
          $bet = int($allBet * $rate[$i] / ($#id + 1));

          # ������ۤΥ�������
          logHistory("${HtagName_}��${HislandTurn}������ �������${H_tagName} ${i}��Ū�������Auction����� $bet$HunitMoney");

          foreach $n (@id) {
            $island = $Hislands[$n];

		$auc9 = $island->{'auc9'};
		$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
		$auc9c += $bet;
		$auc9c2 = int($auc9c/10000);
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";

	    $totoget=$i-5;
            logOut("${HtagName_}$island->{'name'}��${H_tagName} ${HtagName_}�������${H_tagName} ${i}��Ū�桪�����${totoget}�ĥ��åȡ�", $island->{'id'});

	    $etc8 = $island->{'etc8'};
	    $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
	    $toto1++;
	    $toto2+=$i-5;
	    $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

          }
        } else {
          # ����Ԥ����ʤ�
          $rate[$i + 1] += $rate[$i]; # ͽ�����̤�����˲�
        }
      }
    }
##### �����ޤ�

    # HCtoto �ν���

      if((($HislandTurn % 100) == 50) && (($yushouflag == 1) || ($yushouflag == 2))) {

      # toto �������׻�����

      my @totoAns = ($yushounamber, $yushounamber2);

      # ����Υ�������
      logHistory("${HtagName_}��${HislandTurn}������ Hakoniwa Cup toto${H_tagName} <B>�� @totoAns</B>");
      # toto ��Ū��Ƚ��򤹤�
      my($allBet, @totoID);
      my(@totoBet, $i, $j, $n);
      for ($i = 0; $i < $HislandNumber; $i++) {
        $island = $Hislands[$i];
        next unless (@totoBet = ($island->{'eis8'} =~ /\(hc\@(\d+)\.(\d+)\)/));

        # toto ������˾�ʤ�
        my $betCost = 10000; # �������� 1000 ����
        if ($island->{'money'} < $betCost) {
          # �������Ѥ��ʤ�
          logNoMoney($island->{'id'}, $island->{'name'}, 'Hakoniwa Cup toto');
        } else {
          # �������Ѥ�����
          $island->{'money'} -= $betCost;
          $allBet += $betCost;

          # Ū��������Ƚ��
          for ($n = 0, $j = 0; $j <= $#totoAns; $j++) {
            $n++ if ($totoAns[$j] == $totoBet[$j]);
          }

          # ������̤򵭲�
          $totoID[$n] .= "$i,";
        }
      }

      # Ū���������Ȥ�ʧ���ᤷΨ
      my @rate;
      $rate[2] = 10;
      $rate[1] =  3;

      # toto ��ʧ���ᤷ�򤹤�
      # �ʣ���Ū�������Ū���
      my(@id, $bet);
      foreach $i (1..2) {
        if ($totoID[$i] ne '') {
          # ����Ԥ�����
          @id  = split(/,/, $totoID[$i]);
          $bet = int($allBet * $rate[$i] / ($#id + 1));

          # ������ۤΥ�������
          logHistory("${HtagName_}��${HislandTurn}������ Hakoniwa Cup toto${H_tagName} ${i}��Ū�������Auction����� $bet$HunitMoney");

          foreach $n (@id) {
            $island = $Hislands[$n];

		$auc9 = $island->{'auc9'};
		$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
		$auc9c += $bet;
		$auc9c2 = int($auc9c/10000);
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";

		if($i == 1) {
		    $totoget=1;
		}
		if($i == 2) {
		    $totoget=2;
		}

	    $etc8 = $island->{'etc8'};
	    $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
	    $toto1++;
	    $toto2+=$totoget;
	    $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

            logOut("${HtagName_}$island->{'name'}��${H_tagName} ${HtagName_}Hakoniwa Cup toto${H_tagName} ${i}��Ū�桪�����${totoget}�ĥ��åȡ�", $island->{'id'});

          }
        } else {
          # ����Ԥ����ʤ�
          $rate[$i + 1] += $rate[$i]; # ͽ�����̤�����˲�
        }
      }
    }

##### �����ޤ�

    # Numbers3 �ν���

      if(($HislandTurn % 20) == 0) {

      # toto �������׻�����
      my @totoAns = (random(999));

      # ����Υ�������
      logHistory("${HtagName_}��${HislandTurn}������ Numbers3${H_tagName} <B>�� @totoAns</B>");

      # toto ��Ū��Ƚ��򤹤�
      my($allBet, @totoID);
      my(@totoBet, $i, $j, $n);
      for ($i = 0; $i < $HislandNumber; $i++) {
        $island = $Hislands[$i];
        next unless (@totoBet = ($island->{'eis8'} =~ /\(n3\@(\d+)\)/));

        # toto ������˾�ʤ�
        my $betCost = 200; # �������� 200 ����
        if ($island->{'money'} < $betCost) {
          # �������Ѥ��ʤ�
          logNoMoney($island->{'id'}, $island->{'name'}, 'Numbers3����');
        } else {
          # �������Ѥ�����
          $island->{'money'} -= $betCost;
          $allBet += $betCost;

          # Ū��������Ƚ��
          for ($n = 0, $j = 0; $j <= $#totoAns; $j++) {
            $n++ if ($totoAns[$j] == $totoBet[$j]);
          }

          # ������̤򵭲�
          $totoID[$n] .= "$island->{'id'},";
        }
      }

      # Ū���������Ȥ�ʧ���ᤷΨ
      my @rate;
      $rate[1] = 100;

      # toto ��ʧ���ᤷ�򤹤�
      # �ʣ���Ū�������Ū���
      my(@id, $bet);
      foreach $i (1) {
        if ($totoID[$i] ne '') {
          # ����Ԥ�����
          @id  = split(/,/, $totoID[$i]);
          $bet = int($allBet * $rate[$i] / ($#id + 1));

          # ������ۤΥ�������
          logHistory("${HtagName_}��${HislandTurn}������ Numbers3${H_tagName} Ū��������� $bet$HunitMoney");

          foreach $n (@id) {
            $island = $Hislands[$HidToNumber{$n}];
            $island->{'money'} += $bet;
            logOut("${HtagName_}$island->{'name'}��${H_tagName} ${HtagName_}Numbers3${H_tagName} Ū�桪", $n);
          }
        } else {
          # ����Ԥ����ʤ�
          $rate[$i + 1] += $rate[$i]; # ͽ�����̤�����˲�
        }
      }
    }
##### �����ޤ�

    # Numbers4 �ν���

      if(($HislandTurn % 20) == 10) {

      # toto �������׻�����
      my @totoAns = (random(9999));

      # ����Υ�������
      logHistory("${HtagName_}��${HislandTurn}������ Numbers4${H_tagName} <B>�� @totoAns</B>");

      # toto ��Ū��Ƚ��򤹤�
      my($allBet, @totoID);
      my(@totoBet, $i, $j, $n);
      for ($i = 0; $i < $HislandNumber; $i++) {
        $island = $Hislands[$i];
        next unless (@totoBet = ($island->{'eis8'} =~ /\(n4\@(\d+)\)/));

        # toto ������˾�ʤ�
        my $betCost = 200; # �������� 200 ����
        if ($island->{'money'} < $betCost) {
          # �������Ѥ��ʤ�
          logNoMoney($island->{'id'}, $island->{'name'}, 'Numbers4����');
        } else {
          # �������Ѥ�����
          $island->{'money'} -= $betCost;
          $allBet += $betCost;

          # Ū��������Ƚ��
          for ($n = 0, $j = 0; $j <= $#totoAns; $j++) {
            $n++ if ($totoAns[$j] == $totoBet[$j]);
          }

          # ������̤򵭲�
          $totoID[$n] .= "$island->{'id'},";
        }
      }

      # Ū���������Ȥ�ʧ���ᤷΨ
      my @rate;
      $rate[1] = 200;

      # toto ��ʧ���ᤷ�򤹤�
      # �ʣ���Ū�������Ū���
      my(@id, $bet);
      foreach $i (1) {
        if ($totoID[$i] ne '') {
          # ����Ԥ�����
          @id  = split(/,/, $totoID[$i]);
          $bet = int($allBet * $rate[$i] / ($#id + 1));

          # ������ۤΥ�������
          logHistory("${HtagName_}��${HislandTurn}������ Numbers4${H_tagName} Ū��������� $bet$HunitMoney");

          foreach $n (@id) {
            $island = $Hislands[$HidToNumber{$n}];
            $island->{'money'} += $bet;
            logOut("${HtagName_}$island->{'name'}��${H_tagName} ${HtagName_}Numbers4${H_tagName} Ū�桪", $n);
          }
        } else {
          # ����Ԥ����ʤ�
          $rate[$i + 1] += $rate[$i]; # ͽ�����̤�����˲�
        }
      }
    }
##### �����ޤ�

    if(($HislandTurn % 100) == 0) {
    $stsanka = $stsanka - 1;
    logHC($id, $name, $stsanka);
    }

    if($AnkeitoOnOff == 0) {
	$an1 = 0;
	$an2 = 0;
	$an3 = 0;
	$an4 = 0;
	$an5 = 0;
    }

    # �Хå����åץ�����Ǥ���С�������rename
    if(($HislandTurn % $HbackupTurn) == 0) {
	my($i);
	my($tmp) = $HbackupTimes - 1;
	myrmtree("${HdirName}.bak$tmp");
	for($i = ($HbackupTimes - 1); $i > 0; $i--) {
	    my($j) = $i - 1;
	    rename("${HdirName}.bak$j", "${HdirName}.bak$i");
	}
	rename("${HdirName}", "${HdirName}.bak0");
	mkdir("${HdirName}", $HdirMode);

	# �����ե���������᤹
	for($i = 0; $i <= $HlogMax; $i++) {
	    rename("${HdirName}.bak0/hakojima.log$i",
		   "${HdirName}/hakojima.log$i");
	}
	rename("${HdirName}.bak0/hakojima.his",
	       "${HdirName}/hakojima.his");
	rename("${HdirName}.bak0/hakojima.lhc",
	       "${HdirName}/hakojima.lhc");
	rename("${HdirName}.bak0/hakojima.auc",
	       "${HdirName}/hakojima.auc");
    }

    # �ե�����˽񤭽Ф�
    writeIslandsFile(-1);

    my($uti, $sti, $cuti, $csti) = times();
    $uti += $cuti;
    $sti += $csti;
    my($cpu) = $uti + $sti;
    logOut("<SMALL>��ٷ�¬ CPU($cpu) : user($uti) system($sti) Ver.050309</SMALL>",0);

    # �����񤭽Ф�
    logFlush();

    # ��Ͽ����Ĵ��
    logHistoryTrim();

    logHcupTrim();

    logAucTrim();

    # �ȥåפ�
    topPageMain();
}

# �ǥ��쥯�ȥ�ä�
sub myrmtree {
    my($dn) = @_;
    opendir(DIN, "$dn/");
    my($fileName);
    while($fileName = readdir(DIN)) {
	unlink("$dn/$fileName");
    } 
    closedir(DIN);
    rmdir($dn);
}

# ����������ե�����
sub income {
    my($island) = @_;
    my($pop, $farm, $factory, $mountain) = 
	(      
	 $island->{'pop'},
	 $island->{'farm'} * 10,
	 $island->{'factory'},
	 $island->{'mountain'}
	 );

	$factory =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($factory1, $factory2, $co0, $co1, $htf, $shtf, $co95, $co95, $co95, $co95) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10);

    $island->{'incomemoney'} = 0;

    # ����
    if($pop > $farm) {
	# ���Ȥ�������꤬;����
	$island->{'food'} += $farm * ($island->{'co0'} + 1); # ����ե��Ư


	    if($factory2 * 10 > ($pop - $farm)) {

		    $auc9 = $island->{'auc9'};
		    $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

			$auc9c += int(($pop - $farm) / 10);

		    $auc9c2 = int($auc9c/10000);
		    $auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		    $island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";

	    } else {

		    $auc9 = $island->{'auc9'};
		    $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

			$auc9c += $factory2;

		    if($island->{'shouhi'} > $island->{'ene'}) {

			$island->{'money'} +=
			    min(int(($pop - $farm - $factory2*10) / 20),
				 int(($factory1 + $mountain)/2));
			$island->{'incomemoney'} +=
			    min(int(($pop - $farm - $factory2*10) / 20),
				 int(($factory1 + $mountain)/2));
			logStarve2($island->{'id'}, $island->{'name'});
		    } else {
			$island->{'money'} +=
			    min(int(($pop - $farm - $factory2*10) / 10),
				 $factory1 + $mountain) * ($island->{'co1'} + 1);
			$island->{'incomemoney'} +=
			    min(int(($pop - $farm - $factory2*10) / 10),
				 $factory1 + $mountain) * ($island->{'co1'} + 1);
		    }

		    $auc9c2 = int($auc9c/10000);
		    $auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		    $island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	    }

    } else {
	# ���Ȥ����Ǽ���դξ��
	$island->{'food'} += $pop * ($island->{'co0'} + 1); # �������ɻŻ�
    }

    # ��������
    $island->{'food'} = int(($island->{'food'}) - ($pop * $HeatenFood));
}


# ���ޥ�ɥե�����
sub doCommand {
    my($island) = @_;

    # ���ޥ�ɼ��Ф�
    my($comArray, $command);
    $comArray = $island->{'command'};
    $command = $comArray->[0]; # �ǽ�Τ���Ф�
    slideFront($comArray, 0); # �ʹߤ�ͤ��

    # �����Ǥμ��Ф�
    my($kind, $target, $x, $y, $arg) = 
	(
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );

    # Ƴ����
    my($name) = $island->{'name'};
    my($id) = $island->{'id'};
    my($land) = $island->{'land'};
    my($landValue) = $island->{'landValue'};
    my($landKind) = $land->[$x][$y];
    my($lv) = $landValue->[$x][$y];
    my($cost) = $HcomCost[$kind];
    my($comName) = $HcomName[$kind];
    my($point) = "($x, $y)";
    my($landName) = landName($landKind, $lv);

	$jikkouarg = 0;

    if($kind == $HcomDoNothing) {
	# ��ⷫ��
	logDoNothing($id, $name, $comName);
	$island->{'money'} += 100;
	$island->{'money'} += random(100);
		    if(random(100) < 5) {
		    my($value, $str, $lName);
		    $lName = landName($landKind, $lv);
		    $value = 1+ random(1999);
		    $island->{'money'} += $value;
		    $str = "$value$HunitMoney";
	            # ��������
	            logEnjo($id, $name, $lName, "($x, $y)", $str) if ($value > 0);
		    }
	$island->{'absent'} ++;
	
	# ��ư����
	if($island->{'absent'} >= $HgiveupTurn) {
	    $comArray->[0] = {
		'kind' => $HcomGiveup,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0
	    }
	}
	return 1;
    }

    $island->{'absent'} = 0;

    if($anothermood == 1) {
	    if($kind == $HcomHouse) {
		$cost = $island->{'pts'}*2;
	    }
	    if($kind == $HcomKai) {
		$cost = $island->{'pts'}*2;
	    }
	    if($kind == $HcomBoku2) {
		$cost = $island->{'pts'}*4;
	    }
    } else {
	    if($kind == $HcomHouse) {
		$cost = $island->{'pts'}*3;
	    }
	    if($kind == $HcomBettown) {
		$cost = $island->{'pts'};
	    }
	    if($kind == $HcomKai) {
		$cost = $island->{'pts'};
	    }
	    if($kind == $HcomBoku2) {
		$cost = $island->{'pts'}*4;
	    }
    }

			        if($island->{'pts'} > $HouseLevel9) {
			 	    $costx = 2;
			        } elsif($island->{'pts'} > $HouseLevel8) {
			 	    $costx = 1.8;
			        } elsif($island->{'pts'} > $HouseLevel7) {
				    $costx = 1.8;
			        } elsif($island->{'pts'} > $HouseLevel6) {
			 	    $costx = 1.6;
			        } elsif($island->{'pts'} > $HouseLevel5) {
				    $costx = 1.6;
			        } elsif($island->{'pts'} > $HouseLevel4) {
			 	    $costx = 1.4;
			        } elsif($island->{'pts'} > $HouseLevel3) {
				    $costx = 1.4;
			        } elsif($island->{'pts'} > $HouseLevel2) {
			 	    $costx = 1.2;
			        } elsif($island->{'pts'} > $HouseLevel1) {
				    $costx = 1;
			        } else {
				    $costx = 1;
			        }

    if (($anothermood != 1) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomHouse) && ($kind != $HcomBettown) && ($kind != $HcomKai) && ($kind != $HcomBoku2) && ($kind != $HcomEneCs) && ($kind != $HcomEneNF) && ($kind != $HcomEisei) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = $cost * $costx;
    }

    if (($island->{'htf'} > 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * 2 / 3);
    } elsif (($island->{'shtf'} > 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * 9 / 10);
    }

    $costco95 = 0.975**$island->{'co95'};

	    if($costco95 < 0.9) {
		$costco95 = 0.9;
	    }

    if (($island->{'co95'} > 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costco95);
    }

    $etc5 = $island->{'etc5'};
    $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

    $costseisaku = $s01+$s03+$s05+$s07+$s09+$s11+$s13+$s15+$s17+$s19+$s21+$s23+$s25+$s27+$s29+$s02+$s04+$s06+$s08+$s10+$s12+$s14+$s16+$s18+$s20+$s22+$s24+$s26+$s28+$s30;
    $costseisaku2 = 0.9975**$costseisaku;

    if($costseisaku2 < 0.75) {
	$costseisaku2 = 0.75;
    }

    if (($s00 > 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costseisaku2);
    }

    $s12b = int($s12/5)+1;
    if($s12b > 10) {$s12b = 10;}

    $costmoney = $island->{'money'}/5/(999999*$s12b)+0.8;

    if (($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costmoney);
    }

    # �����ȥ����å�
    if($cost > 0) {
	# ��ξ��
	if($island->{'money'} < $cost) {
	if((($landKind == $HlandFarmchi) && ($kind == $HcomFarmcpc)) ||
	   (($landKind == $HlandFarmpic) && ($kind == $HcomFarmcpc)) ||
	   (($landKind == $HlandFarmcow) && ($kind == $HcomFarmcpc))) {
	} else {
	    logNoMoney($id, $name, $comName);
	    return 0;
	}
	}
    } elsif($cost < 0) {
	# �����ξ��
	if($island->{'food'} < (-$cost)) {
	    logNoFood($id, $name, $comName);
	    return 0;
	}
    }

    # ���ޥ�ɤ�ʬ��
    if(($kind == $HcomPrepare) ||
       ($kind == $HcomPrepare2)) {
	# ���ϡ��Ϥʤ餷
	if(($landKind == $HlandSea) || 
	   ($landKind == $HlandSbase) ||
	   ($landKind == $HlandSeacity) ||
	   ($landKind == $HlandSeatown) ||
	   ($landKind == $HlandOil) ||
	   ($landKind == $HlandIce) ||
	   ($landKind == $HlandFune) ||
	   ($landKind == $HlandFrocity) ||
           ($landKind == $HlandNursery) ||
	   ($landKind == $HlandUmiamu) ||
	   ($landKind == $HlandGold) ||
	   ($landKind == $HlandRottenSea) ||
	   ($landKind == $HlandMountain) ||
	   ($landKind == $HlandUmishuto) ||
	   ($landKind == $HlandMonster)) {
	    # ����������ϡ����ġ��������ä����ϤǤ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

        if ((($landKind == $HlandMonument) && ($lv == 80)) ||
	    (($landKind == $HlandMonument) && ($lv == 81)) ||
	    (($landKind == $HlandMonument) && ($lv == 82)) ||
	    (($landKind == $HlandMonument) && ($lv == 83))) {
		$island->{'food'} += 20000; # ���٤��㤨
	}

        if ((($landKind == $HlandMonument) && ($lv == 74)) ||
	    (($landKind == $HlandMonument) && ($lv == 75)) ||
	    (($landKind == $HlandMonument) && ($lv == 76)) ||
	    (($landKind == $HlandMonument) && ($lv == 77)) ||
	    (($landKind == $HlandMonument) && ($lv == 78)) ||
	    (($landKind == $HlandMonument) && ($lv == 79))) {
		$island->{'money'} += 20000; # ���в�����
	}

	# ��Ū�ξ���ʿ�Ϥˤ���
	$land->[$x][$y] = $HlandPlains;
	$landValue->[$x][$y] = 0;

	logLandSuc($id, $name, '����', $point);

	# ��򺹤�����
	$island->{'money'} -= $cost;

	if($kind == $HcomPrepare2) {
	    # �Ϥʤ餷
	    $island->{'prepare2'}++;
	    
	    # ��������񤻤�
	    return 0;
	} else {
	    # ���Ϥʤ顢��¢��β�ǽ������
	    if(random(1000) < $HdisMaizo) {
		my($v) = 100 + random(901);
		$island->{'money'} += $v;
		logMaizo($id, $name, $comName, $v);
	    }
	    return 1;
	}
    } elsif(($kind == $HcomReclaim) ||
	    ($kind == $HcomReclaim2) ||
	    ($kind == $HcomReclaim3)) {
	# ���Ω��
	if(($landKind != $HlandSea) &&
	   ($landKind != $HlandPlains) &&
	   ($landKind != $HlandPlains2) &&
	   ($landKind != $HlandWaste) &&
	   ($landKind != $HlandOil) &&
           ($landKind != $HlandNursery) &&
	   ($landKind != $HlandUmiamu) &&
	   ($landKind != $HlandSbase) &&
	   ($landKind != $HlandSeatown) &&
	   ($landKind != $HlandUmishuto) &&
	   ($landKind != $HlandSeacity)) {
	    # ����������ϡ����Ĥ������Ω�ƤǤ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	# �����Φ�����뤫�����å�
	my($seaCount) =
	    countAround($land, $x, $y, $HlandSea, 7) +
	    countAround($land, $x, $y, $HlandOil, 7) +
	    countAround($land, $x, $y, $HlandIce, 7) +
	    countAround($land, $x, $y, $HlandSbase, 7) +
	    countAround($land, $x, $y, $HlandFune, 7) +
	    countAround($land, $x, $y, $HlandFrocity, 7) +
            countAround($land, $x, $y, $HlandNursery, 7) +
	    countAround($land, $x, $y, $HlandUmiamu, 7) +
	    countAround($land, $x, $y, $HlandSeatown, 7) +
	    countAround($land, $x, $y, $HlandUmishuto, 7) +
            countAround($land, $x, $y, $HlandSeacity, 7);

        if(($seaCount == 7) &&
	   (($kind == $HcomReclaim)||($kind == $HcomReclaim3))) {
	    # ���������������Ω����ǽ
	    logNoLandAround($id, $name, $comName, $point);
	    return 0;
	}

	if(($landKind == $HlandSea) && ($lv == 1)) {
	    # �����ξ��
	    # ��Ū�ξ�����Ϥˤ���
	    $land->[$x][$y] = $HlandWaste;
	    $landValue->[$x][$y] = 0;

		if($kind == $HcomReclaim3) {
		    $land->[$x][$y] = $HlandMountain;
		    $landValue->[$x][$y] = 0;
		}

	    logLandSuc($id, $name, $comName, $point);
	    $island->{'area'}++;

	    if($seaCount <= 4) {
		# ����γ���3�إå�������ʤΤǡ������ˤ���
		my($i, $sx, $sy);

		for($i = 1; $i < 7; $i++) {
		    $sx = $x + $ax[$i];
		    $sy = $y + $ay[$i];

		    # �Ԥˤ�����Ĵ��
		    if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		    }

		    if(($sx < 0) || ($sx >= $HislandSize) ||
		       ($sy < 0) || ($sy >= $HislandSize)) {
		    } else {
			# �ϰ���ξ��
			if($land->[$sx][$sy] == $HlandSea) {
			    $landValue->[$sx][$sy] = 1;
			}
		    }
		}
	    }
	} elsif($landKind == $HlandPlains || $landKind == $HlandPlains2 || $landKind == $HlandWaste) {
	    # ���ʤ顢��Ū�ξ��������ˤ���
	    $land->[$x][$y] = $HlandMountain;
	    $landValue->[$x][$y] = 0;
	    logLandSuc($id, $name, $comName, $point);
	} elsif(($kind == $HcomReclaim3) && ($landKind == $HlandSea) && ($lv == 1)) {
	    # ���ʤ顢��Ū�ξ��������ˤ���
	    $land->[$x][$y] = $HlandMountain;
	    $landValue->[$x][$y] = 0;
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomReclaim3) {
	    # ���ʤ顢��Ū�ξ��������ˤ���
	    $land->[$x][$y] = $HlandWaste;
	    $landValue->[$x][$y] = 0;
	    logLandSuc($id, $name, $comName, $point);
	} else {
	    # ���ʤ顢��Ū�ξ��������ˤ���
	    $land->[$x][$y] = $HlandSea;
	    $landValue->[$x][$y] = 1;
	    logLandSuc($id, $name, $comName, $point);
	}
	
	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;
    } elsif($kind == $HcomMinato) {
	# ��
	if(($landKind != $HlandSea) &&
	   ($landKind != $HlandOil) &&
	   ($landKind != $HlandSbase) &&
           ($landKind != $HlandNursery) &&
	   ($landKind != $HlandUmiamu) &&
	   ($landKind != $HlandSeatown) &&
	   ($landKind != $HlandUmishuto) &&
	   ($landKind != $HlandSeacity)) {
	    # ����������ϡ����Ĥ������Ω�ƤǤ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	# �����Φ�����뤫�����å�
	my($seaCount) =
	    countAround($land, $x, $y, $HlandSea, 7) +
	    countAround($land, $x, $y, $HlandOil, 7) +
	    countAround($land, $x, $y, $HlandIce, 7) +
	    countAround($land, $x, $y, $HlandSbase, 7) +
	    countAround($land, $x, $y, $HlandFune, 7) +
	    countAround($land, $x, $y, $HlandFrocity, 7) +
            countAround($land, $x, $y, $HlandNursery, 7) +
	    countAround($land, $x, $y, $HlandUmiamu, 7) +
	    countAround($land, $x, $y, $HlandSeatown, 7) +
	    countAround($land, $x, $y, $HlandUmishuto, 7) +
            countAround($land, $x, $y, $HlandSeacity, 7);

        if($seaCount == 7) {
	    # ���������������Ω����ǽ
	    logNoLandAround($id, $name, $comName, $point);
	    return 0;
	}

	if(($landKind == $HlandSea) && ($lv == 1)) {
	    # �����ξ��
	    # ��Ū�ξ�����Ϥˤ���
	    $land->[$x][$y] = $HlandMinato;
	    $landValue->[$x][$y] = 0;
	    logLandSuc($id, $name, $comName, $point);
	    $island->{'area'}++;

	    if($seaCount <= 4) {
		# ����γ���3�إå�������ʤΤǡ������ˤ���
		my($i, $sx, $sy);

		for($i = 1; $i < 7; $i++) {
		    $sx = $x + $ax[$i];
		    $sy = $y + $ay[$i];

		    # �Ԥˤ�����Ĵ��
		    if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		    }

		    if(($sx < 0) || ($sx >= $HislandSize) ||
		       ($sy < 0) || ($sy >= $HislandSize)) {
		    } else {
			# �ϰ���ξ��
			if($land->[$sx][$sy] == $HlandSea) {
			    $landValue->[$sx][$sy] = 1;
			}
		    }
		}
	    }
	} else {
	    # ���ʤ顢��Ū�ξ��������ˤ���
	    $land->[$x][$y] = $HlandSea;
	    $landValue->[$x][$y] = 1;
	    logLandSuc($id, $name, $comName, $point);
	}
	
	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;

    } elsif($kind == $HcomFune) {
	# ��
	if(($landKind != $HlandSea) &&
	   ($landKind != $HlandOil) &&
	   ($landKind != $HlandSbase) &&
           ($landKind != $HlandNursery) &&
	   ($landKind != $HlandUmiamu) &&
	   ($landKind != $HlandSeatown) &&
	   ($landKind != $HlandUmishuto) &&
	   ($landKind != $HlandSeacity)) {
	    # ����������ϡ����Ĥ������Ω�ƤǤ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	# �����Φ�����뤫�����å�
	my($seaCount) =
	    countAround($land, $x, $y, $HlandMinato, 7);

        if($seaCount == 0) {
	    # ���������������Ω����ǽ
	    logNoLandAroundm($id, $name, $comName, $point);
	    return 0;
	}

	if($landKind == $HlandSea) {
	    # �����ξ��
	    # ��Ū�ξ�����Ϥˤ���
			if($arg == 77) {
			$land->[$x][$y] = $HlandFrocity;
			$landValue->[$x][$y] = 1;
			# ��򺹤�����
			$value = min($arg * ($cost), $island->{'money'});
			$island->{'money'} -= $value;
			logLandSuc($id, $name, $comName, $point);
			return 1;
			}

	    $land->[$x][$y] = $HlandFune;
		if(($arg >= $HfuneNumber) ||
		   ($arg == 0)) {
		    $arg = 1;
		}
		$landValue->[$x][$y] = $arg;
		logLandSuc($id, $name, $comName, $point);
			if(($arg == 1) ||
			   ($arg == 2) ||
			   ($arg == 5) ||
			   ($arg == 6) ||
			   ($arg == 11)) {
			    $island->{'gyo'}++;
			}

	} else {
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}
	
	# ��򺹤�����
	$value = min($arg * ($cost), $island->{'money'});
	$island->{'money'} -= $value;
	return 1;

    } elsif($kind == $HcomSeki) {
	# �ؽ�
	if(($landKind != $HlandSea) &&
	   ($landKind != $HlandOil) &&
	   ($landKind != $HlandSbase) &&
           ($landKind != $HlandNursery) &&
	   ($landKind != $HlandUmiamu) &&
	   ($landKind != $HlandSeatown) &&
	   ($landKind != $HlandUmishuto) &&
	   ($landKind != $HlandSeacity)) {
	    # ����������ϡ����Ĥ������Ω�ƤǤ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	my($seaCount) =
	    countAround($land, $x, $y, $HlandSea, 7) +
	    countAround($land, $x, $y, $HlandOil, 7) +
	    countAround($land, $x, $y, $HlandIce, 7) +
	    countAround($land, $x, $y, $HlandSbase, 7) +
	    countAround($land, $x, $y, $HlandFune, 7) +
	    countAround($land, $x, $y, $HlandFrocity, 7) +
            countAround($land, $x, $y, $HlandNursery, 7) +
	    countAround($land, $x, $y, $HlandUmiamu, 7) +
	    countAround($land, $x, $y, $HlandSeatown, 7) +
	    countAround($land, $x, $y, $HlandUmishuto, 7) +
            countAround($land, $x, $y, $HlandSeacity, 7);

	if(($landKind == $HlandSea) && ($lv == 1)) {
	    # �����ξ��
	    # ��Ū�ξ�����Ϥˤ���
	    $land->[$x][$y] = $HlandSeki;
	    $landValue->[$x][$y] = 0;
	    logLandSuc($id, $name, $comName, $point);
	    $island->{'area'}++;

	    if($seaCount <= 4) {
		# ����γ���3�إå�������ʤΤǡ������ˤ���
		my($i, $sx, $sy);

		for($i = 1; $i < 7; $i++) {
		    $sx = $x + $ax[$i];
		    $sy = $y + $ay[$i];

		    # �Ԥˤ�����Ĵ��
		    if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		    }

		    if(($sx < 0) || ($sx >= $HislandSize) ||
		       ($sy < 0) || ($sy >= $HislandSize)) {
		    } else {
			# �ϰ���ξ��
			if($land->[$sx][$sy] == $HlandSea) {
			    $landValue->[$sx][$sy] = 1;
			}
		    }
		}
	    }
	} else {
	    # ���ʤ顢��Ū�ξ��������ˤ���
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}
	
	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;

    } elsif(($kind == $HcomDestroy)||($kind == $HcomDestroy3)) {
	# ����
	if(($landKind == $HlandSbase) ||
	   ($landKind == $HlandSeacity) ||
	   ($landKind == $HlandSeatown) ||
	   ($landKind == $HlandOil) ||
	   ($landKind == $HlandFune) ||
	   ($landKind == $HlandFrocity) ||
           ($landKind == $HlandNursery) ||
	   ($landKind == $HlandUmiamu) ||
	   ($landKind == $HlandRottenSea) ||
	   ($landKind == $HlandUmishuto) ||
	   ($landKind == $HlandMonster)) {
	    # ������ϡ����ġ����äϷ���Ǥ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	if(($landKind == $HlandSea) && ($lv == 0)) {
	    # ���ʤ顢����õ��
	    # ���۷���
	    if($arg == 0) { $arg = 1; }
	    my($value, $str, $p);
	    $value = min($arg * ($cost), $island->{'money'});
	    $str = "$value$HunitMoney";
	    $p = int($value / $cost);
	    $island->{'money'} -= $value;

	    # ���Ĥ��뤫Ƚ��
            if($p > random(100) + $island->{'oil'} * 25) {
		# ���ĸ��Ĥ���
		logOilFound($id, $name, $point, $comName, $str);
		$land->[$x][$y] = $HlandOil;
		$landValue->[$x][$y] = 0;
		$island->{'oil'}++;

	    if($island->{'sin'} > 0) {
	    my($value, $str);
	    $value = random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logSinMoney($id, $name, $str);
	    }
	    if($island->{'jin'} > 0) {
	    my($value, $str);
	    $value = random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logJinMoney($id, $name, $str);
	    }

	    } else {
		# ̵�̷���˽����
		logOilFail($id, $name, $point, $comName, $str);
	    }
	    return 1;
	}

	# ��Ū�ξ��򳤤ˤ��롣���ʤ���Ϥˡ������ʤ鳤�ˡ�
	if($landKind == $HlandMountain) {
	    $land->[$x][$y] = $HlandWaste;
	    $landValue->[$x][$y] = 0;
		if($kind == $HcomDestroy3) {
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 1;
		}
	} elsif($landKind == $HlandGold) {
	    $land->[$x][$y] = $HlandWaste;
	    $landValue->[$x][$y] = 0;
		if($kind == $HcomDestroy3) {
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 1;
		}
	} elsif($landKind == $HlandIce) {
	    $land->[$x][$y] = $HlandSea;
	    $landValue->[$x][$y] = 1;
		if($kind == $HcomDestroy3) {
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		}
	} elsif($kind == $HcomDestroy3) {
	    $land->[$x][$y] = $HlandSea;
	    $landValue->[$x][$y] = 0;
	} elsif($landKind == $HlandSea) {
	    $landValue->[$x][$y] = 0;
	} else {
	    $land->[$x][$y] = $HlandSea;
	    $landValue->[$x][$y] = 1;
	    $island->{'area'}--;
	}
	logLandSuc($id, $name, $comName, $point);

	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;


    } elsif($kind == $HcomOnsen) {
	# ��������
	if($landKind != $HlandMountain) {
	    # ���ʳ��Ϸ���Ǥ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	if(($landKind == $HlandMountain) && ($lv == 0)) {
	    # ���ʤ顢����õ��
	    # ���۷���
	    if($arg == 0) { $arg = 1; }
	    my($value, $str, $p);
	    $value = min($arg * ($cost), $island->{'money'});
	    $str = "$value$HunitMoney";
	    $p = int($value / $cost);
	    $island->{'money'} -= $value;

	    # ���Ĥ��뤫Ƚ��
	    if(random(10000) < $p * 15) {
		my($v) = 1000 + random(2001);
		$island->{'money'} += $v;
		$land->[$x][$y] = $HlandGold;
		$landValue->[$x][$y] = 1;
		logGold($id, $name, $comName, $v);

	    if($island->{'sin'} > 0) {
	    my($value, $str);
	    $value = random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logSinMoney($id, $name, $str);
	    }
	    if($island->{'jin'} > 0) {
	    my($value, $str);
	    $value = random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logJinMoney($id, $name, $str);
	    }

	    } elsif(random(1000) < 50) {
		logEggFound($id, $name, $comName, $value);
		$land->[$x][$y] = $HlandMonument;
		$eggnum = 80+random(3);
		$landValue->[$x][$y] = $eggnum;
	    } elsif((random(1000) < 50) && ($island->{'m84'} < 4)) {
		logIsekiFound($id, $name, $comName, $value);
		$land->[$x][$y] = $HlandMonument;
		$landValue->[$x][$y] = 84;
	    } elsif($p > random(100) + $island->{'hot'} * 30) {
		# ���ĸ��Ĥ���
		logHotFound($id, $name, $point, $comName, $str);
		$land->[$x][$y] = $HlandOnsen;
		$landValue->[$x][$y] = 1;
	    } else {
		# ̵�̷���˽����
		logHotFail($id, $name, $point, $comName, $str);
	    }

	    if(random(1000) < 15) {
		my($v) = 100 + random(901);
		$island->{'money'} += $v;
		logMaizo($id, $name, $comName, $v);
	    }

		# ��򺹤�����
		$island->{'money'} -= $cost;
	    return 1;
	}

    } elsif($kind == $HcomSellTree) {
	# Ȳ��
	if($landKind != $HlandForest) {
	    # ���ʳ���Ȳ�ΤǤ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	# ��Ū�ξ���ʿ�Ϥˤ���
	$land->[$x][$y] = $HlandPlains;
	$landValue->[$x][$y] = 0;
	logLandSuc($id, $name, $comName, $point);
	    if(random(1000) < 75) {
		logEggFound($id, $name, $comName, $value);
		$land->[$x][$y] = $HlandMonument;
		$eggnum = 80+random(3);
		$landValue->[$x][$y] = $eggnum;
	    }

	# ��Ѷ������
	$island->{'money'} += $HtreeValue * $lv;
	return 0;
    } elsif(($kind == $HcomPlant) ||
	    ($kind == $HcomFarm) ||
	    ($kind == $HcomEneAt) ||
	    ($kind == $HcomEneFw) ||
	    ($kind == $HcomEneWt) ||
	    ($kind == $HcomEneWd) ||
	    ($kind == $HcomEneBo) ||
	    ($kind == $HcomEneSo) ||
	    ($kind == $HcomEneCs) ||
	    ($kind == $HcomEneNF) ||
	    ($kind == $HcomConden) ||
	    ($kind == $HcomFoodim) ||
	    ($kind == $HcomFarmcpc) ||
	    ($kind == $HcomCollege) ||
	    ($kind == $HcomFactory) ||
	    ($kind == $HcomBase) ||
	    ($kind == $HcomMonument) ||
	    ($kind == $HcomHaribote) ||
	    ($kind == $HcomMonbuy) ||
	    ($kind == $HcomMonbuyt) ||
            ($kind == $HcomPark) ||
            ($kind == $HcomZoo) ||
            ($kind == $HcomMine) ||
            ($kind == $HcomNursery) ||
            ($kind == $HcomKyujo) ||
            ($kind == $HcomUmiamu) ||
            ($kind == $HcomNewtown) ||
            ($kind == $HcomRizort) ||
            ($kind == $HcomYoyaku) ||
            ($kind == $HcomYakusho) ||
            ($kind == $HcomKura) ||
            ($kind == $HcomKuraf) ||
            ($kind == $HcomKura2) ||
            ($kind == $HcomTrain) ||
	    ($kind == $HcomDbase)) {

	# �Ͼ���߷�
	if(!
	   (($landKind == $HlandPlains) ||
	    ($landKind == $HlandPlains2) ||
	    ($landKind == $HlandTown) ||
	    (($landKind == $HlandMinato) && ($kind == $HcomMinato)) ||
	    (($landKind == $HlandPark) && ($kind == $HcomPark)) ||
	    (($landKind == $HlandZoo) && ($kind == $HcomZoo)) ||
	    (($landKind == $HlandIce) && ($kind == $HcomPark)) ||
	    (($landKind == $HlandUmiamu) && ($kind == $HcomUmiamu)) ||
	    (($landKind == $HlandSea) && ($lv == 0) && ($kind == $HcomUmiamu)) ||
	    (($landKind == $HlandMonument) && ($kind == $HcomMonument)) ||
	    (($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
	    (($landKind == $HlandEneAt) && ($kind == $HcomEneAt)) ||
	    (($landKind == $HlandEneFw) && ($kind == $HcomEneFw)) ||
	    (($landKind == $HlandEneWt) && ($kind == $HcomEneWt)) ||
	    (($landKind == $HlandEneWd) && ($kind == $HcomEneWd)) ||
	    (($landKind == $HlandEneBo) && ($kind == $HcomEneBo)) ||
	    (($landKind == $HlandEneSo) && ($kind == $HcomEneSo)) ||
	    (($landKind == $HlandEneCs) && ($kind == $HcomEneCs)) ||
	    (($landKind == $HlandFarmchi) && ($kind == $HcomFarmcpc)) ||
	    (($landKind == $HlandFarmpic) && ($kind == $HcomFarmcpc)) ||
	    (($landKind == $HlandFarmcow) && ($kind == $HcomFarmcpc)) ||
	    (($landKind == $HlandCollege) && ($kind == $HcomCollege)) ||
	    (($landKind == $HlandFoodim) && ($kind == $HcomFoodim)) ||
	    (($landKind == $HlandFactory) && ($kind == $HcomFactory)) ||
            (($landKind == $HlandSea) && ($lv == 1) && ($kind == $HcomNursery)) ||
            (($landKind == $HlandCollege) && ($lv == 77) && ($kind == $HcomYakusho)) ||
            (($landKind == $HlandCollege) && ($lv == 78) && ($kind == $HcomYakusho)) ||
            (($landKind == $HlandCollege) && ($lv == 79) && ($kind == $HcomYakusho)) ||
            (($landKind == $HlandCollege) && ($lv == 80) && ($kind == $HcomYakusho)) ||
            (($landKind == $HlandNursery) && ($kind == $HcomNursery)) ||
            (($landKind == $HlandKura) && ($kind == $HcomKura)) ||
            (($landKind == $HlandKuraf) && ($kind == $HcomKuraf)) ||
            (($landKind == $HlandKura) && ($kind == $HcomKura2)) ||
            (($landKind == $HlandKuraf) && ($kind == $HcomKura2)) ||
	    (($landKind == $HlandTrain) && ($lv == 0) && ($kind == $HcomTrain)) ||
	    (($landKind == $HlandDefence) && ($kind == $HcomDbase)))) {
	    # ��Ŭ�����Ϸ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	# �����ʬ��
	if($kind == $HcomPlant) {
	    # ��Ū�ξ��򿹤ˤ��롣
	    $land->[$x][$y] = $HlandForest;
	    $landValue->[$x][$y] = 1; # �ڤϺ���ñ��
	    logPBSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomMonbuy) {
	    # ��Ū�ξ�����äˤ��롣
	    $kind = random($HmonsterLevel3) + 1;
	    $lv = $lv = ($kind << 4)
		+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
	    $land->[$x][$y] = $HlandMonster;
	    $landValue->[$x][$y] = $lv;
	    # ���þ���
	    my($mKind, $mName, $mHp) = monsterSpec($lv);
	    # ��å�����
	    logMonsFree($id, $name, $mName, $point);
	} elsif($kind == $HcomMonbuyt) {
	    # ��Ū�ξ�����äˤ��롣
	    $kind = 29;
	    $lv = $lv = ($kind << 4)
		+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
	    $land->[$x][$y] = $HlandMonster;
	    $landValue->[$x][$y] = $lv;
	    # ���þ���
	    my($mKind, $mName, $mHp) = monsterSpec($lv);
	    # ��å�����
	    logMonsFree($id, $name, $mName, $point);
	} elsif($kind == $HcomBase) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
	    # ��Ū�ξ���ߥ�������Ϥˤ��롣
	    $land->[$x][$y] = $HlandBase;
	    $landValue->[$x][$y] = 0; # �и���0
	    logPBSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomHaribote) {
	    # ��Ū�ξ���ϥ�ܥƤˤ���
	    $land->[$x][$y] = $HlandHaribote;
	    $landValue->[$x][$y] = 0;
	    logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);
        } elsif($kind == $HcomPark) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
            # ��Ū�ξ���ͷ���Ϥˤ���
	    if($landKind == $HlandPark) {
		# ���Ǥ�ͷ���Ϥξ��
		$landValue->[$x][$y] += 30; # ���� + 10000��
		if($landValue->[$x][$y] > 100) {
		    $landValue->[$x][$y] = 100; # ���� 100000��
		}
	    } elsif($landKind == $HlandIce) {
		# ���Ǥ�ͷ���Ϥξ��
		$landValue->[$x][$y] += 25; # ���� + 10000��
		if($landValue->[$x][$y] > 100) {
		    $landValue->[$x][$y] = 100; # ���� 100000��
		}
	    } else {
		# ��Ū�ξ���ͷ���Ϥ�
		$land->[$x][$y] = $HlandPark;
		$landValue->[$x][$y] = 10; # ���� = 10000��
		$island->{'par'}++;
	    }
	    logLandSuc($id, $name, $comName, $point);
        } elsif($kind == $HcomZoo) {

        if ($arg > 30) {
            $arg = 30;
        }

	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
            # ��Ū�ξ���ͷ���Ϥˤ���
	    if($landKind == $HlandZoo) {

		$etc6 = $island->{'etc6'};
		$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);


		$nigekaiju = $arg;
		$nigeflag = 0;
	            if ($z->{"$nigekaiju"} > 0) {

			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
			    $sx = $x + $ax[$i];
			    $sy = $y + $ay[$i];

			    # �Ԥˤ�����Ĵ��
			    if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			    }

			    $landKind = $land->[$sx][$sy];
			    $lv = $landValue->[$sx][$sy];
			    $point = "($sx, $sy)";

			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {
			    } else {
				# �ϰ���ξ��
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandSea) ||
				   ($landKind == $HlandIce) ||
				   ($landKind == $HlandOil) ||
				   ($landKind == $HlandFune) ||
				   ($landKind == $HlandFrocity) ||
				   ($landKind == $HlandUmiamu) ||
				   ($landKind == $HlandSeacity) ||
				   ($landKind == $HlandSeatown) ||
				   ($landKind == $HlandMonster) ||
				   ($landKind == $HlandZoo) ||
				   ($landKind == $HlandUmishuto) ||
				   ($landKind == $HlandSbase)) {
				} else {
					if ($nigeflag < 1) {
						$nigeflag++;
						$z->{"$nigekaiju"} -= 1;
						$kind = $nigekaiju;
						$lv = $lv = ($kind << 4)
						+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
						$land->[$sx][$sy] = $HlandMonster;
						$landValue->[$sx][$sy] = $lv;
						my($mKind, $mName, $mHp) = monsterSpec($lv);
						logNige2($id, $name, landName($landKind, $lv), $mName, "($x, $y)");
						$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
					}
				}
			    }
			}


				if ($nigeflag < 1) {
				    $kind = $nigekaiju;
				    $lv = ($kind << 4)
					+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				    # �ɤ��˸���뤫����
				    my($bx, $by, $i);
				    for($i = 0; $i < $HpointNumber; $i++) {
					$bx = $Hrpx[$i];
					$by = $Hrpy[$i];
					if(($land->[$bx][$by] == $HlandTown) ||
					   ($land->[$bx][$by] == $HlandBigtown) ||
					   ($land->[$bx][$by] == $HlandBettown) ||
					   ($land->[$bx][$by] == $HlandSkycity) ||
					   ($land->[$bx][$by] == $HlandUmicity) ||
					   ($land->[$bx][$by] == $HlandRizort) ||
					   ($land->[$bx][$by] == $HlandKajino) ||
					   ($land->[$bx][$by] == $HlandBigRizort) ||
					   ($land->[$bx][$by] == $HlandNewtown)) {
			
					    # �Ϸ�̾
					    my($lName) = landName($HlandTown, $landValue->[$bx][$by]);

					    # ���Υإå�������ä�
					    $land->[$bx][$by] = $HlandMonster;
					    $landValue->[$bx][$by] = $lv;

					    $z->{"$nigekaiju"} -= 1;
					    $island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

					    # ���þ���
					    my($mKind, $mName, $mHp) = monsterSpec($lv);

					    # ��å�����
					    logMonsCome($id, $name, $mName, "($bx, $by)", $lName);
					    last;
					}
				    }
	            		}


	            }
			return 0;
	    } else {
		# ��Ū�ξ���ͷ���Ϥ�
		$land->[$x][$y] = $HlandZoo;
		$landValue->[$x][$y] = 10; # ���� = 10000��

		    if($island->{'zoo'} < 1) {
			my($first);
			$first = 1;
			while((random(5) != 0) || ($first == 1)) {
			    $first = 0;
			    $mKind = random(12);

			$etc6 = $island->{'etc6'};
			$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
			($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

			$z->{"$mKind"}++;
			$island->{'zoo'}++;
			$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
			}
		    }

	    }
	    logLandSuc($id, $name, $comName, $point);
        } elsif($kind == $HcomMine) {
            # ��Ū�ξ�������ˤ���
            if ($arg == 0) {
                $arg = 1;
            } elsif ($arg > 9) {
                $arg = 9;
            }
            $arg = min($arg, int($island->{'money'} / $cost));
            $cost *= $arg;
            $land->[$x][$y] = $HlandMine;
            $landValue->[$x][$y] = $arg;
            logPBSuc($id, $name, $comName, $point);
        } elsif($kind == $HcomConden) {
            if ($arg == 0) {
                $arg = 1;
            } elsif ($arg >= 2) {
                $arg = 2;
            }
            $arg = min($arg, int($island->{'money'} / $cost));
            $cost *= $arg;
            if ($arg == 1) {
            $land->[$x][$y] = $HlandConden;
            } elsif ($arg == 2) {
            $land->[$x][$y] = $HlandConden2;
            }
            $landValue->[$x][$y] = 0;
            logLandSuc($id, $name, $comName, $point);
        } elsif($kind == $HcomTrain) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
            if ($arg > 9) {
                $arg = 0;
            }
            if(($landKind == $HlandTrain) && ($lv == 0) && ($arg == 1)) {
	            $landValue->[$x][$y] = 10;
            } elsif (($landKind == $HlandTrain) && ($lv == 0) && ($arg == 2)) {
	            $landValue->[$x][$y] = 20;
            } else {
		$land->[$x][$y] = $HlandTrain;
		$landValue->[$x][$y] = $arg;
            }
            logLandSuc($id, $name, $comName, $point);

        } elsif($kind == $HcomKura) {
            if ($arg == 0) {
                $arg = 1;
            }

	    $seq = int($lv/100);
	    $choki = $lv%100;
            $arg = min($arg, int($island->{'money'} / $cost));
            $cost *= $arg;

	    if($landKind == $HlandKura) {
		$choki += $arg;
		if($choki > 99) {
		    $choki = 99;
		}
		$landValue->[$x][$y] = $seq*100+$choki;
            } else {
		$land->[$x][$y] = $HlandKura;
		$landValue->[$x][$y] = $seq*100+$arg;
	    }

            logLandSuc($id, $name, $comName, $point);

        } elsif($kind == $HcomKuraf) {
	    if ($arg == 0) {
	        $arg = 1;
	    } elsif ($arg > 9) {
	        $arg = 9;
	    }

	    $choki = int($lv/10);
	    $kibo = $lv%10;
            $arg = min($arg, int($island->{'food'} / -$cost));
            $cost *= $arg;

	    if($landKind == $HlandKuraf) {
		$choki += $arg;
		if($choki > 400-40*(9-$kibo)) {
		    $choki = 400-40*(9-$kibo);
		}
		$landValue->[$x][$y] = $choki*10+$kibo;
            } else {
		$choki = 0;
		$kibo = 0;
		$land->[$x][$y] = $HlandKuraf;
		$landValue->[$x][$y] = $arg*10;
	    }
	    $island->{'food'} -= 10000*$arg;
            logLandSuc($id, $name, $comName, $point);

        } elsif($kind == $HcomKura2) {
            if ($arg == 0) {
                $arg = 1;
            }

	    $seq = int($lv/100);
	    $choki = $lv%100;
            if ($arg > $choki) {
                $arg = $choki;
            }
            $cost *= $arg;

	    if($landKind == $HlandKura) {
		$choki -= $arg;
		if($choki < 0) {
		    $choki = 0;
		}
		$landValue->[$x][$y] = $seq*100+$choki;
		$island->{'money'} += 10000*$arg;
		logLandSuc($id, $name, $comName, $point);
                return 0;

            } elsif($landKind == $HlandKuraf) {
		    if ($arg == 0) {
		        $arg = 1;
		    } elsif ($arg > 9) {
		        $arg = 9;
		    }
	    $choki = int($lv/10);
	    $kibo = $lv%10;
            if ($arg > $choki) {
                $arg = $choki;
            }
            $cost *= $arg;

		$choki -= $arg;
		if($choki < 0) {
		    $choki = 0;
		}
		$landValue->[$x][$y] = $choki*10+$kibo;
		$island->{'food'} += 10000*$arg;
		logLandSuc($id, $name, $comName, $point);
                return 0;

            } else {
                # ��Ŭ�����Ϸ�
                logLandFail($id, $name, $comName, $landName, $point);
                return 0;
	    }

        } elsif($kind == $HcomYoyaku) {
                $jikkouarg ++;
            $jikkouarg = min($jikkouarg, int($island->{'money'} / $cost));
            $cost *= $jikkouarg;
            $cost *= $jikkouarg;
            $land->[$x][$y] = $HlandPlains2;
            $landValue->[$x][$y] = 0;
            logLandSuc($id, $name, $comName, $point);
	    return 0;
        } elsif($kind == $HcomNursery) {
            # �ܿ���
            if($landKind == $HlandNursery) {
                # ���Ǥ��ܿ���ξ��
                $landValue->[$x][$y] += 5; # ���� + 5000��
                if($landValue->[$x][$y] > 100) {
                    $landValue->[$x][$y] = 100; # ���� 100000��
                }
            } elsif(($landKind == $HlandSea) && ($lv == 1)) {
                # ��Ū�ξ����ܿ����
                $land->[$x][$y] = $HlandNursery;
                $landValue->[$x][$y] = 20; # ���� = 20000��
            } else {
                # ��Ŭ�����Ϸ�
                logLandFail($id, $name, $comName, $landName, $point);
                return 0;
            }
            logLandSuc($id, $name, $comName, $point);
        } elsif($kind == $HcomYakusho) {
	my($shutoCount) =
	    countAround($land, $x, $y, $HlandShuto, 7) +
	    countAround($land, $x, $y, $HlandUmishuto, 7);

	    if(($island->{'shu'} == 0) || ($shutoCount == 0)) {
		logJoFail($id, $name, $comName, $landName, $point);
		return 0;
	    }

            if(($landKind == $HlandCollege) && ($lv == 77) && ($costseisaku > 35)) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 78;
		logLandSuc($id, $name, $comName, $point);
            } elsif(($landKind == $HlandCollege) && ($lv == 78) && ($costseisaku > 60)) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 79;
		logLandSuc($id, $name, $comName, $point);
            } elsif(($landKind == $HlandCollege) && ($lv == 79) && ($costseisaku > 110)) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 80;
		logLandSuc($id, $name, $comName, $point);
            } elsif($landKind == $HlandCollege) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 77;
		logLandSuc($id, $name, $comName, $point);
            } else {
		$land->[$x][$y] = $HlandYakusho;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
            }

        } elsif($kind == $HcomKyujo) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
            # ��Ū�ξ�������ˤ���
            $land->[$x][$y] = $HlandKyujo;
            $landValue->[$x][$y] = 0;
            logLandSuc($id, $name, $comName, $point);
        } elsif($kind == $HcomNewtown) {
            # ��Ū�ξ�������ˤ���
            $land->[$x][$y] = $HlandNewtown;
            $landValue->[$x][$y] = 1;
            logLandSuc($id, $name, $comName, $point);
        } elsif($kind == $HcomRizort) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
            # ��Ū�ξ�������ˤ���
            $land->[$x][$y] = $HlandRizort;
            $landValue->[$x][$y] = 1;
            logLandSuc($id, $name, $comName, $point);
        } elsif($kind == $HcomUmiamu) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
            # ��Ū�ξ��򳤤��ߤ�ˤ���
	    if($landKind == $HlandUmiamu) {
		# ���Ǥ˳����ߤ�ξ��
		$landValue->[$x][$y] += 30; # ���� + 30000��
		if($landValue->[$x][$y] > 1000) {
		    $landValue->[$x][$y] = 1000; # ���� 1000000��
		}
	    } elsif(($landKind == $HlandSea) && ($lv == 0)) {
		# ��Ū�ξ��򳤤��ߤ��
		$land->[$x][$y] = $HlandUmiamu;
		$landValue->[$x][$y] = 50; # ���� = 50000��
            } else {
                # ��Ŭ�����Ϸ�
                logLandFail($id, $name, $comName, $landName, $point);
                return 0;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomFarm) {
	    # ����
	    if($landKind == $HlandFarm) {
		# ���Ǥ�����ξ��
		$landValue->[$x][$y] += 2; # ���� + 2000��
		if($landValue->[$x][$y] > 50) {
		    $landValue->[$x][$y] = 50; # ���� 50000��
		}
	    } else {
		# ��Ū�ξ��������
		$land->[$x][$y] = $HlandFarm;
		$landValue->[$x][$y] = 10; # ���� = 10000��
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneAt) {
	    if($landKind == $HlandEneAt) {
		$landValue->[$x][$y] += 30;
		if($landValue->[$x][$y] > 1500) {
		    $landValue->[$x][$y] = 1500;
		}
	    } else {
		$land->[$x][$y] = $HlandEneAt;
		$landValue->[$x][$y] = 50;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneFw) {

	my($seaCount) =
	    countAround($land, $x, $y, $HlandSea, 7) +
	    countAround($land, $x, $y, $HlandOil, 7) +
	    countAround($land, $x, $y, $HlandIce, 7) +
	    countAround($land, $x, $y, $HlandSbase, 7) +
	    countAround($land, $x, $y, $HlandFune, 7) +
	    countAround($land, $x, $y, $HlandFrocity, 7) +
            countAround($land, $x, $y, $HlandNursery, 7) +
	    countAround($land, $x, $y, $HlandUmiamu, 7) +
	    countAround($land, $x, $y, $HlandSeatown, 7) +
	    countAround($land, $x, $y, $HlandUmishuto, 7) +
            countAround($land, $x, $y, $HlandSeacity, 7);

	        if($seaCount == 0) {
		    # ���������������Ω����ǽ
		    logNoLandArounde($id, $name, $comName, $point, "��");
		    return 0;
		}

	    if($landKind == $HlandEneFw) {
		$landValue->[$x][$y] += 30;
		if($landValue->[$x][$y] > 500) {
		    $landValue->[$x][$y] = 500;
		}
	    } else {
		$land->[$x][$y] = $HlandEneFw;
		$landValue->[$x][$y] = 20;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneWt) {

	my($mountainCount) =
	    countAround($land, $x, $y, $HlandMountain, 7) +
            countAround($land, $x, $y, $HlandGold, 7);

	        if($mountainCount == 0) {
		    # ���������������Ω����ǽ
		    logNoLandArounde($id, $name, $comName, $point, "��");
		    return 0;
		}

	    if($landKind == $HlandEneWt) {
		$landValue->[$x][$y] += 15;
		if($landValue->[$x][$y] > 250) {
		    $landValue->[$x][$y] = 250;
		}
	    } else {
		$land->[$x][$y] = $HlandEneWt;
		$landValue->[$x][$y] = 10;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneWd) {

	my($PlainsCount) =
	    countAround($land, $x, $y, $HlandPlains, 7) +
            countAround($land, $x, $y, $HlandPlains2, 7);

	        if($PlainsCount == 0) {
		    # ���������������Ω����ǽ
		    logNoLandArounde($id, $name, $comName, $point, "ʿ��");
		    return 0;
		}

	    if($landKind == $HlandEneWd) {
		$landValue->[$x][$y] += 25;
		if($landValue->[$x][$y] > 150) {
		    $landValue->[$x][$y] = 150;
		}
	    } else {
		$land->[$x][$y] = $HlandEneWd;
		$landValue->[$x][$y] = 25;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneBo) {

	my($FoodimCount) = countAround($land, $x, $y, $HlandFoodim, 7);

	        if($FoodimCount == 0) {
		    # ���������������Ω����ǽ
		    logNoLandArounde($id, $name, $comName, $point, "��ʪ�����");
		    return 0;
		}

	    if($landKind == $HlandEneBo) {
		$landValue->[$x][$y] += 50;
		if($landValue->[$x][$y] > 2000) {
		    $landValue->[$x][$y] = 2000;
		}
	    } else {
		$land->[$x][$y] = $HlandEneBo;
		$landValue->[$x][$y] = 100;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneCs) {

	        if($island->{'eis7'} == 0) {
	        logNesEisei($id, $name, $comName);
		    return 0;
		}

	    if($landKind == $HlandEneCs) {
		$landValue->[$x][$y] += 200;
		if($landValue->[$x][$y] > 4000) {
		    $landValue->[$x][$y] = 4000;
		}
	    } else {
		$land->[$x][$y] = $HlandEneCs;
		$landValue->[$x][$y] = 400;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneSo) {

	    if($landKind == $HlandEneSo) {
		$landValue->[$x][$y] += 1000;
		if($landValue->[$x][$y] > 1000) {
		    $landValue->[$x][$y] = 1000;
		}
	    } else {
		$land->[$x][$y] = $HlandEneSo;
		$landValue->[$x][$y] = 1000;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneNF) {
	    $etc9 = $island->{'etc9'};
	    $etc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($co7, $magicf, $magici, $magica, $magicw, $magicl, $magicd) = ($1, $2, $3, $4, $5, $6, $7);
	    if(($magica != $magicl) || ($magicl == 0) || ($island->{'con99'} > 0) || ($island->{'co77'} == 0)) {
		logEiseifail($id, $name, $comName, $point);
		# �����ﳲ�롼����
		wideDamage($id, $name, $land, $landValue, $x, $y);
                return 0;
	    } else {
		$land->[$x][$y] = $HlandConden4;
		$landValue->[$x][$y] = 99;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomFoodim) {
	    if($landKind == $HlandFoodim) {
		# ���Ǥ�����ξ��
		$landValue->[$x][$y] += 10; # ���� + 10000��
		if($landValue->[$x][$y] > 500) {
		    $landValue->[$x][$y] = 500; # ���� 500000��
		}
	    } else {
		# ��Ū�ξ��������
		$land->[$x][$y] = $HlandFoodim;
		$landValue->[$x][$y] = 30; # ���� = 30000��
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomCollege) {

	    if(($landKind == $HlandCollege) && ($lv == 4)) {
		$landValue->[$x][$y] = 96;
		logLandSuc($id, $name, $comName, $point);
                return 0;
	    } elsif(($landKind == $HlandCollege) && ($lv == 98)) {
		$landValue->[$x][$y] = 97;
		logLandSuc($id, $name, $comName, $point);
                return 0;
	    } elsif(($landKind == $HlandCollege) && ($lv == 96)) {
		$landValue->[$x][$y] = 4;
		logLandSuc($id, $name, $comName, $point);
                return 0;
	    } elsif(($landKind == $HlandCollege) && ($lv == 97)) {
		$landValue->[$x][$y] = 98;
		logLandSuc($id, $name, $comName, $point);
                return 0;
	    } elsif(($landKind == $HlandCollege) && ($lv == 6)) {
			if($island->{'money'} < 250000) {
			logNoMoney($id, $name, $comName);
			return 0;
			}
		$landValue->[$x][$y] = 95;
		$island->{'money'} -= 250000;
	    } elsif(($landKind == $HlandCollege) && ($lv == 95)) {
		$landValue->[$x][$y] = 6;
		$island->{'money'} += 250000;
		logLandSuc($id, $name, $comName, $point);
                return 0;
	    } else {
		$land->[$x][$y] = $HlandCollege;
	    if(random(100) < 30) {
		$landValue->[$x][$y] = 0;

		    if(random(100) < 40) {
			$landValue->[$x][$y] = 8;
		    }

	    } elsif(random(100) < 30) {
		$landValue->[$x][$y] = 1;

		    if(random(100) < 30) {
			$landValue->[$x][$y] = 7;
		    }

	    } elsif(random(100) < 25) {
		$landValue->[$x][$y] = 6;
	    } elsif(random(100) < 15) {
		$landValue->[$x][$y] = 2;
	    } elsif(random(100) < 15) {
		$landValue->[$x][$y] = 3;
	    } elsif(random(100) < 15) {
		$landValue->[$x][$y] = 4;
		if(($island->{'co4'} == 0) &&
		   ($island->{'co99'} == 0) &&
		   ($island->{'c28'} == 0)) {
		$island->{'eisei5'} = "3,5,5,5,0,0,0";
		}
	    } else {
		$landValue->[$x][$y] = 5;
	    }
	    }
	    logLandSuc($id, $name, $comName, $point);


		$etc5 = $island->{'etc5'};
		$etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		$s10b = int($s10/5)+1;

		if(($island->{'co77'} > 0) && ($arg < 10) && ($arg != 0) && ($arg-1 < $s10b)) {
			if($arg == 0) {
			    $arg = 1;
			}
		$landValue->[$x][$y] = $arg-1;
		$island->{'money'} -= $arg * 10000;
			if(($arg == 4) &&
			   ($island->{'co4'} == 0) &&
		   	   ($island->{'co99'} == 0) &&
		   	   ($island->{'c28'} == 0)) {
			$island->{'eisei5'} = "3,5,5,5,0,0,0";
			}
		}

	} elsif($kind == $HcomFarmcpc) {
	    # �Ҿ�
	    if(($arg >= 4) ||
	       ($arg == 0)) {
	        $arg = 1;
	    }
	    if(($landKind == $HlandFarmchi) ||
		($landKind == $HlandFarmpic) ||
		($landKind == $HlandFarmcow)) {
		# ���Ǥ��Ҿ�ξ��
		if($landKind == $HlandFarmchi) {
		$island->{'money'} += $lv * 10;
		$land->[$x][$y] = $HlandFarmchi;
		$landValue->[$x][$y] = 1;
	        } elsif($landKind == $HlandFarmpic) {
		$island->{'money'} += $lv * 20;
		$land->[$x][$y] = $HlandFarmpic;
		$landValue->[$x][$y] = 1;
	        } elsif($landKind == $HlandFarmcow) {
		$island->{'money'} += $lv * 50;
		$land->[$x][$y] = $HlandFarmcow;
		$landValue->[$x][$y] = 1;
	        }
		logLandSuc($id, $name, $comName, $point);
	        $cost *= 0;
		return 0;
	    } else {
		if($arg == 1) {
		$land->[$x][$y] = $HlandFarmchi;
		$landValue->[$x][$y] = 1;
	        } elsif($arg == 2) {
		$land->[$x][$y] = $HlandFarmpic;
		$landValue->[$x][$y] = 1;
	        } elsif($arg == 3) {
		$land->[$x][$y] = $HlandFarmcow;
		$landValue->[$x][$y] = 1;
	        }
		# ��򺹤�����
	        $arg = min($arg, int($island->{'money'} / $cost));
	        $cost *= $arg;
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomFactory) {
	    # ����
	    if($landKind == $HlandFactory) {
		# ���Ǥ˹���ξ��
		$landValue->[$x][$y] += 10; # ���� + 10000��
		if($landValue->[$x][$y] > 100) {
		    $landValue->[$x][$y] = 100; # ���� 100000��
		}
	    } else {
		# ��Ū�ξ��򹩾��
		$land->[$x][$y] = $HlandFactory;
		$landValue->[$x][$y] = 30; # ���� = 10000��
	    }
	    logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomDbase) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
	    # �ɱһ���
	    if($landKind == $HlandDefence) {
		# ���Ǥ��ɱһ��ߤξ��
		$landValue->[$x][$y] = 1; # �������֥��å�
		logBombSet($id, $name, $landName, $point);
	    } else {
		# ��Ū�ξ����ɱһ��ߤ�
		$land->[$x][$y] = $HlandDefence;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
	    }
	} elsif($kind == $HcomMonument) {
	    # ��ǰ��
	    if($landKind == $HlandMonument) {
		# ���Ǥ˵�ǰ��ξ��
		# �������åȼ���
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
		    # �������åȤ����Ǥˤʤ�
		    # ������鷺�����
		    return 0;
		}
		my($tIsland) = $Hislands[$tn];

                # ����ο͸������ʤ�������ɸ��ο͸������ʤ��ʤ顢�¹Ԥϵ��Ĥ���ʤ�
                if (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) {
                    logForbidden($id, $name, $comName);
                    return 0;
                }

		if($lovePeace == 1) {
		$island->{'bigmissile'}++;
		$island->{'money'} = 0;

		    my($i,$sx,$sy);
		    for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
		    if($land->[$sx][$sy] == $HlandSbase) {
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
		    } elsif(($land->[$sx][$sy] == $HlandBase) ||
			    ($land->[$sx][$sy] == $HlandMonument)) {
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;

		    }
		}
		logNiwaren($id, $name);

	        } else {
		$tIsland->{'bigmissile'}++;
	        }

		# ���ξ��Ϲ��Ϥ�
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
		logMonFly($id, $name, $landName, $point);
	    } else {
		# ��Ū�ξ���ǰ���
		$land->[$x][$y] = $HlandMonument;

		my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
		my $day = ('��','��','��','��','��','��','��')[$wday];
		$year = $year + 1900;
		$mon = $mon + 1;
		my $date = sprintf("%04d/%02d/%02d(%s) %02d:%02d:%02d",$year,$mon,$mday,$day,$hour,$min,$sec);

		if(($arg == 88) && ($mon > 2) && ($mon < 6)) {
		    $arg = 88;
		}

		elsif(($arg == 73) && ($mon > 2) && ($mon < 6)) {
		    $arg = 73;
		}

		elsif(($arg == 89) && ($mon > 5) && ($mon < 9)) {
		    $arg = 89;
		}

		elsif(($arg == 94) && ($mon > 5) && ($mon < 9)) {
		    $arg = 94;
		}

		elsif(($arg == 90) && ($mon > 8) && ($mon < 12)) {
		    $arg = 90;
		}

		elsif(($arg == 92) && ($mon > 11) && ($mon < 3)) {
		    $arg = 92;
		}

		elsif(($arg == 85) && ($mon == 12) && ($mday == 24)) {
		    $arg = 85;
		}

		elsif(($arg == 91) && ($mon == 12) && ($mday == 25)) {
		    $arg = 91;
		}

		elsif(($arg == 95) && ($mon == 12)) {
		    $arg = 95;
		}

		elsif($arg >= $HmonumentNumber) {
		    $arg = 0;
		}
		$landValue->[$x][$y] = $arg;
		logLandSuc($id, $name, $comName, $point);
	    }
	}

	# ��򺹤�����
	$island->{'money'} -= $cost;

	# ����դ��ʤ顢���ޥ�ɤ��᤹
	if(($kind == $HcomFarm) ||
           ($kind == $HcomFoodim) ||
           ($kind == $HcomNursery) ||
           ($kind == $HcomEneAt) ||
           ($kind == $HcomEneFw) ||
           ($kind == $HcomEneWt) ||
           ($kind == $HcomEneWd) ||
           ($kind == $HcomEneBo) ||
           ($kind == $HcomEneSo) ||
           ($kind == $HcomEneCs) ||
           ($kind == $HcomPark) ||
           ($kind == $HcomUmiamu) ||
	   ($kind == $HcomFactory)) {
	    if($arg > 1) {
		my($command);
		$arg--;
		slideBack($comArray, 0);
		$comArray->[0] = {
		    'kind' => $kind,
		    'target' => $target,
		    'x' => $x,
		    'y' => $y,
		    'arg' => $arg
		    };
	    }
	}

	return 1;
    } elsif($kind == $HcomMountain) {
	# �η���
            if($landKind == $HlandMountain) {
                # ���Ǥ˺η���ξ��
                $landValue->[$x][$y] += 5; # ���� + 5000��
                if($landValue->[$x][$y] > 200) {
                    $landValue->[$x][$y] = 200; # ���� 200000��
                }
            } elsif($landKind == $HlandGold) {
                # ���Ǥ˶⻳�ξ��
                $landValue->[$x][$y] += 20; # ���� + 20000��
                if($landValue->[$x][$y] > 200) {
                    $landValue->[$x][$y] = 200; # ���� 200000��
                }
            } else {
                # ��Ŭ�����Ϸ�
                logLandFail($id, $name, $comName, $landName, $point);
                return 0;
            }
            logLandSuc($id, $name, $comName, $point);

	# ��򺹤�����
	$island->{'money'} -= $cost;
	if($arg > 1) {
	    my($command);
	    $arg--;
	    slideBack($comArray, 0);
	    $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}

	    if(random(1000) < 9) {
		my($v) = 1000 + random(4001);
		$island->{'money'} += $v;
		$land->[$x][$y] = $HlandGold;
		logGold($id, $name, $comName, $v);

	    if($island->{'sin'} > 0) {
	    my($value, $str);
	    $value = random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logSinMoney($id, $name, $str);
	    }
	    if($island->{'jin'} > 0) {
	    my($value, $str);
	    $value = random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logJinMoney($id, $name, $str);
	    }

	    }

	return 1;

    } elsif($kind == $HcomHTget) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
	# �ϥ��ƥ�
            if($landKind == $HlandHTFactory) {
                # ���Ǥ˺η���ξ��
                $landValue->[$x][$y] += 10; # ���� + 10000��
                if($landValue->[$x][$y] > 500) {
                    $landValue->[$x][$y] = 500; # ���� 500000��
                }
            } elsif($landKind == $HlandFactory) {
			if($lv == 100) {
			    $land->[$x][$y] = $HlandHTFactory;
			} else {
			logJoFail($id, $name, $comName, $landName, $point);
			return 0;
			}
            } else {
                # ��Ŭ�����Ϸ�
                logLandFail($id, $name, $comName, $landName, $point);
                return 0;
            }
            logLandSuc($id, $name, $comName, $point);

	# ��򺹤�����
	$island->{'money'} -= $cost;
	if($arg > 1) {
	    my($command);
	    $arg--;
	    slideBack($comArray, 0);
	    $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;

	} elsif($kind == $HcomHouse) {
	    if($island->{'hou'} > 0) {
		$island->{'eisei1'} = $arg;
	        logLandSuc($id, $name, $comName, $point);
                return 0;

	    } else {
		if(!
		   (($landKind == $HlandPlains) ||
		    ($landKind == $HlandPlains2) ||
		    ($landKind == $HlandTown))) {
		    # ��Ŭ�����Ϸ�
		    logLandFail($id, $name, $comName, $landName, $point);
		    return 0;
		} else {
		if($arg == 0) {
		   $arg = 5;
		}
		$island->{'eisei1'} = $arg;
		$land->[$x][$y] = $HlandHouse;



	        if($island->{'pts'} > $HouseLevel9) {
		    $landValue->[$x][$y] = 9;
	        } elsif($island->{'pts'} > $HouseLevel8) {
	 	    $landValue->[$x][$y] = 8;
	        } elsif($island->{'pts'} > $HouseLevel7) {
		    $landValue->[$x][$y] = 7;
	        } elsif($island->{'pts'} > $HouseLevel6) {
	 	    $landValue->[$x][$y] = 6;
	        } elsif($island->{'pts'} > $HouseLevel5) {
		    $landValue->[$x][$y] = 5;
	        } elsif($island->{'pts'} > $HouseLevel4) {
	 	    $landValue->[$x][$y] = 4;
	        } elsif($island->{'pts'} > $HouseLevel3) {
		    $landValue->[$x][$y] = 3;
	        } elsif($island->{'pts'} > $HouseLevel2) {
	 	    $landValue->[$x][$y] = 2;
	        } elsif($island->{'pts'} > $HouseLevel1) {
		    $landValue->[$x][$y] = 1;
	        } else {
		    $landValue->[$x][$y] = 0;
	        }
		logLandSuc($id, $name, $comName, $point);
		# ��򺹤�����
		$island->{'money'} -= $cost;
		return 1;
		}
	    }

	} elsif($kind == $HcomBettown) {
	my($shutoCount) =
	    countAround($land, $x, $y, $HlandShuto, 7) +
	    countAround($land, $x, $y, $HlandUmishuto, 7);
	my($betCount) =
	    countAround($land, $x, $y, $HlandBettown, 7);

		if($landKind != $HlandBigtown){
		    # ��Ŭ�����Ϸ�
		    logLandFail($id, $name, $comName, $landName, $point);
		    return 0;
		}

			if(($island->{'shu'} > 0) &&
			  (($shutoCount > 0) ||
			   ($betCount > 1))) {
			    $land->[$x][$y] = $HlandBettown;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
			} else {
			logJoFail($id, $name, $comName, $landName, $point);
			return 0;
			}

	} elsif($kind == $HcomKai) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
		if($landKind == $HlandKyujo) {

			if($island->{'ky2'} == 0) {
			$island->{'eisei4'} = "1,1,1,0,0,0,0,0,0,0,10";
			}

		$land->[$x][$y] = $HlandKyujokai;
		$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandKyujokai) {
			$eisei4 = $island->{'eisei4'};
			$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
			$sto++;
			$std++;
			$stk++;
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			if($arg > 1) {
			    my($command);
			    $arg--;
			    slideBack($comArray, 0);
			    $comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
			}
			return 1;
		} elsif(($landKind == $HlandConden4) && ($lv == 2)) {
			$land->[$x][$y] = $HlandConden2;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif(($landKind == $HlandConden4) && ($lv == 3)) {
			$land->[$x][$y] = $HlandConden3;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif(($landKind == $HlandFune) && ($lv == 10)) {
			$landValue->[$x][$y] = 19;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif(($landKind == $HlandFoodim) && ($lv >= 480)) {
			$land->[$x][$y] = $HlandFoodka;
			$landValue->[$x][$y] = 1;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandEneSo) {
			$landValue->[$x][$y] = 1250;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandZoo) {
			$landValue->[$x][$y] += 10;
			if($landValue->[$x][$y] > int($island->{'rena'}/75)) {
			    $landValue->[$x][$y] = int($island->{'rena'}/75);
			}
			if($landValue->[$x][$y] > 200) {
			    $landValue->[$x][$y] = 200;
			}
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			if($arg > 1) {
			    my($command);
			    $arg--;
			    slideBack($comArray, 0);
			    $comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
			}
			return 1;
		} elsif($landKind == $HlandDefence) {
			$landValue->[$x][$y] = 77;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandHTFactory) {
			$land->[$x][$y] = $HlandSHTF;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandSHTF) {
			$land->[$x][$y] = $HlandHTFactory;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandKura) {

		    $seq = int($lv/100);
		    $choki = $lv%100;
			$seq ++;
			if($seq > 9) {
			    $seq = 9;
			}
			$landValue->[$x][$y] = $seq*100+$choki;

			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			if($arg > 1) {
			    my($command);
			    $arg--;
			    slideBack($comArray, 0);
			    $comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
			}
			return 1;

		} elsif($landKind == $HlandKuraf) {

		    $choki = int($lv/10);
		    $kibo = $lv%10;
			$kibo ++;
			if($kibo > 9) {
			    $kibo = 9;
			}
			$landValue->[$x][$y] = $choki*10+$kibo;

			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			if($arg > 1) {
			    my($command);
			    $arg--;
			    slideBack($comArray, 0);
			    $comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
			}
			return 1;

		} elsif($landKind == $HlandRizort) {
		my($seaCount) =
		    countAround($land, $x, $y, $HlandSea, 7) +
		    countAround($land, $x, $y, $HlandOil, 7) +
		    countAround($land, $x, $y, $HlandIce, 7) +
		    countAround($land, $x, $y, $HlandSbase, 7) +
		    countAround($land, $x, $y, $HlandFune, 7) +
		    countAround($land, $x, $y, $HlandFrocity, 7) +
	            countAround($land, $x, $y, $HlandNursery, 7) +
		    countAround($land, $x, $y, $HlandUmiamu, 7) +
		    countAround($land, $x, $y, $HlandSeatown, 7) +
		    countAround($land, $x, $y, $HlandUmishuto, 7) +
	            countAround($land, $x, $y, $HlandSeacity, 7);
		my($rizortCount) =
		    countAround($land, $x, $y, $HlandRizort, 7) +
		    countAround($land, $x, $y, $HlandKajino, 7) +
		    countAround($land, $x, $y, $HlandBigRizort, 7);
            my($value);
            $value = $lv+$island->{'eis1'}+$island->{'eis2'}+$island->{'eis3'}+$island->{'eis5'}+int($island->{'fore'}/10)+int($island->{'rena'}/10)-$island->{'monsterlive'}*100;
			if(($seaCount > 1) &&
			   ($value > 500) &&
			   ($rizortCount > 2)) {
			    $land->[$x][$y] = $HlandBigRizort;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
			} else {
			logJoFail($id, $name, $comName, $landName, $point);
			return 0;
			}

		} elsif($landKind == $HlandBigRizort) {
			if($island->{'rena'} < 15000) {
			logJo2Fail($id, $name, $comName, $landName, $point);
			return 0;
			} else {
			$land->[$x][$y] = $HlandKajino;
			logLandSuc($id, $name, $comName, $point);
			# ��򺹤�����
			$island->{'money'} -= $cost;
			return 1;
			}

		} else {
		    # ��Ŭ�����Ϸ�
		    logLandFail($id, $name, $comName, $landName, $point);
		    return 0;
		}

    } elsif($kind == $HcomSbase) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
	# �������
	if(($landKind != $HlandSea) || ($lv != 0)){
	    # ���ʳ��ˤϺ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	$land->[$x][$y] = $HlandSbase;
	$landValue->[$x][$y] = 0; # �и���0
	logLandSuc($id, $name, $comName, '(?, ?)');

	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;
    } elsif($kind == $HcomSeacity) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
	# �����Ի�
	if(($landKind != $HlandSea) || ($lv != 0)){
	    # ���ʳ��ˤϺ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	$land->[$x][$y] = $HlandSeacity;
	$landValue->[$x][$y] = 0; # �͸�0
	logLandSuc($id, $name, $comName, '(?, ?)');

	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;
    } elsif($kind == $HcomProcity) {
	# �ɺҲ�
	if(($landKind != $HlandTown) || ($lv != 100)){
	    # ���ʳ��ˤϺ��ʤ�
	    logLandFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	$land->[$x][$y] = $HlandProcity;
	$landValue->[$x][$y] = 100; # �и���0
	logLandSuc($id, $name, $comName, $point);

	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;
    } elsif($kind == $HcomBigtown) {
	# ���岽
	if(($landKind != $HlandNewtown) || ($lv < 149)){
	    # ���ʳ��ˤϺ��ʤ�
	    logJoFail($id, $name, $comName, $landName, $point);
	    return 0;
	}
	my($townCount) =
	    countAround($land, $x, $y, $HlandTown, 19) +
	    countAround($land, $x, $y, $HlandProcity, 19) +
            countAround($land, $x, $y, $HlandNewtown, 19) +
	    countAround($land, $x, $y, $HlandBigtown, 19) +
	    countAround($land, $x, $y, $HlandBettown, 19) +
	    countAround($land, $x, $y, $HlandSkycity, 19) +
	    countAround($land, $x, $y, $HlandUmicity, 19) +
	    countAround($land, $x, $y, $HlandSeatown, 19) +
	    countAround($land, $x, $y, $HlandRizort, 19) +
	    countAround($land, $x, $y, $HlandKajino, 19) +
	    countAround($land, $x, $y, $HlandBigRizort, 19) +
	    countAround($land, $x, $y, $HlandShuto, 19) +
	    countAround($land, $x, $y, $HlandUmishuto, 19) +
	    countAround($land, $x, $y, $HlandMinato, 19) +
	    countAround($land, $x, $y, $HlandFrocity, 19) +
	    countAround($land, $x, $y, $HlandOnsen, 19) +
            countAround($land, $x, $y, $HlandSeacity, 19);
        if($townCount < 16) {
	    # ���������������Ω����ǽ
	    logJoFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	$land->[$x][$y] = $HlandBigtown;
	logLandSuc($id, $name, $comName, $point);

	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;
    } elsif($kind == $HcomSeatown) {
	# ���岽
	if(($landKind != $HlandSeacity) || ($lv < 200)){
	    # ���ʳ��ˤϺ��ʤ�
	    logJoFail($id, $name, $comName, $landName, '(?, ?)');
	    return 0;
	}
	my($townCount) =
	    countAround($land, $x, $y, $HlandTown, 19) +
	    countAround($land, $x, $y, $HlandProcity, 19) +
            countAround($land, $x, $y, $HlandNewtown, 19) +
	    countAround($land, $x, $y, $HlandBigtown, 19) +
	    countAround($land, $x, $y, $HlandBettown, 19) +
	    countAround($land, $x, $y, $HlandSkycity, 19) +
	    countAround($land, $x, $y, $HlandUmicity, 19) +
	    countAround($land, $x, $y, $HlandSeatown, 19) +
	    countAround($land, $x, $y, $HlandRizort, 19) +
	    countAround($land, $x, $y, $HlandKajino, 19) +
	    countAround($land, $x, $y, $HlandBigRizort, 19) +
	    countAround($land, $x, $y, $HlandShuto, 19) +
	    countAround($land, $x, $y, $HlandUmishuto, 19) +
	    countAround($land, $x, $y, $HlandMinato, 19) +
	    countAround($land, $x, $y, $HlandFrocity, 19) +
	    countAround($land, $x, $y, $HlandOnsen, 19) +
            countAround($land, $x, $y, $HlandSeacity, 19);
        if($townCount < 16) {
	    # ���������������Ω����ǽ
	    logJoFail($id, $name, $comName, $landName, '(?, ?)');
	    return 0;
	}

	$land->[$x][$y] = $HlandSeatown;
	logLandSuc($id, $name, $comName, '(?, ?)');

	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;
    } elsif($kind == $HcomBoku) {
	# �ͤΰ��ۤ�
	if($landKind != $HlandProcity){
	    # ���ʳ��ˤϺ��ʤ�
	    logBokuFail($id, $name, $comName, $landName, $point);
	    return 0;
	}

	# �����Φ�����뤫�����å�
	my($townCount) =
	    countAround($land, $x, $y, $HlandTown, 19);

        if($townCount == 0) {
	    # ���������������Ω����ǽ
	    logNoTownAround($id, $name, $comName, $point);
	    return 0;
	}

	$landValue->[$x][$y] += 10; # ���� + 1000��
	if($landValue->[$x][$y] > 200) {
	    $landValue->[$x][$y] = 200; # ���� 20000��
	}
	    my($i,$sx,$sy);
	    for($i = 1; $i < 19; $i++) {
	        $sx = $x + $ax[$i];
	        $sy = $y + $ay[$i];
	    if($land->[$sx][$sy] == $HlandTown){
	       $landValue->[$sx][$sy] -= int(20/$townCount);
			if($landValue->[$sx][$sy] <= 0) {
			    # ʿ�Ϥ��᤹
			    $land->[$sx][$sy] = $HlandPlains;
			    $landValue->[$sx][$sy] = 0;
			    next;
			}
	    }
	    }
	logLandSuc($id, $name, $comName, $point);

	# ��򺹤�����
	$island->{'money'} -= $cost;
	if($arg > 1) {
	    my($command);
	    $arg--;
	    slideBack($comArray, 0);
	    $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;

    } elsif($kind == $HcomBoku2) {
	# �ͤΰ��ۤ�2

	if($landKind == $HlandMonster) {
	my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	my($special) = $HmonsterSpecial[$mKind];
	    logBokuFail2($id, $name, $comName, $mName, $point);
	return 0;
	}

	if((($landKind == $HlandPlains) || ($landKind == $HlandSea)) && ($island->{'stockflag'} == 55)) {
		$land->[$x][$y] = $island->{'stocklandkind'};
		$landValue->[$x][$y] = $island->{'stocklandvalue'};
		$island->{'pointb'} .= "($x, $y)";
		logLandSuc($id, $name, $comName, $island->{'pointb'});

		if($HislandSize > 16) {
		$sizekeisu = 5;
		} else {
		$sizekeisu = 1;
		}

		if(($island->{'stocklandkind'} == $HlandHouse) && ($island->{'stocklandvalue'} == 9) && ($island->{'co01'} > $sizekeisu) && ($island->{'co8'} > $sizekeisu)) {

		$island->{'condenmekki'} = 0;

                my($i, $sx, $sy, $kind, $lv);
                for($i = 1; $i < 7; $i++) {
                    $sx = $x + $ax[$i];
                    $sy = $y + $ay[$i];

                    # �Ԥˤ�����Ĵ��
                    if((($sy % 2) == 0) && (($y % 2) == 1)) {
                        $sx--;
                    }
		    if(($sx < 0) || ($sx >= $HislandSize) ||
		       ($sy < 0) || ($sy >= $HislandSize)) {
		        # �ϰϳ�
		        next;
		    }

                    $kind = $land->[$sx][$sy];
                    $lv   = $landValue->[$sx][$sy];
		    my($mKind, $mName, $mHp) = monsterSpec($lv);

		    if (($kind == $HlandMonster) && ($mKind == 14)) {
		    $island->{'condenmekki'} = 3;
		    }

		    }

		if ($island->{'condenmekki'} == 3) {

	                my($i, $sx, $sy, $kind, $lv);
	                for($i = 1; $i < 19; $i++) {
	                    $sx = $x + $ax[$i];
	                    $sy = $y + $ay[$i];

	                    # �Ԥˤ�����Ĵ��
	                    if((($sy % 2) == 0) && (($y % 2) == 1)) {
	                        $sx--;
	                    }
			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {
			        # �ϰϳ�
			        next;
			    }

	                    $kind = $land->[$sx][$sy];
	                    $lv   = $landValue->[$sx][$sy];

	                    if ($kind == $HlandConden2) {
	                    $land->[$sx][$sy] = $HlandConden3;
	                    logConsFire($id, $name, landName($kind, $lv), "($sx, $sy)", $comName);
			    return 1;
			    }
			    }

		}

		}

		$island->{'money'} -= $cost;

	return 1;

	} elsif(($landKind == $HlandMountain) && ($island->{'stockflag'} == 55) && ((($island->{'stocklandkind'} == $HlandBettown) && ($island->{'stocklandvalue'} > 1500)) || (($island->{'stocklandkind'} == $HlandKajino) && ($island->{'stocklandvalue'} > 2000)))) {

		$land->[$x][$y] = $HlandSkycity;
		$landValue->[$x][$y] = $island->{'stocklandvalue'};
		$island->{'pointb'} .= "($x, $y)";
		logLandSuc($id, $name, $comName, $island->{'pointb'});

		$island->{'money'} -= $cost;

	return 1;

	} elsif(($landKind == $HlandFrocity) && ($island->{'stockflag'} == 55) && ((($island->{'stocklandkind'} == $HlandBettown) && ($island->{'stocklandvalue'} > 1500)) || (($island->{'stocklandkind'} == $HlandKajino) && ($island->{'stocklandvalue'} > 2000)))) {

		$land->[$x][$y] = $HlandUmicity;
		$landValue->[$x][$y] += $island->{'stocklandvalue'};
		$island->{'pointb'} .= "($x, $y)";
		logLandSuc($id, $name, $comName, $island->{'pointb'});

		$island->{'money'} -= $cost;

	return 1;

	} else {
		$island->{'stocklandkind'} = $land->[$x][$y];
		$island->{'stocklandvalue'} = $landValue->[$x][$y];
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		$island->{'pointb'} = "($x, $y)��";
		$island->{'stockflag'} = 55;
	return 0;
	}


    } elsif($kind == $HcomAuction) {

	$auc6 = $island->{'auc6'};
	$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($auc6a, $auc6x, $auc6y) = ($1, $2, $3);

	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$aucland = $landKind * $lv;

	if($auc6a != 1) {
	    logMsNoEne3($id, $name, $comName);
	    return 0;
	}

	$auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);
	$auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);
	$auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

	if($shuppin1 == 29) {
	    $island->{'auc6'} = "2,$x,$y";
	    $island->{'auc7'} = "$name��($x, $y)��$landName";
	    $auction1 = "30,$id,0,$arg,$aucland";
		$island->{'money'} -= $cost;
		logLandSuc($id, $name, $comName, $point);
		return 1;
	} elsif($shuppin2 == 29) {
	    $island->{'auc6'} = "2,$x,$y";
	    $island->{'auc7'} = "$name��($x, $y)��$landName";
	    $auction2 = "30,$id,0,$arg,$aucland";
		$island->{'money'} -= $cost;
		logLandSuc($id, $name, $comName, $point);
		return 1;
	} elsif($shuppin3 == 29) {
	    $island->{'auc6'} = "2,$x,$y";
	    $island->{'auc7'} = "$name��($x, $y)��$landName";
	    $auction3 = "30,$id,0,$arg,$aucland";
		$island->{'money'} -= $cost;
		logLandSuc($id, $name, $comName, $point);
		return 1;
	}

	    logMsNoEne4($id, $name, $comName);
	    return 0;

    } elsif($kind == $HcomGivefood) {
	# ����
            if($landKind == $HlandMonster) {
	    my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	    my($special) = $HmonsterSpecial[$mKind];
		if($mHp < 10){$lv+=random(5);}
		$landValue->[$x][$y] = $lv;
            } elsif((($landKind == $HlandCollege) && ($lv == 4)) ||
		    (($landKind == $HlandCollege) && ($lv == 96)) ||
		    (($landKind == $HlandCollege) && ($lv == 97)) ||
		    (($landKind == $HlandCollege) && ($lv == 98))) {
		$eisei5 = $island->{'eisei5'};
		$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		    if(rand(100) < 30) {
		    $msap++;
		    } elsif (rand(100) < 30) {
		    $msdp++;
		    } elsif (rand(100) < 30) {
		    $mssp++;
		    } else {
		    $mshp++;
			if($mshp > 15){
			$mshp = 15;
			}
		    }
		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
            } else {
                # ��Ŭ�����Ϸ�
                logLandFail($id, $name, $comName, $landName, $point);
                return 0;
            }
            logLandSuc($id, $name, $comName, $point);

	# ��򺹤�����
	$island->{'food'} += $cost;
	if($arg > 1) {
	    my($command);
	    $arg--;
	    slideBack($comArray, 0);
	    $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;

    } elsif($kind == $HcomEisei) {

	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}

	if($arg == 99) {
	    $arg = 99;
	} elsif(($arg >= 7) ||
	   ($arg == 0)) {
	    $arg = 1;
	}
	if($arg == 1) {
	    if($island->{'m17'} < 1) {
		logNoRoke($id, $name, $comName, $point);
	    return 0;
	    }
	    if($island->{'rena'} < 10) {
		logNoTech($id, $name, $comName, $point);
	    return 0;
	    }
	    if(random(100) > 70+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# ��򺹤�����
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	    return 1;
	    }
	   $island->{'eis1'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 2) {
	    if($island->{'m17'} < 1) {
		logNoRoke($id, $name, $comName, $point);
	    return 0;
	    }
	    if($island->{'rena'} < 40) {
		logNoTech($id, $name, $comName, $point);
	    return 0;
	    }
	    if(random(100) > 50+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# ��򺹤�����
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	    return 1;
	    }
	   $island->{'eis2'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 3) {
	    if($island->{'m17'} < 2) {
		logNoRoke($id, $name, $comName, $point);
	    return 0;
	    }
	    if($island->{'rena'} < 100) {
		logNoTech($id, $name, $comName, $point);
	    return 0;
	    }
	    if(random(1000) > 600+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# ��򺹤�����
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	    return 1;
	    }
	   $island->{'eis3'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 4) {
	    if($island->{'m17'} < 3) {
		logNoRoke($id, $name, $comName, $point);
	    return 0;
	    }
	    if($island->{'rena'} < 250) {
		logNoTech($id, $name, $comName, $point);
	    return 0;
	    }
	    if(random(1000) > 400+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# ��򺹤�����
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	    return 1;
	    }
	   $island->{'eis4'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 5) {
	    if($island->{'m17'} < 4) {
		logNoRoke($id, $name, $comName, $point);
	    return 0;
	    }
	    if($island->{'rena'} < 1000) {
		logNoTech($id, $name, $comName, $point);
	    return 0;
	    }
	    if(random(1000) > 200+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# ��򺹤�����
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	    return 1;
	    }
	   $island->{'eis5'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 6) {
	    if($island->{'m17'} < 10) {
		logNoRoke($id, $name, $comName, $point);
	    return 0;
	    }
	    if($island->{'rena'} < 2000) {
		logNoTech($id, $name, $comName, $point);
	    return 0;
	    }
	    if(random(10000) > 3000+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# ��򺹤�����
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	    return 1;
	    }
	   $island->{'eis6'} = 250;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 99) {
	    if($island->{'money'} < 1000000) {
		logNoMoney($id, $name, $comName);
		return 0;
	    }
	    if($island->{'m17'} < 10) {
		logNoRoke($id, $name, $comName, $point);
	    return 0;
	    }
	    if($island->{'rena'} < 5000) {
		logNoTech($id, $name, $comName, $point);
	    return 0;
	    }
	    if(random(10000) > 3000+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# ��򺹤�����
		$island->{'money'} -= 1000000;
	    return 1;
	    }
	   $island->{'eis7'} = 124;
	logLandSucmini($id, $name, $comName, $point);
	$island->{'money'} -= 1000000;
	return 1;
	}
	
	# ��򺹤�����
	$value = min($arg * ($cost), $island->{'money'});
	$island->{'money'} -= $value;
	return 1;
    } elsif($kind == $HcomEiseimente) {

	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}

	if($arg == 99) {
	    $arg = 99;
	} elsif(($arg >= 6) ||
	   ($arg == 0)) {
	    $arg = 1;
	}
	if($arg == 1) {
	    if($island->{'eis1'} >= 1) {
	       $island->{'eis1'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	    } else {
	    logNoEisei($id, $name, $comName);
		return 0;
	    }
	}
	if($arg == 2) {
	    if($island->{'eis2'} >= 1) {
	       $island->{'eis2'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	    } else {
	    logNoEisei($id, $name, $comName);
		return 0;
	    }
	}
	if($arg == 3) {
	    if($island->{'eis3'} >= 1) {
	       $island->{'eis3'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	    } else {
	    logNoEisei($id, $name, $comName);
		return 0;
	    }
	}
	if($arg == 4) {
	    if($island->{'eis4'} >= 1) {
	       $island->{'eis4'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	    } else {
	    logNoEisei($id, $name, $comName);
		return 0;
	    }
	}
	if($arg == 5) {
	    if($island->{'eis5'} >= 1) {
	       $island->{'eis5'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	    } else {
	    logNoEisei($id, $name, $comName);
		return 0;
	    }
	}
	if($arg == 99) {
	    $eis7 = $island->{'eis7'};
	    $cstpop = int($eis7/100);
	    $csten = $eis7%100;
	    if($csten >= 1) {
	       $csten += 25;

	    if($csten > 99) {
		$csten = 99;
		$cstpop+=100;
	    }
		logLandSucmini($id, $name, $comName, $point);
	       $island->{'eis7'} = $cstpop*100+$csten;
	    } else {
	    logNoEisei($id, $name, $comName);
		return 0;
	    }
	}
	
	# ��򺹤�����
	$island->{'money'} -= $cost;
	return 1;

    } elsif($kind == $HcomEiseiAtt) {
	if($arg == 99) {
	    $arg = 99;
	} elsif(($arg >= 7) ||
	   ($arg == 0)) {
	    $arg = 1;
	}
	# �������åȼ���
	my($tn) = $HidToNumber{$target};
	if($tn eq '') {
	    # �������åȤ����Ǥˤʤ�
	    logMsNoTarget($id, $name, $comName);
	    return 0;
	}
	# ��������
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tEisei1) = $tIsland->{'eis1'};
	my($tEisei2) = $tIsland->{'eis2'};
	my($tEisei3) = $tIsland->{'eis3'};
	my($tEisei4) = $tIsland->{'eis4'};
	my($tEisei5) = $tIsland->{'eis5'};
	my($tEisei6) = $tIsland->{'eis6'};
	my($tEisei7) = $tIsland->{'eis7'};


	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);
	if((($msjotai != 2) ||
	   ($tIsland->{'id'} != $msid)) && ($lovePeace == 1)) {
		logNiwaren3($id, $name, $comName);
		return 1;
        }


	if($island->{'eis6'} >= 1) {
	    if($arg == 1) {
	        if($tEisei1 >= 1) {
		    if(random(100) < 100) {
	               $tIsland->{'eis1'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "���ݱ���");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "���ݱ���");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 2) {
	        if($tEisei2 >= 1) {
		    if(random(100) < 90) {
	               $tIsland->{'eis2'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "��¬����");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "��¬����");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 3) {
	        if($tEisei3 >= 1) {
		    if(random(100) < 80) {
	               $tIsland->{'eis3'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "�޷����");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "�޷����");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 4) {
	        if($tEisei4 >= 1) {
		    if(random(100) < 70) {
	               $tIsland->{'eis4'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "��������");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "��������");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 5) {
	        if($tEisei5 >= 1) {
		    if(random(100) < 60) {
	               $tIsland->{'eis5'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "�ɱұ���");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "�ɱұ���");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 6) {
	        if($tEisei6 >= 1) {
		    if(random(100) < 50) {
	               $tIsland->{'eis6'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "���쥮��顼");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "���쥮��顼");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 99) {
	        if($tEisei7 >= 1) {
			$tcstpop = int($tEisei7/100);
			$tcsten = $tEisei7%100;
			$tdmg = random(100);
			$tcstpop = int($tcstpop*$tdmg/100);
			$tcsten = int($tcsten*$tdmg/100);
			$tIsland->{'eis7'} = $tcstpop*100+$tcsten;
			$tdmg = 100-$tdmg;
	                logEiseiAttcst($id, $tId, $name, $tName, $comName, "���襹�ơ������", $tdmg);

			if($tcsten < $tdmg) {
			$tIsland->{'eis7'} = 0;
			logEiseiEnd($id, $name, "���襹�ơ������");
			}

	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	# ��򺹤�����
        $island->{'eis6'} -= 30;
        if($island->{'eis6'} < 1) {
           $island->{'eis6'} = 0;
		logEiseiEnd($id, $name, "���쥮��顼");
        }
	$island->{'money'} -= $cost;
	return 1;
	}
	elsif($island->{'eis4'} >= 1) {
	    if($arg == 1) {
	        if($tEisei1 >= 1) {
		    if(random(100) < 70) {
	               $tIsland->{'eis1'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "���ݱ���");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "���ݱ���");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 2) {
	        if($tEisei2 >= 1) {
		    if(random(100) < 60) {
	              $tIsland->{'eis2'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "��¬����");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "��¬����");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 3) {
	        if($tEisei3 >= 1) {
		    if(random(100) < 50) {
	               $tIsland->{'eis3'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "�޷����");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "�޷����");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 4) {
	        if($tEisei4 >= 1) {
		    if(random(100) < 40) {
	               $tIsland->{'eis4'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "��������");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "��������");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 5) {
	        if($tEisei5 >= 1) {
		    if(random(100) < 30) {
	               $tIsland->{'eis5'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "�ɱұ���");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "�ɱұ���");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 6) {
	        if($tEisei6 >= 1) {
		    if(random(100) < 20) {
	               $tIsland->{'eis6'} = 0;
	                logEiseiAtts($id, $tId, $name, $tName, $comName, "���쥮��顼");
	            } else {
	                logEiseiAttf($id, $tId, $name, $tName, $comName, "���쥮��顼");
		    }
	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	    if($arg == 99) {
	        if($tEisei7 >= 1) {
			$tcstpop = int($tEisei7/100);
			$tcsten = $tEisei7%100;
			$tdmg = random(100);
			$tcstpop = int($tcstpop*$tdmg/100);
			$tcsten = int($tcsten*$tdmg/100);
			$tIsland->{'eis7'} = $tcstpop*100+$tcsten;
			$tdmg = 100-$tdmg;
	                logEiseiAttcst($id, $tId, $name, $tName, $comName, "���襹�ơ������", $tdmg);

			if($tcsten < $tdmg) {
			$tIsland->{'eis7'} = 0;
			logEiseiEnd($id, $name, "���襹�ơ������");
			}

	        } else {
	        logNoEisei($id, $name, $comName);
		    return 0;
	        }
	    }
	# ��򺹤�����
        $island->{'eis4'} -= 30;
        if($island->{'eis4'} < 1) {
           $island->{'eis4'} = 0;
		logEiseiEnd($id, $name, "��������");
        }
	$island->{'money'} -= $cost;
	return 1;
	} else {
	        logNesEisei($id, $name, $comName);
		    return 0;
        }


    } elsif($kind == $HcomEiseiLzr) {
	my($tn) = $HidToNumber{$target};
	if($tn eq '') {
	    # �������åȤ����Ǥˤʤ�
	    logMsNoTarget($id, $name, $comName);
	    return 0;
	}
	# ��������
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty);


	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);
	if((($msjotai != 2) ||
	   ($tIsland->{'id'} != $msid)) && ($lovePeace == 1)) {
		logNiwaren3($id, $name, $comName);
		return 1;
        }


        # ����ο͸������ʤ�������ɸ��ο͸������ʤ��ʤ顢�¹Ԥϵ��Ĥ���ʤ�
        if (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) {
            logForbidden($id, $name, $comName);
            return 0;
        }
		# ����������
		$err = 1;
		my($r) = random($err);
		$tx = $x + $ax[$r];
		$ty = $y + $ay[$r];
		if((($ty % 2) == 0) && (($y % 2) == 1)) {
		    $tx--;
		}

		# ���������Ϸ�������
		my($tL) = $tLand->[$tx][$ty];
		my($tLv) = $tLandValue->[$tx][$ty];
		my($tLname) = landName($tL, $tLv);
		my($tPoint) = "($tx, $ty)";

	if($island->{'eis6'} >= 1){
	    if(($tL == $HlandSea) ||
	       ($tL == $HlandWaste) ||
	       ($tL == $HlandMountain) ||
	       ($tL == $HlandGold) ||
	       ($tL == $HlandSeacity) ||
	       ($tL == $HlandSeatown) ||
	       ($tL == $HlandUmishuto) ||
	       ($tL == $HlandUmiamu) ||
	       ($tL == $HlandSbase)) {
		logLzrefc($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
	    } elsif(($tL == $HlandOil) ||
	       ($tL == $HlandNursery) ||
	       ($tL == $HlandFrocity) ||
	       ($tL == $HlandIce) ||
	       ($tL == $HlandFune)) {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
                        $tLand->[$tx][$ty] = $HlandSea;
                        $tLandValue->[$tx][$ty] = 1;
	    } elsif($tL == $HlandOnsen) {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
                        $tLand->[$tx][$ty] = $HlandMountain;
                        $tLandValue->[$tx][$ty] = 0;
	    } else {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
                        $tLand->[$tx][$ty] = $HlandWaste;
                        $tLandValue->[$tx][$ty] = 0;
		                if (rand(1000) < 100) {
		                    $land->[$tx][$ty] = $HlandMonument;
		                    $landValue->[$tx][$ty] = 79;
		                }
	    }
	 	$island->{'eis6'} -= 5;
		if($island->{'eis6'} < 1) {
		   $island->{'eis6'} = 0;
		    logEiseiEnd($id, $name, "���쥮��顼");
		}
		$island->{'money'} -= $cost;
		return 1;
	} elsif($island->{'eis4'} >= 1){
	    if(($tL == $HlandSea) ||
	       ($tL == $HlandWaste) ||
	       ($tL == $HlandMountain) ||
	       ($tL == $HlandGold) ||
	       ($tL == $HlandSeacity) ||
	       ($tL == $HlandSeatown) ||
	       ($tL == $HlandUmishuto) ||
	       ($tL == $HlandUmiamu) ||
	       ($tL == $HlandSbase)) {
		logLzrefc($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
	    } elsif(($tL == $HlandOil) ||
	       ($tL == $HlandNursery) ||
	       ($tL == $HlandFrocity) ||
	       ($tL == $HlandIce) ||
	       ($tL == $HlandFune)) {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
                        $tLand->[$tx][$ty] = $HlandSea;
                        $tLandValue->[$tx][$ty] = 1;
	    } elsif($tL == $HlandOnsen) {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
                        $tLand->[$tx][$ty] = $HlandMountain;
                        $tLandValue->[$tx][$ty] = 0;
	    } else {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
                        $tLand->[$tx][$ty] = $HlandWaste;
                        $tLandValue->[$tx][$ty] = 0;
		                if (rand(1000) < 100) {
		                    $land->[$tx][$ty] = $HlandMonument;
		                    $landValue->[$tx][$ty] = 79;
		                }
	    }
	 	$island->{'eis4'} -= 10;
		if($island->{'eis4'} < 1) {
		   $island->{'eis4'} = 0;
		    logEiseiEnd($id, $name, "��������");
		}
		$island->{'money'} -= $cost;
		return 1;
	} else {
	        logNesEisei($id, $name, $comName);
		    return 0;
        }


    } elsif(($kind == $HcomMissileNM) ||
	    ($kind == $HcomMissilePP) ||
	    ($kind == $HcomMissileSPP) ||
	    ($kind == $HcomMissileST) ||
	    ($kind == $HcomMissileSS) ||
	    ($kind == $HcomMissileLR) ||
	    ($kind == $HcomMissileLD)) {
	# �ߥ������
	# �������åȼ���
	my($tn) = $HidToNumber{$target};
	if($tn eq '') {
	    # �������åȤ����Ǥˤʤ�
	    logMsNoTarget($id, $name, $comName);
	    return 0;
	}

	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}

	my($flag) = 0;
	if($arg == 0) {
	    # 0�ξ��Ϸ�Ƥ����
	    $arg = 100;
	}

	# ��������
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty, $err);

	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);

	my($doumei) = 0;

	    my($dx, $dy, $landKindd, $ttlv, $i);
	    for($i = 0; $i < $HpointNumber; $i++) {
		$dx = $Hrpx[$i];
		$dy = $Hrpy[$i];
		$landKindd = $land->[$dx][$dy];
		if($landKindd == $HlandTaishi) {
		    $ttlv = $landValue->[$dx][$dy];
		    if($ttlv == $tIsland->{'id'}) {
			$doumei = 1;
	            }
		}
	    }

		if(($lovePeace == 1) &&
		   ($msjotai == 2) &&
		   ($tIsland->{'id'} == $msid)) {

	        } elsif(($lovePeace == 1) &&
		   ($doumei == 1) &&
		   ($island->{'id'} != $tIsland->{'id'})) {

	        } elsif(($lovePeace == 1) &&
		   ($tIsland->{'monsterlive'} == 0) &&
		   ($tIsland->{'rot'} == 0) &&
		   ($island->{'id'} != $tIsland->{'id'})) {

		$island->{'money'} = 0;

		logNiwaren2($id, $name, $comName);
		return 0;
	        } elsif(($lovePeace == 1) &&
			($kind != $HcomMissileSPP) &&
			($island->{'id'} != $tIsland->{'id'})) {
		logNiwaren3($id, $name, $comName);
		return 0;
	        }


        # ����ο͸������ʤ�������ɸ��ο͸������ʤ��ʤ顢�¹Ԥϵ��Ĥ���ʤ�
        if ((($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) && ($tIsland->{'rot'} == 0)) {
            logForbidden($id, $name, $comName);
            return 0;
        }

	# ��̱�ο�
	my($boat) = 0;

	# ����
	if($kind == $HcomMissilePP) {
	    $err = 7;
	} elsif($kind == $HcomMissileSS) {
	    $err = 7;
	} elsif($kind == $HcomMissileSPP) {
	    $err = 1;
	} else {
	    $err = 19;
	}

	$mukou = 0;
	$bouei = 0;
	$kaijumukou = 0;
	$kaijuhit = 0;
	$total = 0;
	$fuhatu = 0;

	# �⤬�Ԥ��뤫�������­��뤫������������Ĥޤǥ롼��
	my($bx, $by, $count) = (0,0,0);
	while(($arg > 0) &&
	      ($island->{'money'} >= $cost)) {
	    # ���Ϥ򸫤Ĥ���ޤǥ롼��
	    while($count < $HpointNumber) {
		$bx = $Hrpx[$count];
		$by = $Hrpy[$count];
		if(($land->[$bx][$by] == $HlandBase) ||
		   ($land->[$bx][$by] == $HlandSbase)) {
		    last;
		}
		$count++;
	    }
	    if($count >= $HpointNumber) {
		# ���Ĥ���ʤ��ä��餽���ޤ�
		last;
	    }

	    # �����Ĵ��Ϥ����ä��Τǡ�flag��Ω�Ƥ�
	    $flag = 1;	   

	    # ���ϤΥ�٥�򻻽�
	    my($level) = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]);
	    # ������ǥ롼��
	    while(($level > 0) &&
		  ($arg > 0) &&
		  ($island->{'money'} > $cost)) {
			if(rand(300) < $alltotal-int($island->{'rena'}/100)) {
			$level--;
			$arg--;
			$island->{'money'} -= $cost;
			$total++;
			$alltotal++;
			$fuhatu++;
			}
		# ��ä��Τ�����ʤΤǡ����ͤ���פ�����
		$level--;
		$arg--;
		$island->{'money'} -= $cost;
		$total++;
		$alltotal++;
		# ����������
		my($r) = random($err);
		$tx = $x + $ax[$r];
		$ty = $y + $ay[$r];
		if((($ty % 2) == 0) && (($y % 2) == 1)) {
		    $tx--;
		}

		# �������ϰ��⳰�����å�
		if(($tx < 0) || ($tx >= $HislandSize) ||
		   ($ty < 0) || ($ty >= $HislandSize)) {
		    # �ϰϳ�
		    if($kind == $HcomMissileST) {
			$mukou++;
		    } else {
			$mukou++;
		    }
		    next;
		}

		# ���������Ϸ�������
		my($tL) = $tLand->[$tx][$ty];
		my($tLv) = $tLandValue->[$tx][$ty];
		my($tLname) = landName($tL, $tLv);
		my($tPoint) = "($tx, $ty)";

		# �ɱһ���Ƚ��
		my($defence) = 0;
		if($kind == $HcomMissileSPP) {
		    $defence = 1;
		}
		if($HdefenceHex[$id][$tx][$ty] == 1) {
		    $defence = 1;
		} elsif($HdefenceHex[$id][$tx][$ty] == -1) {
		    $defence = 0;
		} else {
		    if(($tL == $HlandDefence) ||
		      (($tL == $HlandProcity) && ($tLv < 160))) {
			# �ɱһ��ߤ�̿��
			# �ե饰�򥯥ꥢ
			my($i, $count, $sx, $sy);
			for($i = 0; $i < 19; $i++) {
			    $sx = $tx + $ax[$i];
			    $sy = $ty + $ay[$i];

			    # �Ԥˤ�����Ĵ��
			    if((($sy % 2) == 0) && (($ty % 2) == 1)) {
				$sx--;
			    }

			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {
				# �ϰϳ��ξ�粿�⤷�ʤ�
			    } else {
				# �ϰ���ξ��
				$HdefenceHex[$id][$sx][$sy] = 0;
			    }
			}
		    } elsif((countAround($tLand, $tx, $ty, $HlandDefence, 19))&&($island->{'sabun'} > 0)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		    } elsif((countAround($tLand, $tx, $ty, $HlandProcity, 7))&&($island->{'sabun'} > 0)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		    } elsif((countAround($tLand, $tx, $ty, $HlandHouse, 1))&&($island->{'sabun'} > 0)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		    } elsif((countAround($tLand, $tx, $ty, $HlandShuto, 7))&&($island->{'sabun'} > 0)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		    } else {
			$HdefenceHex[$id][$tx][$ty] = -1;
			$defence = 0;
		    }
		}
		
		if($defence == 1) {
		    # ��������
		    if($kind == $HcomMissileST) {
			$bouei++;
		    } else {
			$bouei++;
		    }
		    next;
		}

	        if($tIsland->{'eis5'} >= 1) {
		    if(random(5000) < $tIsland->{'rena'}) {
	               $tIsland->{'eis5'} -= 2;
			if($tIsland->{'eis5'} < 1) {
			   $tIsland->{'eis5'} = 0;
			    logEiseiEnd($id, $name, "�ɱұ���");
			}
			$bouei++;
		    next;
		    }
	        }

	        if($tIsland->{'c23'} >= 1) {
			$kaijumukou++;
		    next;
	        }

	        if(($tIsland->{'h10'} >= 1) && ($island->{'id'} != $tIsland->{'id'})) {
			$bouei++;
		    next;
	        }

		# �ָ��̤ʤ���hex��ǽ��Ƚ��
		if(($kind != $HcomMissileLR) &&
		   ((($tL == $HlandSea) && ($tLv == 0)) || # ������
		   ((($tL == $HlandSea) ||   # ���ޤ��ϡ�����
		     ($tL == $HlandSbase) ||   # ������Ϥޤ��ϡ�����
		     ($tL == $HlandSeacity) ||
		     ($tL == $HlandSeatown) ||
		     ($tL == $HlandUmishuto) ||
		     ($tL == $HlandUmiamu) ||
		     ($tL == $HlandGold) ||
		     ($tL == $HlandMountain)) # ���ǡ�����
		    && ($kind != $HcomMissileLD)))){ # Φ���ưʳ�
		    # ������Ϥξ�硢���Υե�
		    if(($tL == $HlandSbase) ||
		       ($tL == $HlandSeatown) ||
		       ($tL == $HlandUmishuto) ||
		       ($tL == $HlandSeacity)) {
			$tL = $HlandSea;
		    }
		    $tLname = landName($tL, $tLv);

		    # ̵����
		    if($kind == $HcomMissileST) {
			# ���ƥ륹
			$mukou++;
		    } else {
			# �̾��
			$mukou++;
		    }
		    next;
		}

		# �Ƥμ����ʬ��
      if($kind == $HcomMissileLR) {
        if(($tL == $HlandMountain) ||
	   ($tL == $HlandGold)) {
          # �������Ƥ������̵��
			$mukou++;
          next;
        }
        if($tL == $HlandSbase) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandSea;
          $landValue->[$tx][$ty] = 1;
          logMsLRSbase($id, $target, $name, $tName,
                       $comName, $tLname, $point, $tPoint);
          next;
        } elsif($tL == $HlandSeacity) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandSea;
          $landValue->[$tx][$ty] = 1;
          logMsLRSbase($id, $target, $name, $tName,
                     $comName, $tLname, $point, $tPoint);
          next;
        } elsif($tL == $HlandUmishuto) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandSea;
          $landValue->[$tx][$ty] = 1;
          logMsLRSbase($id, $target, $name, $tName,
                     $comName, $tLname, $point, $tPoint);
          next;
        } elsif($tL == $HlandSeatown) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandSea;
          $landValue->[$tx][$ty] = 1;
          logMsLRSbase($id, $target, $name, $tName,
                     $comName, $tLname, $point, $tPoint);
          next;
        } elsif($tL == $HlandOil) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandSea;
          $landValue->[$tx][$ty] = 1;
          logMsLRSbase($id, $target, $name, $tName,
                     $comName, $tLname, $point, $tPoint);
          next;
        } elsif($tL == $HlandFune) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandSea;
          $landValue->[$tx][$ty] = 1;
          logMsLRSbase($id, $target, $name, $tName,
                     $comName, $tLname, $point, $tPoint);
          next;
        } elsif($tL == $HlandFrocity) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandSea;
          $landValue->[$tx][$ty] = 1;
          logMsLRSbase($id, $target, $name, $tName,
                     $comName, $tLname, $point, $tPoint);
          next;
        } elsif($tL == $HlandUmiamu) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandSea;
          $landValue->[$tx][$ty] = 1;
          logMsLRSbase($id, $target, $name, $tName,
                     $comName, $tLname, $point, $tPoint);
          next;
        } elsif($tL == $HlandRottenSea) {
          # ������Ϥʤ顢��Ū�ξ��������ˤ���
          $land->[$tx][$ty] = $HlandMountain;
          $landValue->[$tx][$ty] = 0;
          logMsLRSeaRotten($id, $target, $name, $tName,
                     $comName, $tLname, $point, $tPoint);
          next;
        } elsif(($tL == $HlandSea) ||
		($tL == $HlandIce)) {
          if($tLv == 1){
            # �����ξ��
            $tLand->[$tx][$ty] = $HlandWaste;
            $tLandValue->[$tx][$ty] = 0;
            logMsLRSea1($id, $target, $name, $tName,
                        $comName, $tLname, $point, $tPoint);

            $tIsland->{'area'}++;

            if($seaCount <= 4) {
              # ����γ���3�إå�������ʤΤǡ������ˤ���
              my($i, $sx, $sy);
              for($i = 1; $i < 7; $i++) {
                $sx = $x + $ax[$i];
                $sy = $y + $ay[$i];

                # �Ԥˤ�����Ĵ��
                if((($sy % 2) == 0) && (($y % 2) == 1)) {
                  $sx--;
                }

                if(($sx < 0) || ($sx >= $HislandSize) ||
                   ($sy < 0) || ($sy >= $HislandSize)) {
                } else {
                # �ϰ���ξ��
                  if($tLand->[$sx][$sy] == $HlandSea) {
                    $tLandValue->[$sx][$sy] = 1;
                  }
                }
              }
            }
            next;
          } else {
            # ���ʤ顢��Ū�ξ��������ˤ���
            $tLand->[$tx][$ty] = $HlandSea;
            $tLandValue->[$tx][$ty] = 1;
            logMsLRSbase($id, $target, $name, $tName,
                       $comName, $tLname, $point, $tPoint);

            next;

          }
        } elsif($tL == $HlandMonster){
          logMsLRMonster($id, $target, $name, $tName,
                         $comName, $tLname, $point, $tPoint);
          # ���ˤʤ�
          $tLand->[$tx][$ty] = $HlandMountain;
          $tLandValue->[$tx][$ty] = 0;
          next;
        }

        logMsLRLand($id, $target, $name, $tName,
                    $comName, $tLname, $point, $tPoint);
        # ���ˤʤ�
        $tLand->[$tx][$ty] = $HlandMountain;
        $tLandValue->[$tx][$ty] = 0;
		                if (rand(1000) < 22) {
		                    $tLand->[$tx][$ty] = $HlandMonument;
		                    $tLandValue->[$tx][$ty] = 75;
		                }
        next;
		    # �и���
		    if(($tL == $HlandTown) ||
			 ($tL == $HlandMinato) ||
			 ($tL == $HlandOnsen) ||
			 ($tL == $HlandNewtown) ||
			 ($tL == $HlandBigtown)) {
			if(($land->[$bx][$by] == $HlandBase) ||
			($land->[$bx][$by] == $HlandSbase)) {
			# �ޤ����Ϥξ��Τ�
			$landValue->[$bx][$by] += int($tLv / 20);
			if($landValue->[$bx][$by] > $HmaxExpPoint) {
			$landValue->[$bx][$by] = $HmaxExpPoint;
			}
			}
		        logMsLRLand($id, $target, $name, $tName,
		                    $comName, $tLname, $point, $tPoint);
		        # ���ˤʤ�
		        $tLand->[$tx][$ty] = $HlandMountain;
		        $tLandValue->[$tx][$ty] = 0;
		        next;
		    } else {
		    # ����¾
		    logMsLRLand($id, $target, $name, $tName,
		                $comName, $tLname, $point, $tPoint);
		    # ���ˤʤ�
		    $tland->[$tx][$ty] = $HlandMountain;
 		    $tlandValue->[$tx][$ty] = 0;

		                if (rand(1000) < 20) {
		                    $tland->[$tx][$ty] = $HlandMonument;
		                    $tlandValue->[$tx][$ty] = 75;
		                }

		    next;
		    }


		} elsif($kind == $HcomMissileSS) {
			logMsSS($id, $target, $name, $tName,
				    $comName, $tLname, $point, $tPoint);
		wideDamageli($target, $tName, $tLand, $tLandValue, $tx, $ty);

		} elsif($kind == $HcomMissileLD) {
		    # Φ���˲���
		    if(($tL == $HlandMountain) ||
		       ($tL == $HlandOnsen) ||
		       ($tL == $HlandGold)) {
			# ��(���Ϥˤʤ�)
			logMsLDMountain($id, $target, $name, $tName,
					 $comName, $tLname, $point, $tPoint);
			# ���Ϥˤʤ�
			$tLand->[$tx][$ty] = $HlandWaste;
			$tLandValue->[$tx][$ty] = 0;
			next;

		    } elsif(($tL == $HlandSbase) ||
			    ($tL == $HlandFune) ||
			    ($tL == $HlandFrocity) ||
			    ($tL == $HlandUmiamu) ||
			    ($tL == $HlandSeatown) ||
			    ($tL == $HlandUmishuto) ||
		            ($tL == $HlandSeacity)) {
			# ������� �����Ի�
			logMsLDSbase($id, $target, $name, $tName,
				      $comName, $tLname, $point, $tPoint);
		    } elsif($tL == $HlandMonster) {
			# ����
			logMsLDMonster($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
		    } elsif($tL == $HlandRottenSea) {
			# ����
			logMsLDSeaRotten($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
		    } elsif(($tL == $HlandSea) ||
			    ($tL == $HlandIce)) {
			# ����
			logMsLDSea1($id, $target, $name, $tName,
				    $comName, $tLname, $point, $tPoint);
		    } else {
			# ����¾
			logMsLDLand($id, $target, $name, $tName,
				     $comName, $tLname, $point, $tPoint);
		    }
		    
		    # �и���
		    if(($tL == $HlandTown) ||
			 ($tL == $HlandMinato) ||
			 ($tL == $HlandNewtown) ||
			 ($tL == $HlandBigtown)) {
			if(($land->[$bx][$by] == $HlandBase) ||
			   ($land->[$bx][$by] == $HlandSbase)) {
			    # �ޤ����Ϥξ��Τ�
			    $landValue->[$bx][$by] += int($tLv / 20);
			    if($landValue->[$bx][$by] > $HmaxExpPoint) {
				$landValue->[$bx][$by] = $HmaxExpPoint;
			    }
			}
		    }

		    # �����ˤʤ�
		    $tLand->[$tx][$ty] = $HlandSea;
		    $tIsland->{'area'}--;
		    $tLandValue->[$tx][$ty] = 1;

		    # �Ǥ����ġ�������������Ϥ��ä��鳤
		    if(($tL == $HlandOil) ||
			($tL == $HlandSea) ||
			($tL == $HlandIce) ||
			($tL == $HlandSeacity) ||
			($tL == $HlandSeatown) ||
			($tL == $HlandUmishuto) ||
			($tL == $HlandFune) ||
			($tL == $HlandFrocity) ||
			($tL == $HlandUmiamu) ||
		       ($tL == $HlandSbase)) {
			$tLandValue->[$tx][$ty] = 0;
		    }
		} else {
		    # ����¾�ߥ�����
		    if($tL == $HlandWaste) {
			# ����(�ﳲ�ʤ�)
			if($kind == $HcomMissileST) {
			$mukou++;
			} else {
			$mukou++;
			}
		    } elsif($tL == $HlandRottenSea) {
			if($kind == $HcomMissileST) {
			    # ���ƥ륹
			    logMsNormalSRotten($id, $target, $name, $tName,
					 $comName, $tLname, $point, $tPoint);
			} else {
			    # �̾�
			    logMsNormalRotten($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
			}
		    } elsif($tL == $HlandMonster) {
			# ����
			my($mKind, $mName, $mHp) = monsterSpec($tLv);
			my($special) = $HmonsterSpecial[$mKind];

			# �Ų���?
			if((($special == 3) && (($HislandTurn % 2) == 1)) ||
                           (($special == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
			   (($special == 4) && (($HislandTurn % 2) == 0))) {
			    # �Ų���
			    if($kind == $HcomMissileST) {
				# ���ƥ륹
				$kaijumukou++;
			    } else {
				# �̾���
				$kaijumukou++;
			    }
			    next;
			} else {
			    # �Ų��椸��ʤ�
			    if(($special == 5 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < $HmonsterDefence) ||
				($mKind == 15 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < $HmonsterDefence)) {
			      if($kind == $HcomMissileST) {
				$kaijumukou++;
			    } else{
				$kaijumukou++;
			    }
			    next;
			    }elsif(($mKind == 13 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 900) ||
				   ($mKind == 20 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 800) ||
				   ($mKind == 21 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 700) ||
				   ($mKind == 22 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 750) ||
				   ($mKind == 18 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < (600+random(400))) ||
				   ($mKind == 30 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < (950+random(50))) ||
				   ($mKind == 19 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < (666+random(400)))) {
			      if($kind == $HcomMissileST) {
				$kaijumukou++;
			    } else{
				$kaijumukou++;
			    }
			    next;
			    }elsif($mKind == 14 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 400){
			      if($kind == $HcomMissileST) {
				$kaijumukou++;
			    } else{
				$kaijumukou++;
			    }
			    next;
			    }elsif($mKind == 17 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < (400+random(500))){
			      if($kind == $HcomMissileST) {
				$kaijumukou++;
			    } else{
				$kaijumukou++;
			    }
			    next;
			  }
			    if($mHp == 1) {
				# ���ä��Ȥ᤿
				if(($land->[$bx][$by] == $HlandBase) ||
				   ($land->[$bx][$by] == $HlandSbase)) {
				    # �и���
				    $landValue->[$bx][$by] += $HmonsterExp[$mKind];
				    if($landValue->[$bx][$by] > $HmaxExpPoint) {
					$landValue->[$bx][$by] = $HmaxExpPoint;
				    }
				}

                                if ($mKind == 8) { # ������ʤ�
                                    # �峤ȯ��
                                    my($point) = "($tx, $ty)";
                                    logRottenSeaBorn($id, $name, $point);
                                    $tLand->[$tx][$ty] = $HlandRottenSea;
                                    $tLandValue->[$tx][$ty] = 1;
                                    next;
                                }

				if($kind == $HcomMissileST) {
				    # ���ƥ륹
				    logMsMonKillS($id, $target, $name, $tName,
						  $comName, $mName, $point,
						  $tPoint);
				} else {
				    # �̾�
				    logMsMonKill($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				}

				# ����
				my($value) = $HmonsterValue[$mKind];
				if($value > 0) {
				    $tIsland->{'money'} += $value;
				    logMsMonMoney($target, $mName, $value);

	    if($island->{'sin'} > 0) {
	    my($value, $str);
	    $value = $HmonsterValue[$mKind] + random(101);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logSinMoney($id, $name, $str);
	    }
	    if($island->{'jin'} > 0) {
	    my($value, $str);
	    $value = $HmonsterValue[$mKind] + random(101);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logJinMoney($id, $name, $str);
	    }

				}

                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $mKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
			    } else {
				# ���������Ƥ�
				if($kind == $HcomMissileST) {
				    # ���ƥ륹
					$kaijuhit++;
				} else {
				    # �̾�
					$kaijuhit++;
				}
				# HP��1����
				$tLandValue->[$tx][$ty]--;
				next;
			    }

			}
		    } else {
			# �̾��Ϸ�
			if($kind == $HcomMissileST) {
			    # ���ƥ륹
			    logMsNormalS($id, $target, $name, $tName,
					   $comName, $tLname, $point,
					   $tPoint);
			} else {
			    # �̾�
			    logMsNormal($id, $target, $name, $tName,
					 $comName, $tLname, $point,
					 $tPoint);
			}
		    }
		    # �и���
		    if(($tL == $HlandTown) ||
			($tL == $HlandMinato) ||
			($tL == $HlandNewtown) ||
			($tL == $HlandBigtown)) {
			if(($land->[$bx][$by] == $HlandBase) ||
			    ($land->[$bx][$by] == $HlandSbase)) {
			    $landValue->[$bx][$by] += int($tLv / 20);
			    $boat += $tLv; # �̾�ߥ�����ʤΤ���̱�˥ץ饹
			    if($landValue->[$bx][$by] > $HmaxExpPoint) {
				$landValue->[$bx][$by] = $HmaxExpPoint;
			    }
			}
		    }
		    
                    # ���Ϥˤʤ�
		    $tLand->[$tx][$ty] = $HlandWaste;
		    $tLandValue->[$tx][$ty] = 1; # ������

		    my($mKind, $mName, $mHp) = monsterSpec($tLv);
		    my($special) = $HmonsterSpecial[$mKind];
		    if(($mKind == 17) && ($tL == $HlandMonster)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 86;
		    }

		    if(($tLv == 25) && ($tL == $HlandMonument) && (random(10000) < $island->{'rena'}) && ($island->{'rena'} > 2000)) {
		    $kind = random($HmonsterLevel4) + 1;
		    $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		    $tLand->[$tx][$ty] = $HlandMonster;
		    $tLandValue->[$tx][$ty] = $lv;
		    # ���þ���
		    my($mKind, $mName, $mHp) = monsterSpec($lv);

		    # ��å�����
		    logMonsComemagic($id, $name, $mName, "($bx, $by)", $lName);
		    }

		    # �Ǥ����Ĥ��ä��鳤
		    if(($tL == $HlandOil) ||
		       ($tL == $HlandFrocity) ||
		       ($tL == $HlandFune)) {
			$tLand->[$tx][$ty] = $HlandSea;
			$tLandValue->[$tx][$ty] = 0;
		    }
                    # �Ǥ��ܿ���ʤ�����
                    if($tL == $HlandNursery) {
                        $tLand->[$tx][$ty] = $HlandSea;
                        $tLandValue->[$tx][$ty] = 1;
                    }
                    if($tL == $HlandIce) {
                        $tLand->[$tx][$ty] = $HlandSea;
                        $tLandValue->[$tx][$ty] = 1;
                    }
                    if($tL == $HlandOnsen) {
                        $tLand->[$tx][$ty] = $HlandMountain;
                        $tLandValue->[$tx][$ty] = 0;
                    }
		} 
	    }

	    # ����������䤷�Ȥ�
	    $count++;
	}
	    # ����
		if($kind == $HcomMissileST) {
			    # ���ƥ륹
		logMsTotalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $total, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu);

		} else {
			    # �̾�
		logMsTotal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $total, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu);

			}

	if($flag == 0) {
	    # ���Ϥ���Ĥ�̵���ä����
	    logMsNoBase($id, $name, $comName);
	    return 0;
	}

	# ��̱Ƚ��
	$boat = int($boat / 2);
	if(($boat > 0) && ($id != $target) && ($kind != $HcomMissileST)) {
	    # ��̱ɺ��
	    my($achive); # ��ã��̱
	    my($i);
	    for($i = 0; ($i < $HpointNumber && $boat > 0); $i++) {
		$bx = $Hrpx[$i];
		$by = $Hrpy[$i];
		if($land->[$bx][$by] == $HlandTown) {
		    # Į�ξ��
		    my($lv) = $landValue->[$bx][$by];
		    if($boat > 50) {
			$lv += 50;
			$boat -= 50;
			$achive += 50;
		    } else {
			$lv += $boat;
			$achive += $boat;
			$boat = 0;
		    }
		    if($lv > 200) {
			$boat += ($lv - 200);
			$achive -= ($lv - 200);
			$lv = 200;
		    }
		    $landValue->[$bx][$by] = $lv;
		} elsif($land->[$bx][$by] == $HlandPlains) {
		    # ʿ�Ϥξ��
		    $land->[$bx][$by] = $HlandTown;;
		    if($boat > 10) {
			$landValue->[$bx][$by] = 5;
			$boat -= 10;
			$achive += 10;
		    } elsif($boat > 5) {
			$landValue->[$bx][$by] = $boat - 5;
			$achive += $boat;
			$boat = 0;
		    }
		}
		if($boat <= 0) {
		    last;
		}
	    }
	    if($achive > 0) {
		# �����Ǥ����夷����硢�������Ǥ�
		logMsBoatPeople($id, $name, $achive);

		# ��̱�ο���������ʾ�ʤ顢ʿ�¾ޤβ�ǽ������
		if($achive >= 200) {
		    my($prize) = $island->{'prize'};
		    $prize =~ /([0-9]*),([0-9]*),(.*)/;
		    my($flags) = $1;
		    my($monsters) = $2;
		    my($turns) = $3;

		    if((!($flags & 8)) &&  $achive >= 200){
			$flags |= 8;
			logPrize($id, $name, $Hprize[4]);
		    } elsif((!($flags & 16)) &&  $achive > 500){
			$flags |= 16;
			logPrize($id, $name, $Hprize[5]);
		    } elsif((!($flags & 32)) &&  $achive > 800){
			$flags |= 32;
			logPrize($id, $name, $Hprize[6]);
		    }
		    $island->{'prize'} = "$flags,$monsters,$turns";
		}
	    }
	}
	return 1;
    } elsif($kind == $HcomSendMonster) {
	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}
	# �����ɸ�
	# �������åȼ���
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};

	if($tn eq '') {
	    # �������åȤ����Ǥˤʤ�
	    logMsNoTarget($id, $name, $comName);
	    return 0;
	}

        # ����ο͸������ʤ�������ɸ��ο͸������ʤ��ʤ顢�¹Ԥϵ��Ĥ���ʤ�
        if (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) {
            logForbidden($id, $name, $comName);
            return 0;
        }

	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);
	if(($msjotai != 2) ||
	   ($tIsland->{'id'} != $msid)) {
		logNiwaren3($id, $name, $comName);
		return 0;
        }

        if ($arg > 30) {
            $arg = 30;
        }

	$kind = $arg;
	$lv = ($kind << 4)
	    + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
	my($mKind, $mName, $mHp) = monsterSpec($lv);

		if($lovePeace == 1) {

		    $etc6 = $island->{'etc6'};
		    $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		    ($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		    $etc6t = $tIsland->{'etc6'};
		    $etc6t =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($z0t,$z1t,$z2t,$z3t,$z4t,$z5t,$z6t,$z7t,$z8t,$z9t,$z10t,$z11t,$z12t,$z13t,$z14t,$z15t,$z16t,$z17t,$z18t,$z19t,$z20t,$z21t,$z22t,$z23t,$z24t,$z25t,$z26t,$z27t,$z28t,$z29t,$z30t) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		    ($zt->{'0'},$zt->{'1'},$zt->{'2'},$zt->{'3'},$zt->{'4'},$zt->{'5'},$zt->{'6'},$zt->{'7'},$zt->{'8'},$zt->{'9'},$zt->{'10'},$zt->{'11'},$zt->{'12'},$zt->{'13'},$zt->{'14'},$zt->{'15'},$zt->{'16'},$zt->{'17'},$zt->{'18'},$zt->{'19'},$zt->{'20'},$zt->{'21'},$zt->{'22'},$zt->{'23'},$zt->{'24'},$zt->{'25'},$zt->{'26'},$zt->{'27'},$zt->{'28'},$zt->{'29'},$zt->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		    $eisei5 = $island->{'eisei5'};
		    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);

		    $eisei5t = $tIsland->{'eisei5'};
		    $eisei5t =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($mshpt, $msapt, $msdpt, $msspt, $mswint, $msexet, $tetsubt) = ($1, $2, $3, $4, $5, $6, $7);

		    $tradeexe = $HmonsterExp[$arg] * 2;

	            if (($z->{"$arg"} > 0) && ($tIsland->{'zoo'} > 0) && ($msexet > $tradeexe) && ($tIsland->{'rena'} > $arg*500)) {
			$z->{"$arg"} -= 1;
			$zt->{"$arg"} += 1;
			$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
			$tIsland->{'etc6'} = "$zt->{'0'},$zt->{'1'},$zt->{'2'},$zt->{'3'},$zt->{'4'},$zt->{'5'},$zt->{'6'},$zt->{'7'},$zt->{'8'},$zt->{'9'},$zt->{'10'},$zt->{'11'},$zt->{'12'},$zt->{'13'},$zt->{'14'},$zt->{'15'},$zt->{'16'},$zt->{'17'},$zt->{'18'},$zt->{'19'},$zt->{'20'},$zt->{'21'},$zt->{'22'},$zt->{'23'},$zt->{'24'},$zt->{'25'},$zt->{'26'},$zt->{'27'},$zt->{'28'},$zt->{'29'},$zt->{'30'}";

			$msexe += $tradeexe;
			$msexet -= $tradeexe;
			$island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tetsub";
			$tIsland->{'eisei5'} = "$mshpt,$msapt,$msdpt,$msspt,$mswint,$msexet,$tetsubt";

			$cost *= $arg;
			$island->{'money'} += $cost;
			$tIsland->{'money'} -= $cost;

			logMonsSend2($id, $target, $name, $tName, $mName);

		    } else {
			logNoMoney2($id, $name, $comName);
			return 0;
		    }


	        } else {

		    $etc6 = $island->{'etc6'};
		    $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		    ($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

	            if ($z->{"$arg"} > 0) {
			$z->{"$arg"} -= 1;
			$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
		    }

		$tIsland->{'monstersend'}++;
		$tIsland->{'monstersendkind'} = $arg;

		$cost *= $arg;
		$island->{'money'} -= $cost;

		# ��å�����
		logMonsSend($id, $target, $name, $tName, $mName);

	        }

	return 1;
    } elsif($kind == $HcomTaishi) {
	# ����ɸ�
	# �������åȼ���
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty, $err);

	if($tn eq '') {
	    # �������åȤ����Ǥˤʤ�
	    logMsNoTarget($id, $name, $comName);
	    return 0;
	}

	if($island->{'id'} > 4090) {
	    # �������åȤ��礭��
            logForbidden($id, $name, $comName);
	    return 0;
	}

        # ����ο͸������ʤ�������ɸ��ο͸������ʤ��ʤ顢�¹Ԥϵ��Ĥ���ʤ�
        if (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) {
            logForbidden($id, $name, $comName);
            return 0;
        }

        # Ʊid�ʤ顢�¹Ԥϵ��Ĥ���ʤ�
        if ($island->{'id'} == $tIsland->{'id'}) {
            logForbidden($id, $name, $comName);
            return 0;
        }

        # ����ο͸������ʤ�������ɸ��ο͸������ʤ��ʤ顢�¹Ԥϵ��Ĥ���ʤ�
        if ($tIsland->{'tai'} > 2) {
            logForbidden($id, $name, $comName);
            return 0;
        }

	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);

	if(($lovePeace == 1) &&
	   ($msjotai != 2) &&
	   ($tIsland->{'id'} != $msid)) {
            logForbidden($id, $name, $comName);
            return 0;
        }

	$tx = $x;
	$ty = $y;
	if((($ty % 2) == 0) && (($y % 2) == 1)) {
	    $tx--;
	}

	# �������ϰ��⳰�����å�
	if(($tx < 0) || ($tx >= $HislandSize) ||
	   ($ty < 0) || ($ty >= $HislandSize)) {
	    next;
	}

	# ���������Ϸ�������
	my($tL) = $tLand->[$tx][$ty];
	my($tLv) = $tLandValue->[$tx][$ty];
	my($tLname) = landName($tL, $tLv);
	my($tPoint) = "($tx, $ty)";
	$id = $island->{'id'};

	if($tL != $HlandPlains) {
	    logLandFail($id, $name, $comName, $tLname, $tPoint);
	    return 0;
	}

          $tLand->[$tx][$ty] = $HlandTaishi;
          $tLandValue->[$tx][$ty] = $id;

	logTaishi($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);

	$island->{'money'} -= $cost;
	return 1;

    } elsif($kind == $HcomMagic) {

	if($island->{'shouhi'} > $island->{'ene'}) {
	    logMsNoEne($id, $name, $comName);
	    return 0;
	}

	# ��ѻ��ɸ�
	# �������åȼ���
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty, $err);

	$etc9 = $island->{'etc9'};
	$etc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($co7, $magicf, $magici, $magica, $magicw, $magicl, $magicd) = ($1, $2, $3, $4, $5, $6, $7);

	if($tn eq '') {
	    # �������åȤ����Ǥˤʤ�
	    logMsNoTarget($id, $name, $comName);
	    return 0;
	}

	if($co7 == 0) {
	    logMagicNoTarget($id, $name, $comName);
	    return 0;
	}

	$tx = $x;
	$ty = $y;
	if((($ty % 2) == 0) && (($y % 2) == 1)) {
	    $tx--;
	}

	# �������ϰ��⳰�����å�
	if(($tx < 0) || ($tx >= $HislandSize) ||
	   ($ty < 0) || ($ty >= $HislandSize)) {
	    next;
	}

	# ���������Ϸ�������
	my($tL) = $tLand->[$tx][$ty];
	my($tLv) = $tLandValue->[$tx][$ty];
	my($tLname) = landName($tL, $tLv);
	my($tPoint) = "($tx, $ty)";
	$id = $island->{'id'};

	if($arg >= 8) {
	    $arg = 0;
	}
	    if($arg == 0) {
		$t = "�����ѻ��ɸ�";
	    }
	    if($arg == 1) {
		$t = "ɹ����ѻ��ɸ�";
	    }
	    if($arg == 2) {
		$t = "�Ϸ���ѻ��ɸ�";
	    }
	    if($arg == 3) {
		$t = "������ѻ��ɸ�";
	    }
	    if($arg == 4) {
		$t = "������ѻ��ɸ�";
	    }
	    if($arg == 5) {
		$t = "�Ƿ���ѻ��ɸ�";
	    }
	    if($arg == 6) {
		$t = "ŷ����ˤ��";
	    }
	    if($arg == 7) {
		$t = "ưʪ����鷸�ɸ�";
	    }

        if ($island->{'id'} == $tIsland->{'id'}) {

		if($tL == $HlandMonster) {

			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);

		    if(($arg == 0)&&($island->{'ene'} > 4000+$magicf*400)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magicf;
			    $island->{'shouhi'} += 4000+$magicf*400;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($id, $name, "�����ѻ�", "��Ǯ�α�", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$tx][$ty] = $HlandWaste;
				$landValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				   logMsMonMoney($id, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			    next;
		    }
		    if(($arg == 1)&&($island->{'ene'} > 6000+$magici*500)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magici+random($magici);
			    $island->{'shouhi'} += 6000+$magici*500;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($id, $name, "ɹ����ѻ�", "���������륢����", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$tx][$ty] = $HlandIce;
				$landValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				   logMsMonMoney($id, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			    next;
		    }
		    if(($arg == 2)&&($island->{'ene'} > 10000)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magica*2;
			    $island->{'shouhi'} += 10000;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($id, $name, "�Ϸ���ѻ�", "��������������", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$tx][$ty] = $HlandMountain;
				$landValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				   logMsMonMoney($id, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			    next;
		    }
		    if(($arg == 3)&&($island->{'ene'} > 1000+$magicw*1000)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicw*2);
			    $island->{'shouhi'} += 1000+$magicw*1000;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($id, $name, "������ѻ�", "�����ο�", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$tx][$ty] = $HlandWaste;
				$landValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				   logMsMonMoney($id, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			    next;
		    }
		    if(($arg == 4)&&($island->{'ene'} > 10000)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicl*4);
			    $island->{'shouhi'} += 10000;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($id, $name, "������ѻ�", "�饤�ȥ˥󥰥ܥ��", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$tx][$ty] = $HlandWaste;
				$landValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				   logMsMonMoney($id, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			    next;
		    }
		    if(($arg == 5)&&($island->{'ene'} > 10000)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicd*3);
			    $island->{'shouhi'} += 10000;
			    $island->{'money'} -= $cost;
			    logIreAttackt3($id, $name, "�Ƿ���ѻ�", "������������", $dpoint, $tName, $tPoint);

			    if(random(100) < $magicd*10){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$tx][$ty] = $HlandWaste;
				$landValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				   logMsMonMoney($id, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			    next;
		    }
		    if(($arg == 7)&&($island->{'zoo'} > 0)) {

			    my($i,$sx,$sy);
			    my($zlv) = (0);
			    for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];
			    if($land->[$sx][$sy] == $HlandZoo){
				$zlv += $landValue->[$sx][$sy];
			    }
			    }

			$etc6 = $island->{'etc6'};
			$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
			($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

			$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicd*3);

				if($tKind*1000+1000 > $island->{'ene'}) {
				    $island->{'money'} -= $cost;
				    logMsNoEne2($id, $name, $comName);
				    return 0;
				}

				$island->{'shouhi'} += $tKind*1000;
				$island->{'money'} -= $cost;

				$prize = $island->{'prize'};
				my($flags, $monsters, $turns);
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				$flags = $1;
				$monsters= $2;
				$turns = $3;
				$prize = '';
				$f = 1;
				for($i = 0; $i < $HmonsterNumber; $i++) {
				    if($monsters & $f) {
					$taiji->{"$i"}++;
				    }
				    $f *= 2;
				}


			    if(($tKind*500*$tHp < $island->{'rena'}+$island->{'co4'}*1000+$island->{'co99'}*1000) && ($taiji->{"$tKind"} > 0)) {


					    if($zlv < $zookazu){

						logIreAttackt7($id, $name, "ưʪ����鷸", "��ͥ��å�", $dpoint, $tName, $tPoint);

					    } else {

					    logIreAttackt5($id, $name, "ưʪ����鷸", "��ͥ��å�", $dpoint, $tName, $tPoint);
					    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
						$land->[$tx][$ty] = $HlandWaste;
						$landValue->[$tx][$ty] = 0;

						$etc6 = $island->{'etc6'};
						$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
						($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
						($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

						$z->{"$tKind"}++;
						$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

					    }

				} else {
				logIreAttackt6($id, $name, "ưʪ����鷸", "��ͥ��å�", $dpoint, $tName, $tPoint);
				}
			return 1;
		    }
		}

        } else {
		if(($tL == $HlandPlains)&&($island->{'ene'} > 2000)) {
		    if(($arg == 0)&&($magicf>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		    }
		    if(($arg == 1)&&($magici>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		    }
		    if(($arg == 2)&&($magica>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		    }
		    if(($arg == 3)&&($magicw>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		    }
		    if(($arg == 4)&&($magicl>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		    }
		    if(($arg == 5)&&($magicd>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		    }
		    if(($arg == 6)&&($island->{'h11'}>0)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 100;
		    }
		$island->{'shouhi'} += 2000;
		$island->{'money'} -= $cost;
		}


		if($tL == $HlandRottenSea) {
		    if($arg == 0) {
			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
			$magicshouhiene = 600-$magicf*50;
			$magicnenshoene = 0;
			if($magicshouhiene < 300) {
			$magicshouhiene = 300;
			}
			    for($i = 0; $i < 19; $i++) {
				$sx = $tx + $ax[$i];
				$sy = $ty + $ay[$i];

				# �Ԥˤ�����Ĵ��
				if((($sy % 2) == 0) && (($ty % 2) == 1)) {
				    $sx--;
				}
    
				$landKind = $tLand->[$sx][$sy];
				$lv = $tLandValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";

				# �ϰϳ�Ƚ��
				if(($sx < 0) || ($sx >= $HislandSize) ||
				   ($sy < 0) || ($sy >= $HislandSize)) {
				    next;
				}
				if($landKind == $HlandRottenSea) {
				    $tLand->[$sx][$sy] = $HlandWaste;
				    $tLandValue->[$sx][$sy] = 0;
				    $island->{'shouhi'} += $magicshouhiene;
				    $magicnenshoene++;
				}
				if($island->{'shouhi'} > $island->{'ene'}) {
				    $island->{'money'} -= $cost;
				    logIreAttackt4($tIsland->{'id'}, $name, "�����ѻ�", "��Ǯ�α�", $magicnenshoene, "�峤", "�Ƥ��Ԥ���");
				return 1;
				}
			    }
				    $island->{'money'} -= $cost;
				    logIreAttackt4($tIsland->{'id'}, $name, "�����ѻ�", "��Ǯ�α�", $magicnenshoene, "�峤", "�Ƥ��Ԥ���");
				return 1;
		    }
		    if($arg == 4) {
			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
			$magicshouhiene = 700-$magicl*100;
			$magicnenshoene = 0;
			if($magicshouhiene < 500) {
			$magicshouhiene = 500;
			}

			    for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];

				$landKind = $tLand->[$sx][$sy];
				$lv = $tLandValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";

				if(($landKind == $HlandRottenSea)&&(random(10) < $magicl)) {
				    $tLand->[$sx][$sy] = $HlandWaste;
				    $tLandValue->[$sx][$sy] = 0;
				    $island->{'shouhi'} += $magicshouhiene;
				    $magicnenshoene++;
				}
				if($island->{'shouhi'} > $island->{'ene'}) {
				    $island->{'money'} -= $cost;
				    logIreAttackt4($tIsland->{'id'}, $name, "������ѻ�", "�饤�ȥ˥󥰥ܥ��", $magicnenshoene, "�峤", "�Ƥ��Ԥ���");
				return 1;
				}
			    }
				    $island->{'money'} -= $cost;
				    logIreAttackt4($tIsland->{'id'}, $name, "������ѻ�", "�饤�ȥ˥󥰥ܥ��", $magicnenshoene, "�峤", "�Ƥ��Ԥ���");
				return 1;
		    }
		    if($arg == 5) {
			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
			$magicshouhiene = 200;
			$magicnenshoene = 0;
			if($magicshouhiene < 200) {
			$magicshouhiene = 200;
			}

			    for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];

				$landKind = $tLand->[$sx][$sy];
				$lv = $tLandValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";

				if(($landKind == $HlandRottenSea)&&(random(5) < $magicd)) {
				    $tLandValue->[$sx][$sy] += 10+$magicd;
				    $island->{'shouhi'} += $magicshouhiene;
				    $magicnenshoene++;
				}
				if($island->{'shouhi'} > $island->{'ene'}) {
				    $island->{'money'} -= $cost;
				    logIreAttackt4($tIsland->{'id'}, $name, "�Ƿ���ѻ�", "������������", $magicnenshoene, "�峤", "Ϸ������");
				return 1;
				}
			    }
				    $island->{'money'} -= $cost;
				    logIreAttackt4($tIsland->{'id'}, $name, "�Ƿ���ѻ�", "������������", $magicnenshoene, "�峤", "Ϸ������");
				return 1;
		    }

		    if($arg == 6) {
			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
			$magicnenshoene = 0;
			    for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];

				$landKind = $tLand->[$sx][$sy];
				$lv = $tLandValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";

				if($landKind == $HlandRottenSea) {
				    $tLand->[$sx][$sy] = $HlandWaste;
				    $tLandValue->[$sx][$sy] = 1;
				    $island->{'shouhi'} += random(2500);
				    $magicnenshoene++;
				}
				if($island->{'shouhi'} > $island->{'ene'}) {
				    $island->{'money'} -= $cost;
				    logIreAttackt4($tIsland->{'id'}, $name, "ŷ����", "ŷ�κۤ�", $magicnenshoene, "�峤", "�᤭���Ф�");
				return 1;
				}
			    }
				    $island->{'money'} -= $cost;
				    logIreAttackt4($tIsland->{'id'}, $name, "ŷ����", "ŷ�κۤ�", $magicnenshoene, "�峤", "�᤭���Ф�");
				return 1;
		    }

		}

		if($tL == $HlandMonster) {

		    if(($arg == 0)&&($island->{'ene'} > 4000+$magicf*400)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magicf;
			    $island->{'shouhi'} += 4000+$magicf*400;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($tIsland->{'id'}, $name, "�����ѻ�", "��Ǯ�α�", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $tIsland->{'money'} += $value;
				   logMsMonMoney($tIsland->{'id'}, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		    }
		    if(($arg == 1)&&($island->{'ene'} > 6000+$magici*500)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magici+random($magici);
			    $island->{'shouhi'} += 6000+$magici*500;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($tIsland->{'id'}, $name, "ɹ����ѻ�", "���������륢����", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$tLand->[$tx][$ty] = $HlandIce;
				$tLandValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $tIsland->{'money'} += $value;
				   logMsMonMoney($tIsland->{'id'}, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		    }
		    if(($arg == 2)&&($island->{'ene'} > 10000)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magica*2;
			    $island->{'shouhi'} += 10000;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($tIsland->{'id'}, $name, "�Ϸ���ѻ�", "��������������", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$tLand->[$tx][$ty] = $HlandMountain;
				$tLandValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $tIsland->{'money'} += $value;
				   logMsMonMoney($tIsland->{'id'}, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		    }
		    if(($arg == 3)&&($island->{'ene'} > 1000+$magicw*1000)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicw*2);
			    $island->{'shouhi'} += 1000+$magicw*1000;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($tIsland->{'id'}, $name, "������ѻ�", "�����ο�", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $tIsland->{'money'} += $value;
				   logMsMonMoney($tIsland->{'id'}, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		    }
		    if(($arg == 4)&&($island->{'ene'} > 10000)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicl*4);
			    $island->{'shouhi'} += 10000;
			    $island->{'money'} -= $cost;
			    logIreAttackt2($tIsland->{'id'}, $name, "������ѻ�", "�饤�ȥ˥󥰥ܥ��", $dpoint, $tName, $tPoint);

			    $tHp -= $dpoint;
			    $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			    if($tHp < 1){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $tIsland->{'money'} += $value;
				   logMsMonMoney($tIsland->{'id'}, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		    }
		    if(($arg == 5)&&($island->{'ene'} > 10000)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicd*3);
			    $island->{'shouhi'} += 10000;
			    $island->{'money'} -= $cost;
			    logIreAttackt3($tIsland->{'id'}, $name, "�Ƿ���ѻ�", "������������", $dpoint, $tName, $tPoint);

			    if(random(100) < $magicd*10){
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $tIsland->{'money'} += $value;
				   logMsMonMoney($tIsland->{'id'}, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		    }
		    if(($arg == 6)&&($island->{'h11'} > 0)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
			    $island->{'shouhi'} += random(20000);
			    $island->{'money'} -= $cost;
			    logIreAttackt3($tIsland->{'id'}, $name, "ŷ����", "ŷ�κۤ�", $dpoint, $tName, $tPoint);

			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 1;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $tIsland->{'money'} += $value;
				   logMsMonMoney($tIsland->{'id'}, $tName, $value);
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
		    }

		}
        }

	logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
	return 1;

    } elsif($kind == $HcomSell) {
	# ͢���̷���
	if($arg == 0) { $arg = 1; }
	my($value) = min($arg * (-$cost), $island->{'food'});

	# ͢�Х���
	logSell($id, $name, $comName, $value);
	$island->{'food'} -=  $value;
	$island->{'money'} += ($value / 10);
	return 0;
    } elsif(($kind == $HcomFood) ||
	    ($kind == $HcomMoney)) {
	# �����
	# �������åȼ���
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};

        # ����ο͸������ʤ��ʤ顢�¹Ԥϵ��Ĥ���ʤ�
        if ($island->{'pop'} < $HguardPop) {
            logForbidden($id, $name, $comName);
            return 0;
        }

	# ����̷���
	if($arg == 0) { $arg = 1; }
	my($value, $str);
	if($cost < 0) {
	    $value = min($arg * (-$cost), $island->{'food'});
	    $str = "$value$HunitFood";
	} else {
	    $value = min($arg * ($cost), $island->{'money'});
	    $str = "$value$HunitMoney";
	}

	# �������
	logAid($id, $target, $name, $tName, $comName, $str);

	if($cost < 0) {
	    $island->{'food'} -= $value;
	    $tIsland->{'food'} += $value;
	} else {
	    $island->{'money'} -= $value;
	    $tIsland->{'money'} += $value;
	}
	return 0;
    } elsif($kind == $HcomEneGive) {
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};

	# ����̷���
	if($arg == 0) { $arg = 1; }
	my($value, $str);

	    $value = min($arg * ($cost), $island->{'ene'});
	    $str = "$value��kW";

	# �������
	logAid($id, $target, $name, $tName, $comName, $str);

	    $island->{'money'} -= $value;
	    $island->{'shouhi'} += $value;
	    $tIsland->{'sabun'} = $value;

	    if ($tIsland->{'sabun'} > 0) {
		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
		    $x = $Hrpx[$i];
		    $y = $Hrpy[$i];
		    $landKind = $tLand->[$x][$y];
		    $lv = $tLandValue->[$x][$y];
		    if(($landKind == $HlandConden) && ($lv < 2000)) {

	                    $n = int((2000 - $lv) / 2);
	                    $n = min(int($n + $n), $tIsland->{'sabun'});
	                    $tIsland->{'sabun'} -= $n;
	                    $tLandValue->[$x][$y] += $n;
			if ($value > 2000) {
	                    $tLandValue->[$x][$y] = 2000;
			}

		    }
	 	    if(($landKind == $HlandConden2) && ($lv < 4000)) {

	                    $n = int((4000 - $lv) / 10);
	                    $n = min(int($n*9 + rand($n)), $tIsland->{'sabun'});
	                    $tIsland->{'sabun'} -= $n;
	                    $tLandValue->[$x][$y] += $n;
			if ($value > 4000) {
	                    $tLandValue->[$x][$y] = 4000;
			}

		    }
		    if(($landKind == $HlandConden3) && ($lv < 7000)) {

	                    $n = int((7000 - $lv) / 2);
	                    $n = min(int($n + $n), $tIsland->{'sabun'});
	                    $tIsland->{'sabun'} -= $n/2;
	                    $tLandValue->[$x][$y] += $n/2;
			if ($value > 7000) {
	                    $tLandValue->[$x][$y] = 7000;
			}

		    }

	                last if ($tIsland->{'sabun'} <= 0);
		}
	    }
	return 1;
    } elsif($kind == $HcomPropaganda) {
	# Ͷ�׳�ư
	logPropaganda($id, $name, $comName);
	$island->{'propaganda'} = 1;
	$island->{'money'} -= $cost;
	if($arg > 1) {
	    my($command);
	    $arg--;
	    slideBack($comArray, 0);
	    $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;
    } elsif($kind == $HcomGiveup) {
	# ����
	logGiveup($id, $name);
	$island->{'dead'} = 1;
	unlink("island.$id");
	return 1;
    }

    return 1;
}


# ��Ĺ�����ñ�إå����ҳ�
sub doEachHex {
    my($island) = @_;
    my(@monsterMove);

    # Ƴ����
    my($name) = $island->{'name'};
    my($id) = $island->{'id'};
    my($land) = $island->{'land'};
    my($landValue) = $island->{'landValue'};

    if($anothermood == 1) {
	$island->{'amarimoney'} = $island->{'money'};
	$island->{'money'} = 0;
    }

    $etc5 = $island->{'etc5'};
    $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
    $s06b = int($s06/5);
    $s08b = int($s08/5);
    $s12b = int($s12/5)+1;
    if($s12b > 10) {$s12b = 10;}

    if(random(20000000)+$s12b*1500000 < $island->{'fukeikimoney'}-$island->{'co6'}*100000) {
	logFukeiki($id, $name);
	$island->{'money'} += 10;
	return 1;
    }

    $aucflag1 = 0;
    $aucflag2 = 0;
    $aucflag3 = 0;

    $zooflag = 0;
    $seisakuflag = 1;

    $msseigen = 0;
    $kougekiseigen = 0;
    $kougekiseigenm = 0;

    $oilincome = 0;
    $parkincome = 0;
    $rizortincome = 0;
    $m84income = 0;
    $gyosenincome = 0;
    $island->{'trainmoney'} = 0;
    $island->{'trainmoney2'} = 0;
    $island->{'hcsankaflag'} = 0;
    $island->{'roudenflag'} = 0;
    $island->{'urikireflag'} = 0;

    # ������͸��Υ�����
    my($addpop)  = 10;  # ¼��Į
    my($addpop2) = 0; # �Ի�
    if($island->{'food'} < 0) {
	# ������­
	$addpop = -30;
    } elsif($island->{'propaganda'} == 1) {
	# Ͷ�׳�ư��
	$addpop = 30;
	$addpop2 = 3;
    } elsif((rand(1000)+$island->{'m73'}*250) < $island->{'rot'} * 50) {
	# ˦�ҡ���

	if($island->{'ownfe'} == 1) {
	    logRotsick($id, $name);
	    $value = $island->{'pop'}*3 + random($island->{'pop'})*5;
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";

		if(random(100) < 20) {
		    $island->{'urikireflag'} = 1;
		    logMiyage2c($id, $name, "$island->{'onm'}", $str, "�峤���Ǿä���");
		} else {
		    logMiyage2b($id, $name, "$island->{'onm'}", $str, "�峤���Ǿä���");
		}

	} elsif($island->{'ownfe'} > 1) {

	} else {
	    logRotsick($id, $name);
	    $addpop = -10;
	}

    } elsif(random(1000) < $island->{'c21'} * 500) {
	# ���¡���
	$addpop = -3;
	$island->{'food'} -= int($island->{'food'} / 2);
	logSatansick($id, $name);
    } elsif($island->{'fim'} > 0) {
	# �����ѡ���
	    if(random(1000) < 10) {
		$addpop = -20;
		logStarvefood($id, $name);
	    }
    }

    # �롼��
    my($x, $y, $i);
    for($i = 0; $i < $HpointNumber; $i++) {
	$x = $Hrpx[$i];
	$y = $Hrpy[$i];
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];


	    if(($landKind == $HlandPlains) && (($island->{'co78'} > 0) || ($island->{'co80'} > 0) || ($island->{'yaku'} > 0))) {
		$land->[$x][$y] = $HlandPlains2;
		$landValue->[$x][$y] = 0;
		$island->{'money'} -= 10000*$seisakuflag;
		$seisakuflag++;
	    }
	    if((($landKind == $HlandWaste) || ($landKind == $HlandSunahama)) && (($island->{'co79'} > 0) || ($island->{'co80'} > 0))) {
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		$island->{'money'} -= 30000*$seisakuflag;
		$seisakuflag++;
	    }


	if(($landKind == $HlandTown) ||
	   ($landKind == $HlandMinato) ||
	   ($landKind == $HlandSeacity)) {
	    # Į��


	my($monsterCount) =
	    countAround($land, $x, $y, $HlandMonster, 7);
            if($monsterCount > 0) {
	    $lv -= random(20)+10;
	    $landValue->[$x][$y] = $lv;
	    logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if(($lv <= 0) &&
		   ($landKind == $HlandSeacity)) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		    next;
		} elsif($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    }


	my($townCount) =
	    countAround($land, $x, $y, $HlandTown, 19) +
	    countAround($land, $x, $y, $HlandProcity, 19) +
            countAround($land, $x, $y, $HlandNewtown, 19) +
	    countAround($land, $x, $y, $HlandBigtown, 19) +
	    countAround($land, $x, $y, $HlandBettown, 19) +
	    countAround($land, $x, $y, $HlandSkycity, 19) +
	    countAround($land, $x, $y, $HlandUmicity, 19) +
	    countAround($land, $x, $y, $HlandSeatown, 19) +
	    countAround($land, $x, $y, $HlandRizort, 19) +
	    countAround($land, $x, $y, $HlandKajino, 19) +
	    countAround($land, $x, $y, $HlandBigRizort, 19) +
	    countAround($land, $x, $y, $HlandShuto, 19) +
	    countAround($land, $x, $y, $HlandUmishuto, 19) +
	    countAround($land, $x, $y, $HlandMinato, 19) +
	    countAround($land, $x, $y, $HlandFrocity, 19) +
	    countAround($land, $x, $y, $HlandOnsen, 19) +
            countAround($land, $x, $y, $HlandSeacity, 19);
            if($townCount > 17) {
	        if(random(1000) < 1) {
		    if($lv > 195) {
			if($landKind == $HlandTown) {
		            $land->[$x][$y] = $HlandBigtown;
		        }
		    }
		}
	    }
	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
			if($landKind == $HlandSeacity) {
		    	$land->[$x][$y] = $HlandSea;
		    	$landValue->[$x][$y] = 0;
		    	next;
			}
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 100) {
		    $lv += random($addpop) + 1;
		    if($lv > 100) {
			$lv = 100;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 200) {
		$lv = 200;
	    }
	    $landValue->[$x][$y] = $lv;
	} elsif($landKind == $HlandPlains) {
	    # ʿ��
	    if(random(5) == 0) {
		# ��������졢Į������С�������Į�ˤʤ�
	        if(countGrow($land, $landValue, $x, $y)){
		    $land->[$x][$y] = $HlandTown;
		    $landValue->[$x][$y] = 1;
		    if(random(1000) < $island->{'nto'}*3) {
		        $land->[$x][$y] = $HlandNewtown;
		        $landValue->[$x][$y] = 1;
		    }
		}
	    }
	} elsif($landKind == $HlandFarmchi) {

	my($FarmCount) = countAround($land, $x, $y, $HlandFarm, 7);
	my($FoodkaCount) = countAround($land, $x, $y, $HlandFoodka, 7);

		$value = $lv;

		if(($FoodkaCount > 0) && ($island->{'shouhi'} < $island->{'ene'})) {
	            $valuek = int($lv/$FoodkaCount);
		    my($i,$sx,$sy);
		    for($i = 1; $i < 7; $i++) {
		        $sx = $x + $ax[$i];
		        $sy = $y + $ay[$i];
			    # �Ԥˤ�����Ĵ��
			    if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			    }
			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {
			    } else {

				if(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 1)) {
					$island->{'money'} += int($valuek*0.175);
					$island->{'shouhi'} += int($valuek*0.005);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 2)) {
					$island->{'money'} += int($valuek*0.25);
					$island->{'shouhi'} += int($valuek*0.015);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 3)) {
					$island->{'money'} += int($valuek*0.4);
					$island->{'shouhi'} += int($valuek*0.03);
				} else {

				}
			    }
			}
                } else {
	            $island->{'food'} += $value;
                }

		    $lv += random(8 + $FarmCount * 3) + 5 + $s08b;

                if($lv > 4000) {
                    $lv = 4000;
                }

	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandFarmpic) {

	my($FarmCount) = countAround($land, $x, $y, $HlandFarm, 7);
	my($FoodkaCount) = countAround($land, $x, $y, $HlandFoodka, 7);

		$value = 2 * $lv;

		if(($FoodkaCount > 0) && ($island->{'shouhi'} < $island->{'ene'})) {
	            $valuek = int($lv*2/$FoodkaCount);
		    my($i,$sx,$sy);
		    for($i = 1; $i < 7; $i++) {
		        $sx = $x + $ax[$i];
		        $sy = $y + $ay[$i];
			    # �Ԥˤ�����Ĵ��
			    if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			    }
			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {
			    } else {

				if(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 1)) {
					$island->{'money'} += int($valuek*0.175);
					$island->{'shouhi'} += int($valuek*0.005);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 2)) {
					$island->{'money'} += int($valuek*0.25);
					$island->{'shouhi'} += int($valuek*0.015);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 3)) {
					$island->{'money'} += int($valuek*0.4);
					$island->{'shouhi'} += int($valuek*0.03);
				} else {

				}
			    }
			}
                } else {
	            $island->{'food'} += $value;
                }

		    $lv += random(4 + $FarmCount * 2 + $s08b) + 3 + $s08b;

                if($lv > 4000) {
                    $lv = 4000;
                }

	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandFarmcow) {

	my($FarmCount) = countAround($land, $x, $y, $HlandFarm, 7);
	my($FoodkaCount) = countAround($land, $x, $y, $HlandFoodka, 7);

		$value = 3 * $lv;

		if(($FoodkaCount > 0) && ($island->{'shouhi'} < $island->{'ene'})) {
	            $valuek = int($lv*3/$FoodkaCount);
		    my($i,$sx,$sy);
		    for($i = 1; $i < 7; $i++) {
		        $sx = $x + $ax[$i];
		        $sy = $y + $ay[$i];
			    # �Ԥˤ�����Ĵ��
			    if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			    }
			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {

			    } else {

				if(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 1)) {
					$island->{'money'} += int($valuek*0.175);
					$island->{'shouhi'} += int($valuek*0.005);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 2)) {
					$island->{'money'} += int($valuek*0.25);
					$island->{'shouhi'} += int($valuek*0.015);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 3)) {
					$island->{'money'} += int($valuek*0.4);
					$island->{'shouhi'} += int($valuek*0.03);
				} else {

				}
			    }
			}

                } else {
	            $island->{'food'} += $value;
                }

		    $lv += random(4 + $FarmCount + $s08b) + 1 + int($s08b/2);

                if($lv > 4000) {
                    $lv = 4000;
                }

	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandFoodka) {
	my($FarmchiCount) = countAround($land, $x, $y, $HlandFarmchi, 7);
	my($FarmpicCount) = countAround($land, $x, $y, $HlandFarmpic, 7);
	my($FarmcowCount) = countAround($land, $x, $y, $HlandFarmcow, 7);
	my($FarmCount) = countAround($land, $x, $y, $HlandFarm, 7);
	my($townCount) =
	    countAround($land, $x, $y, $HlandTown, 19) +
	    countAround($land, $x, $y, $HlandProcity, 19) +
            countAround($land, $x, $y, $HlandNewtown, 19) +
	    countAround($land, $x, $y, $HlandBigtown, 19) +
	    countAround($land, $x, $y, $HlandBettown, 19) +
	    countAround($land, $x, $y, $HlandSkycity, 19) +
	    countAround($land, $x, $y, $HlandUmicity, 19) +
	    countAround($land, $x, $y, $HlandSeatown, 19) +
	    countAround($land, $x, $y, $HlandRizort, 19) +
	    countAround($land, $x, $y, $HlandKajino, 19) +
	    countAround($land, $x, $y, $HlandBigRizort, 19) +
	    countAround($land, $x, $y, $HlandShuto, 19) +
	    countAround($land, $x, $y, $HlandUmishuto, 19) +
	    countAround($land, $x, $y, $HlandMinato, 19) +
	    countAround($land, $x, $y, $HlandFrocity, 19) +
	    countAround($land, $x, $y, $HlandOnsen, 19) +
            countAround($land, $x, $y, $HlandSeacity, 19);
	my($townCounta) =
	    countAround($land, $x, $y, $HlandTown, 19) +
            countAround($land, $x, $y, $HlandNewtown, 19) +
	    countAround($land, $x, $y, $HlandBigtown, 19) +
	    countAround($land, $x, $y, $HlandBettown, 19) +
	    countAround($land, $x, $y, $HlandSkycity, 19) +
	    countAround($land, $x, $y, $HlandUmicity, 19) +
	    countAround($land, $x, $y, $HlandRizort, 19) +
	    countAround($land, $x, $y, $HlandKajino, 19) +
	    countAround($land, $x, $y, $HlandBigRizort, 19);
	    if($island->{'shouhi'} > $island->{'ene'}) {
		    $lv = 0;
                } elsif(($FarmCount > 0) && ($FarmcowCount > 0) && ($FarmchiCount > 0) && ($townCounta > 3)) {
		    $lv = 3;
                } elsif(($FarmCount > 0) && ($FarmcowCount > 0) && ($townCount > 2)) {
		    $lv = 2;
                } elsif(($FarmchiCount > 0) || ($FarmpicCount > 0) || ($FarmcowCount > 0)) {
		    $lv = 1;
                } else {
		    $lv = 0;
                }
	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandEneBo) {
	            $island->{'food'} -= $lv*5;

	} elsif($landKind == $HlandEneSo) {
		$landValue->[$x][$y] -= random(20);
		if($landValue->[$x][$y] <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}

	} elsif($landKind == $HlandEneAt) {
		if(random(1000) < (50-int($lv/100))) {
		    $AtAttackslog = 0;
		    my($sx, $sy, $i, $landKind, $landName, $lv, $point);
		    for($i = 0; $i < 19; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			    $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# �ϰϳ�Ƚ��
			if(($sx < 0) || ($sx >= $HislandSize) ||
			   ($sy < 0) || ($sy >= $HislandSize)) {
			    next;
			}
	                if((($landKind == $HlandTown) && ($lv > 1)) ||
			  (($landKind == $HlandMinato) && ($lv > 1)) ||
			  (($landKind == $HlandProcity) && ($lv > 1)) ||
			  (($landKind == $HlandFrocity) && ($lv > 1)) ||
			  (($landKind == $HlandNewtown) && ($lv > 1)) ||
			  (($landKind == $HlandBigtown) && ($lv > 1)) ||
			  (($landKind == $HlandBettown) && ($lv > 1)) ||
			  (($landKind == $HlandSkycity) && ($lv > 1)) ||
			  (($landKind == $HlandUmicity) && ($lv > 1)) ||
			  (($landKind == $HlandRizort) && ($lv > 1)) ||
			  (($landKind == $HlandKajino) && ($lv > 1)) ||
			  (($landKind == $HlandBigRizort) && ($lv > 1)) ||
			  (($landKind == $HlandShuto) && ($lv > 1)) ||
			  (($landKind == $HlandOnsen) && ($lv > 1))) {
	                    # Į
				$landValue->[$sx][$sy] -= random(25);
				if($lv <= 0) {
				    # ʿ�Ϥ��᤹
				    $land->[$sx][$sy] = $HlandPlains;
				    $landValue->[$sx][$sy] = 0;
				    next;
				}
				if($AtAttackslog <= 0) {
				$landKind = $land->[$x][$y];
				$lv = $landValue->[$x][$y];
				$landName = landName($landKind, $lv);
				logAtAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
				$AtAttackslog++;
				}
	                }
		    }
		}

	} elsif($landKind == $HlandHTFactory) {

		if ($island->{'pika'} > 0) {
                	$landValue->[$x][$y] += 2;
                	if($landValue->[$x][$y] > 500) {
                	    $landValue->[$x][$y] = 500;
                	}
		}

	} elsif($landKind == $HlandSHTF) {

		if ($island->{'pika'} > 0) {
                	$landValue->[$x][$y] += 1;
                	if($landValue->[$x][$y] > 500) {
                	    $landValue->[$x][$y] = 500;
                	}
		}

	} elsif($landKind == $HlandForest) {
	    my($forestCount) = countAround($land, $x, $y, $HlandForest, 19);
	    # ��
	    if($lv < 200+$forestCount*200) {
		# �ڤ����䤹
		$landValue->[$x][$y] += 1+random($forestCount)+$s08b;
	    }

	    if($lv > 200+$forestCount*200) {
		$landValue->[$x][$y] = 200+$forestCount*200;
	    }

	} elsif($landKind == $HlandTrain) {
	    if($lv == 10) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 11) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 12) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y - 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 5) || ($slv == 7) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 13) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 14) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y - 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 3) || ($slv == 6) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 15) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 16) {
		if(random(100) < 33) {
		$sx = $x + 1;
		$sy = $y - 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 5) || ($slv == 7) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } elsif(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 17) {
		if(random(100) < 33) {
		$sx = $x - 1;
		$sy = $y - 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 3) || ($slv == 6) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } elsif(random(100) < 50) {
		$sx = $x - 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 18) {
		if(random(100) < 50) {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 19) {
		if(random(100) < 50) {
		$sx = $x + 0;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x + 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "�����ż�", "($sx, $sy)");
		            }

			}
		}
	    }

	    if($lv == 20) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 21) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 22) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y - 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 5) || ($slv == 7) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 23) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 24) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y - 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 3) || ($slv == 6) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 25) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 26) {
		if(random(100) < 33) {
		$sx = $x + 1;
		$sy = $y - 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 5) || ($slv == 7) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } elsif(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 27) {
		if(random(100) < 33) {
		$sx = $x - 1;
		$sy = $y - 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 3) || ($slv == 6) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } elsif(random(100) < 50) {
		$sx = $x - 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 28) {
		if(random(100) < 50) {
		$sx = $x - 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x - 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		    $sx++;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    } elsif($lv == 29) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
	    } else {
		$sx = $x + 1;
		$sy = $y + 1;
		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}
		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			    if($island->{'shouhi'} > $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "��ʪ���", "($sx, $sy)");
		            }

			}
		}
	    }

	} elsif($landKind == $HlandKura) {
	    $seq = int($lv/100);
	    $choki = $lv%100;
	    if(random(100) < 9-$seq) {
		$choki = int($choki/100*random(100));
		$seq--;
			if($seq < 0) {
			$seq = 0;
			}
		$landValue->[$x][$y] = $seq*100+$choki;
		my($lName) = &landName($landKind, $lv);
		logKuralupin($id, $name, $lName, "($x, $y)");
	    }

	    if($anothermood == 1) {
		$choki -= int($choki/100*$seq);
			if($choki < 0) {
			$choki = 0;
			}
		$landValue->[$x][$y] = $seq*100+$choki;
	    }

	} elsif($landKind == $HlandHouse) {

		$zeikin = int($island->{'pop'}*($lv+1)*$island->{'eisei1'}/100);

		if($anothermood == 1) {
                    $island->{'money'} += $zeikin;
		}else{

		if($zeikin > 10000) {
		    if($HislandTurn % 5 == 0) {
                    $island->{'money'} += $zeikin;
		    }else{
		    }
		}elsif($zeikin > 5000) {
		    if($HislandTurn % 2 == 0) {
                    $island->{'money'} += $zeikin;
		    }else{
		    }
		}else{
                    $island->{'money'} += $zeikin;
		}

		}

	} elsif($landKind == $HlandDefence) {
	    if($lv == 1) {
		# �ɱһ��߼���
		my($lName) = &landName($landKind, $lv);
		logBombFire($id, $name, $lName, "($x, $y)");

		# �����ﳲ�롼����
		wideDamage($id, $name, $land, $landValue, $x, $y);
	    }
	} elsif($landKind == $HlandProcity) {
	    # �ɺ��Ի�
	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 100) {
		    $lv += random($addpop) + 1;
		    if($lv > 100) {
			$lv = 100;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 200) {
		$lv = 200;
	    }
	    $landValue->[$x][$y] = $lv;

	    if($lv == 200) {

	    my($i,$sx,$sy);
	    for($i = 1; $i < 7; $i++) {
	        $sx = $x + $ax[$i];
	        $sy = $y + $ay[$i];
	    if($land->[$sx][$sy] == $HlandMonster){
		# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��

		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

		    logBariaAttack($id, $name, $tName, "($sx, $sy)");
	    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 1;
	    next;
	    }
	    }
	    }

	} elsif($landKind == $HlandNewtown) {
	    # �˥塼�������
	my($townCount) =
	    countAround($land, $x, $y, $HlandTown, 19) +
	    countAround($land, $x, $y, $HlandProcity, 19) +
            countAround($land, $x, $y, $HlandNewtown, 19) +
	    countAround($land, $x, $y, $HlandBigtown, 19) +
	    countAround($land, $x, $y, $HlandBettown, 19) +
	    countAround($land, $x, $y, $HlandSkycity, 19) +
	    countAround($land, $x, $y, $HlandUmicity, 19) +
	    countAround($land, $x, $y, $HlandSeatown, 19) +
	    countAround($land, $x, $y, $HlandRizort, 19) +
	    countAround($land, $x, $y, $HlandKajino, 19) +
	    countAround($land, $x, $y, $HlandBigRizort, 19) +
	    countAround($land, $x, $y, $HlandShuto, 19) +
	    countAround($land, $x, $y, $HlandUmishuto, 19) +
	    countAround($land, $x, $y, $HlandMinato, 19) +
	    countAround($land, $x, $y, $HlandFrocity, 19) +
	    countAround($land, $x, $y, $HlandOnsen, 19) +
            countAround($land, $x, $y, $HlandSeacity, 19);
            if($townCount > 17) {
	        if(random(1000) < 3) {
		    if($lv > 295) {
		        $land->[$x][$y] = $HlandBigtown;
		    }
		}
	    }
	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 100) {
		    $lv += random($addpop) + 1;
		    if($lv > 100) {
			$lv = 100;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 300) {
		$lv = 300;
	    }
	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandBigtown) {


	my($monsterCount) =
	    countAround($land, $x, $y, $HlandMonster, 7);
            if($monsterCount > 0) {
	    $lv -= random(20)+10;
	    $landValue->[$x][$y] = $lv;
	    logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    }


	my($townCount) =
	    countAround($land, $x, $y, $HlandTown, 19) +
	    countAround($land, $x, $y, $HlandProcity, 19) +
            countAround($land, $x, $y, $HlandNewtown, 19) +
	    countAround($land, $x, $y, $HlandBigtown, 19) +
	    countAround($land, $x, $y, $HlandBettown, 19) +
	    countAround($land, $x, $y, $HlandSkycity, 19) +
	    countAround($land, $x, $y, $HlandUmicity, 19) +
	    countAround($land, $x, $y, $HlandSeatown, 19) +
	    countAround($land, $x, $y, $HlandRizort, 19) +
	    countAround($land, $x, $y, $HlandKajino, 19) +
	    countAround($land, $x, $y, $HlandBigRizort, 19) +
	    countAround($land, $x, $y, $HlandShuto, 19) +
	    countAround($land, $x, $y, $HlandUmishuto, 19) +
	    countAround($land, $x, $y, $HlandMinato, 19) +
	    countAround($land, $x, $y, $HlandFrocity, 19) +
	    countAround($land, $x, $y, $HlandOnsen, 19) +
            countAround($land, $x, $y, $HlandSeacity, 19);
	my($houseCount) =
	    countAround($land, $x, $y, $HlandHouse, 7);
            if(($island->{'shu'} == 0) &&
		($houseCount == 1) &&
		($townCount > 16) &&
		(random(1000) < 300)) {
		        $land->[$x][$y] = $HlandShuto;
			my($onm);
			$onm = $island->{'onm'};
			$island->{'totoyoso2'} = "$onm���ƥ���";
				logShuto($id, $name, landName($landKind, $lv), "$onm���ƥ���", "($x, $y)");
		    $island->{'shu'}++;
	    }
	    # �����ԻԷ�
	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 200) {
		    $lv += random($addpop) + 1;
		    if($lv > 200) {
			$lv = 200;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 500) {
		$lv = 500;
	    }
	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandSeatown) {
	    # ���쿷�ԻԷ�
	my($townCount) =
	    countAround($land, $x, $y, $HlandTown, 19) +
	    countAround($land, $x, $y, $HlandProcity, 19) +
            countAround($land, $x, $y, $HlandNewtown, 19) +
	    countAround($land, $x, $y, $HlandBigtown, 19) +
	    countAround($land, $x, $y, $HlandBettown, 19) +
	    countAround($land, $x, $y, $HlandSkycity, 19) +
	    countAround($land, $x, $y, $HlandUmicity, 19) +
	    countAround($land, $x, $y, $HlandSeatown, 19) +
	    countAround($land, $x, $y, $HlandRizort, 19) +
	    countAround($land, $x, $y, $HlandKajino, 19) +
	    countAround($land, $x, $y, $HlandBigRizort, 19) +
	    countAround($land, $x, $y, $HlandShuto, 19) +
	    countAround($land, $x, $y, $HlandUmishuto, 19) +
	    countAround($land, $x, $y, $HlandMinato, 19) +
	    countAround($land, $x, $y, $HlandFrocity, 19) +
	    countAround($land, $x, $y, $HlandOnsen, 19) +
            countAround($land, $x, $y, $HlandSeacity, 19);
	my($houseCount) =
	    countAround($land, $x, $y, $HlandHouse, 7);
            if(($island->{'shu'} == 0) &&
		($houseCount == 1) &&
		($townCount > 16) &&
		(random(1000) < 300)) {
		        $land->[$x][$y] = $HlandUmishuto;
			my($onm);
			$onm = $island->{'onm'};
			$island->{'totoyoso2'} = "$onm���ƥ���";
				logShuto($id, $name, landName($landKind, $lv), "$onm���ƥ���", "($x, $y)");
		    $island->{'shu'}++;
	    }
	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 250) {
		    $lv += random($addpop) + 1;
		    if($lv > 250) {
			$lv = 250;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 400) {
		$lv = 400;
	    }
	    $landValue->[$x][$y] = $lv;



	} elsif($landKind == $HlandBettown) {


	my($monsterCount) =
	    countAround($land, $x, $y, $HlandMonster, 7);
            if($monsterCount > 0) {
	    $lv -= random(20)+10;
	    $landValue->[$x][$y] = $lv;
	    logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    }

	my($shutoCount) =
	    countAround($land, $x, $y, $HlandShuto, 7) +
	    countAround($land, $x, $y, $HlandUmishuto, 7);
	my($betCount) =
	    countAround($land, $x, $y, $HlandBettown, 7);

	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ

		if(($island->{'shu'} > 0) &&
		  (($shutoCount > 0) ||
		   ($betCount > 1))) {

		if($lv < 1000) {
		    $lv += random($addpop) + 1;
		    if($lv > 1000) {
			$lv = 1000;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}

		}

	    }
	    if($lv > 2000) {
		$lv = 2000;
	    }
	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandSkycity) {


	my($monsterCount) =
	    countAround($land, $x, $y, $HlandMonster, 7);
            if($monsterCount > 0) {
	    $lv -= random(20)+10;
	    $landValue->[$x][$y] = $lv;
	    logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    }

	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ

		if($lv < 2250) {
		    $lv += random($addpop) + 1;
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}

	    }
	    if($lv > 3000) {
		$lv = 3000;
	    }
	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandUmicity) {

	my($monsterCount) =
	    countAround($land, $x, $y, $HlandMonster, 7);
            if($monsterCount > 0) {
	    $lv -= random(20)+10;
	    $landValue->[$x][$y] = $lv;
	    logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    }

	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ

		if($lv < 2500) {
		    $lv += random($addpop) + 1;
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}

	    }
	    if($lv > 3000) {
		$lv = 3000;
	    }
	    $landValue->[$x][$y] = $lv;

	} elsif(($landKind == $HlandShuto) ||
		($landKind == $HlandUmishuto)) {
	    # ���Է�

		if($island->{'shu'} > 1) {
		    $land->[$x][$y] = $HlandPlains2;
		    $landValue->[$x][$y] = 0;
		    $island->{'shu'} -= 1;
		}

	my($monsterCount) =
	    countAround($land, $x, $y, $HlandMonster, 7);
            if($monsterCount > 0) {
	    $lv -= random(100)+200;
	    $landValue->[$x][$y] = $lv;
	    logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if(($lv <= 0) &&
		   ($landKind == $HlandUmishuto)) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		    next;
		}
		if(($lv <= 0) &&
		   ($landKind == $HlandShuto)) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    }

	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 750) {
		    $lv += random($addpop) + 1;
		    if($lv > 750) {
			$lv = 750;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 4000) {
		$lv = 4000;
	    }
	    $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandRizort) {
	    # �꥾���ȷ�

    # �Ѹ��Ϥ�����͡�
    if(($lv < 400) && (rand(500) < 15+$s06b*2)) {
        my(@order) = randomArray($HislandNumber);
        my($migrate);

        # �Ѹ����õ��
        my($tIsland);
        my($n) = min($HislandNumber, 5);
        my($i);
        for($i = 0; $i < $n; $i++) { # ����ޤ�Ĵ�٤�
            $tIsland = $Hislands[$order[$i]];

	    $tetc5 = $tIsland->{'etc5'};
	    $tetc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($ts00,$ts01,$ts02,$ts03,$ts04,$ts05,$ts06,$ts07,$ts08,$ts09,$ts10,$ts11,$ts12,$ts13,$ts14,$ts15,$ts16,$ts17,$ts18,$ts19,$ts20,$ts21,$ts22,$ts23,$ts24,$ts25,$ts26,$ts27,$ts28,$ts29,$ts30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	    $ts06b = int($ts06/5);

            # �͸���¿����˴Ѹ�����
            if ($island->{'pop'} < $tIsland->{'pop'}) {
		my($seaCount) = countAround($land, $x, $y, $HlandSea, 19);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 19);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 19);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujo, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujokai, 19);
		my($umiamuCount) = countAround($land, $x, $y, $HlandUmiamu, 19);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 19);
		my($rizortCount) = (countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
                $landKind = $land->[$x][$y];
                $lv = $landValue->[$x][$y];
		$migrate = $seaCount*3 + $forestCount*3 + $mountainCount*3 + $parkCount*4 + $kyujoCount*4 + $umiamuCount*7 + $sunahamaCount*10 + $rizortCount*5 + $s06b*10 - $ts06b*10;

			if ($migrate < 0) {
			    $migrate = 1;
			}

		$lv += $migrate;
            logKankouMigrate($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, "($x, $y)", $migrate);
            }
                last if ($employed <= 0);
        }

            $island->{'eisei2'} += $migrate;
            $island->{'pop'} += $migrate;
            $tIsland->{'pop'} -= $migrate;

            # �Ѹ��ˤ��Ƥ��줿ʬ�͸�����
            my($tLand) = $tIsland->{'land'};
            my($tLandValue) = $tIsland->{'landValue'};
            my($employed) = $migrate;
            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $tLand->[$x][$y];
                $lv = $tLandValue->[$x][$y];

                if((($landKind == $HlandTown) && ($lv > 1)) ||
		  (($landKind == $HlandMinato) && ($lv > 1)) ||
		  (($landKind == $HlandProcity) && ($lv > 1)) ||
		  (($landKind == $HlandFrocity) && ($lv > 1)) ||
		  (($landKind == $HlandNewtown) && ($lv > 1)) ||
		  (($landKind == $HlandBigtown) && ($lv > 1)) ||
		  (($landKind == $HlandBettown) && ($lv > 1)) ||
		  (($landKind == $HlandSkycity) && ($lv > 1)) ||
		  (($landKind == $HlandUmicity) && ($lv > 1)) ||
		  (($landKind == $HlandSeatown) && ($lv > 1)) ||
		  (($landKind == $HlandRizort) && ($lv > 1)) ||
		  (($landKind == $HlandKajino) && ($lv > 1)) ||
		  (($landKind == $HlandBigRizort) && ($lv > 1)) ||
		  (($landKind == $HlandShuto) && ($lv > 1)) ||
		  (($landKind == $HlandUmishuto) && ($lv > 1)) ||
		  (($landKind == $HlandOnsen) && ($lv > 1)) ||
		  (($landKind == $HlandSeacity) && ($lv > 1))) {
                    # Į
                    $n = min($lv - 1, $employed);
                    $tLandValue->[$x][$y] -= $n;
                    $employed -= $n;

			if($tLandValue->[$x][$y] <= 0) {
			    $tLand->[$x][$y] = $HlandPlains;
			    $tLandValue->[$x][$y] = 0;
			}

                }
            }
	}

	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 10) {
		    $lv += random($addpop) + 1;
		    if($lv > 10) {
			$lv = 10;
		    }
		} else {
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 400) {
		$lv = 400;
	    }
	    $landValue->[$x][$y] = $lv;

		my($seaCount) = countAround($land, $x, $y, $HlandSea, 7);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 7);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 7);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 7);
		my($onsenCount) = countAround($land, $x, $y, $HlandOnsen, 7);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 7);
		my($kajinoCount) = countAround($land, $x, $y, $HlandKajino, 7);

		$miryoku = ((2*$seaCount/10)+(5*$forestCount/10)+(5*$mountainCount/10)+(20*$sunahamaCount/10)+(20*$onsenCount/10)+(10*$parkCount/10)+(2*$kajinoCount/10))+1;

            my($value);
            $value = $miryoku * ($lv+$island->{'eis1'}+$island->{'eis2'}+$island->{'eis3'}+$island->{'eis5'}+int($island->{'fore'}/10)+int($island->{'rena'}/25)-$island->{'monsterlive'}*100);

	    if($island->{'shouhi'} > $island->{'ene'}) {
            $value = int($value/2);
            }

            if ($value > 0) {
                $rizortincome += int($value);
		$island->{'money'} += int($value);
            }

	} elsif($landKind == $HlandBigRizort) {
	    # �꥾���ȷ�

    # �Ѹ��Ϥ�����͡�
    if(($lv < 1000) && (rand(500) < 20+$s06b*2)) {
        my(@order) = randomArray($HislandNumber);
        my($migrate);

        # �Ѹ����õ��
        my($tIsland);
        my($n) = min($HislandNumber, 5);
        my($i);
        for($i = 0; $i < $n; $i++) { # ����ޤ�Ĵ�٤�
            $tIsland = $Hislands[$order[$i]];

	    $tetc5 = $tIsland->{'etc5'};
	    $tetc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($ts00,$ts01,$ts02,$ts03,$ts04,$ts05,$ts06,$ts07,$ts08,$ts09,$ts10,$ts11,$ts12,$ts13,$ts14,$ts15,$ts16,$ts17,$ts18,$ts19,$ts20,$ts21,$ts22,$ts23,$ts24,$ts25,$ts26,$ts27,$ts28,$ts29,$ts30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	    $ts06b = int($ts06/5);

            # �͸���¿����˴Ѹ�����
            if ($island->{'pop'} < $tIsland->{'pop'}) {
		my($seaCount) = countAround($land, $x, $y, $HlandSea, 19);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 19);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 19);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujo, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujokai, 19);
		my($umiamuCount) = countAround($land, $x, $y, $HlandUmiamu, 19);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 19);
		my($rizortCount) = (countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
                $landKind = $land->[$x][$y];
                $lv = $landValue->[$x][$y];
		$migrate = $seaCount*3 + $forestCount*3 + $mountainCount*3 + $parkCount*4 + $kyujoCount*4 + $umiamuCount*7 + $sunahamaCount*10 + $rizortCount*5 + $s06b*10 - $ts06b*10;

			if ($migrate < 0) {
			    $migrate = 1;
			}

		$lv += $migrate;
            logKankouMigrate($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, "($x, $y)", $migrate);
            }
                last if ($employed <= 0);
        }

            $island->{'eisei2'} += $migrate;
            $island->{'pop'} += $migrate;
            $tIsland->{'pop'} -= $migrate;

            # �Ѹ��ˤ��Ƥ��줿ʬ�͸�����
            my($tLand) = $tIsland->{'land'};
            my($tLandValue) = $tIsland->{'landValue'};
            my($employed) = $migrate;
            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $tLand->[$x][$y];
                $lv = $tLandValue->[$x][$y];

                if((($landKind == $HlandTown) && ($lv > 1)) ||
		  (($landKind == $HlandMinato) && ($lv > 1)) ||
		  (($landKind == $HlandProcity) && ($lv > 1)) ||
		  (($landKind == $HlandFrocity) && ($lv > 1)) ||
		  (($landKind == $HlandNewtown) && ($lv > 1)) ||
		  (($landKind == $HlandBigtown) && ($lv > 1)) ||
		  (($landKind == $HlandBettown) && ($lv > 1)) ||
		  (($landKind == $HlandSkycity) && ($lv > 1)) ||
		  (($landKind == $HlandUmicity) && ($lv > 1)) ||
		  (($landKind == $HlandSeatown) && ($lv > 1)) ||
		  (($landKind == $HlandRizort) && ($lv > 1)) ||
		  (($landKind == $HlandKajino) && ($lv > 1)) ||
		  (($landKind == $HlandBigRizort) && ($lv > 1)) ||
		  (($landKind == $HlandShuto) && ($lv > 1)) ||
		  (($landKind == $HlandUmishuto) && ($lv > 1)) ||
		  (($landKind == $HlandOnsen) && ($lv > 1)) ||
		  (($landKind == $HlandSeacity) && ($lv > 1))) {
                    # Į
                    $n = min($lv - 1, $employed);
                    $tLandValue->[$x][$y] -= $n;
                    $employed -= $n;

			if($tLandValue->[$x][$y] <= 0) {
			    $tLand->[$x][$y] = $HlandPlains;
			    $tLandValue->[$x][$y] = 0;
			}

                }
            }
	}

	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 10) {
		    $lv += random($addpop) + 1;
		    if($lv > 10) {
			$lv = 10;
		    }
		} else {
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 1000) {
		$lv = 1000;
	    }
	    $landValue->[$x][$y] = $lv;

	my($monsterCount) =
	    countAround($land, $x, $y, $HlandMonster, 7);
            if($monsterCount > 0) {
	    $lv -= random(20)+10;
	    $landValue->[$x][$y] = $lv;
	    logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    }
	} elsif($landKind == $HlandKajino) {
	    # �꥾���ȷ�

    # �Ѹ��Ϥ�����͡�
    if(($lv < 2000) && (rand(500) < 15+$s06b*2)) {
        my(@order) = randomArray($HislandNumber);
        my($migrate);

        # �Ѹ����õ��
        my($tIsland);
        my($n) = min($HislandNumber, 5);
        my($i);
        for($i = 0; $i < $n; $i++) { # ����ޤ�Ĵ�٤�
            $tIsland = $Hislands[$order[$i]];

	    $tetc5 = $tIsland->{'etc5'};
	    $tetc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($ts00,$ts01,$ts02,$ts03,$ts04,$ts05,$ts06,$ts07,$ts08,$ts09,$ts10,$ts11,$ts12,$ts13,$ts14,$ts15,$ts16,$ts17,$ts18,$ts19,$ts20,$ts21,$ts22,$ts23,$ts24,$ts25,$ts26,$ts27,$ts28,$ts29,$ts30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	    $ts06b = int($ts06/5);

            # �͸���¿����˴Ѹ�����
            if ($island->{'pop'} < $tIsland->{'pop'}) {
		my($seaCount) = countAround($land, $x, $y, $HlandSea, 19);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 19);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 19);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujo, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujokai, 19);
		my($umiamuCount) = countAround($land, $x, $y, $HlandUmiamu, 19);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 19);
		my($rizortCount) = (countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
                $landKind = $land->[$x][$y];
                $lv = $landValue->[$x][$y];
		$migrate = $seaCount*3 + $forestCount*3 + $mountainCount*3 + $parkCount*4 + $kyujoCount*4 + $umiamuCount*7 + $sunahamaCount*10 + $rizortCount*5 + $s06b*10 - $ts06b*10;

			if ($migrate < 0) {
			    $migrate = 1;
			}

		$lv += $migrate;
            logKankouMigrate($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, "($x, $y)", $migrate);
            }
                last if ($employed <= 0);
        }

            $island->{'eisei2'} += $migrate;
            $island->{'pop'} += $migrate;
            $tIsland->{'pop'} -= $migrate;

            # �Ѹ��ˤ��Ƥ��줿ʬ�͸�����
            my($tLand) = $tIsland->{'land'};
            my($tLandValue) = $tIsland->{'landValue'};
            my($employed) = $migrate;
            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $tLand->[$x][$y];
                $lv = $tLandValue->[$x][$y];

                if((($landKind == $HlandTown) && ($lv > 1)) ||
		  (($landKind == $HlandMinato) && ($lv > 1)) ||
		  (($landKind == $HlandProcity) && ($lv > 1)) ||
		  (($landKind == $HlandFrocity) && ($lv > 1)) ||
		  (($landKind == $HlandNewtown) && ($lv > 1)) ||
		  (($landKind == $HlandBigtown) && ($lv > 1)) ||
		  (($landKind == $HlandBettown) && ($lv > 1)) ||
		  (($landKind == $HlandSkycity) && ($lv > 1)) ||
		  (($landKind == $HlandUmicity) && ($lv > 1)) ||
		  (($landKind == $HlandSeatown) && ($lv > 1)) ||
		  (($landKind == $HlandRizort) && ($lv > 1)) ||
		  (($landKind == $HlandKajino) && ($lv > 1)) ||
		  (($landKind == $HlandBigRizort) && ($lv > 1)) ||
		  (($landKind == $HlandShuto) && ($lv > 1)) ||
		  (($landKind == $HlandUmishuto) && ($lv > 1)) ||
		  (($landKind == $HlandOnsen) && ($lv > 1)) ||
		  (($landKind == $HlandSeacity) && ($lv > 1))) {
                    # Į
                    $n = min($lv - 1, $employed);
                    $tLandValue->[$x][$y] -= $n;
                    $employed -= $n;

			if($tLandValue->[$x][$y] <= 0) {
			    $tLand->[$x][$y] = $HlandPlains;
			    $tLandValue->[$x][$y] = 0;
			}

                }
            }
	}

	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 10) {
		    $lv += random($addpop) + 1;
		    if($lv > 10) {
			$lv = 10;
		    }
		} else {
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 2500) {
		$lv = 2500;
	    }
	    $landValue->[$x][$y] = $lv;

		my($seaCount) = countAround($land, $x, $y, $HlandSea, 7);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 7);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 7);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 7);
		my($onsenCount) = countAround($land, $x, $y, $HlandOnsen, 7);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 7);
		my($kajinoCount) = countAround($land, $x, $y, $HlandRizort, 7);

		$miryoku = ((2*$seaCount/10)+(5*$forestCount/10)+(5*$mountainCount/10)+(20*$sunahamaCount/10)+(20*$onsenCount/10)+(10*$parkCount/10)+(2*$kajinoCount/10))+1;

            my($value);
            $value = int(($lv+$island->{'eis1'}+$island->{'eis2'}+$island->{'eis3'}+$island->{'eis5'}+int($island->{'fore'}/10)+int($island->{'rena'}/10)-$island->{'monsterlive'}*100) / 5 * $miryoku);

	    if($island->{'shouhi'} > $island->{'ene'}) {
            $value = -($value*10);

		$lv -= (random(250) + 100);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
		$landValue->[$x][$y] = $lv;

            }

                $rizortincome += int($value);
		$island->{'money'} += int($value);

	my($monsterCount) =
	    countAround($land, $x, $y, $HlandMonster, 7);
            if($monsterCount > 0) {
	    $lv -= random(20)+10;
	    $landValue->[$x][$y] = $lv;
	    logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    }

	} elsif($landKind == $HlandOnsen) {
	    # ������
	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 50) {
		    $lv += random($addpop) + 1;
		    if($lv > 50) {
			$lv = 50;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 100) {
		$lv = 100;
	    }
	    $landValue->[$x][$y] = $lv;

            my($nt) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
            my($value);
            $value = random($nt * 20 + $lv * 5 + int($island->{'pop'} / 20)) + random(100) + 100;
            if ($value > 0) {
                $island->{'money'} += $value;

                # ��������
                my($str) = "$value$HunitMoney";
                logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str);
            }

	    # �ϳ�Ƚ��
	    if(random(1000) < 10) {
		# �ϳ�
		logOilEnd($id, $name, landName($landKind, $lv), "($x, $y)");
		$land->[$x][$y] = $HlandMountain;
		$landValue->[$x][$y] = 0;
	    }

	} elsif($landKind == $HlandOil) {
	    # ��������
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = $HoilMoney+ random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    $oilincome += $value;

	    # �ϳ�Ƚ��
	    if(random(1000) < $HoilRatio) {
		# �ϳ�
		logOilEnd($id, $name, $lName, "($x, $y)");
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 0;
	    }

	} elsif(($landKind == $HlandSea) && ($lv == 1)) {
	    # ����
	    if(random(100) < 5) {

		$land->[$x][$y] = $HlandSunahama;
		$landValue->[$x][$y] = 0;

	    }
	    if(random(100) < 1) {

		$land->[$x][$y] = $HlandIce;
		$landValue->[$x][$y] = 0;

	    }

	} elsif($landKind == $HlandSunahama) {
	    # ����
	    if(random(100) < 30) {

		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 1;

	    }

	} elsif($landKind == $HlandIce) {
	    # ����
	    my($lv) = $landValue->[$x][$y];

	    if($lv > 0) {
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = $lv * 25 + random(501);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logOilMoney($id, $name, $lName, "($x, $y)", $str);
	    }

	    if(random(100) < 10) {
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 1;
	    }

	} elsif($landKind == $HlandSeki) {
	    # �ؽ�
	    if(random(1000) < 7) {

	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = $HoilMoney+ random(1001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";

	    # ��������
	    logSekiMoney($id, $name, $lName, "($x, $y)", $str);

	    }

	} elsif($landKind == $HlandYakusho) {

		if(($island->{'co0'} > 0) &&
		   ($island->{'co01'} > 0) &&
		   ($island->{'co2'} > 0) &&
		   ($island->{'co3'} > 0) &&
		   ($island->{'co4'} > 0) &&
		   ($island->{'co5'} > 0) &&
		   ($island->{'co6'} > 0) &&
		   ($island->{'co7'} > 0) &&
		   ($island->{'co8'} > 0) &&
		   ($island->{'eis7'} > 1000000) &&
		   ($island->{'rena'} > 10000) &&
		   ($island->{'pts'} > $HouseLevel7)) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 77;
		}

	} elsif($landKind == $HlandGold) {
	    # �⻳
	    my($lv) = $landValue->[$x][$y];
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = $lv * 25 + random(501);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";

	    # ��������
	    logOilMoney($id, $name, $lName, "($x, $y)", $str);

	    # �ϳ�Ƚ��
	    if(random(100) < 7) {
		# �ϳ�
		logGoldEnd($id, $name, $lName, "($x, $y)");
		$land->[$x][$y] = $HlandMountain;
	    }

        } elsif($landKind == $HlandPark) {
            # ͷ����
            if ($island->{'par'} > 5) {
            } else {
            my($lName);
            $lName = landName($landKind, $lv);
            my($nv) = (countAround($land, $x, $y, $HlandPark, 7) + countAround($land, $x, $y, $HlandKyujo, 7) + countAround($land, $x, $y, $HlandKyujokai, 7) + countAround($land, $x, $y, $HlandUmiamu, 7));
            my($nx) = $nv + 10;
            my($value);
            $value = int(int($island->{'pop'} / 50) * 3 * $nx / 10);

	    if($island->{'shouhi'} > $island->{'ene'}) {
            $value = int($value/10);
            }

            if ($value > 0) {
                $island->{'money'} += $value;
            $str = "$value$HunitMoney";
	    $parkincome += $value;
            }
            }

            # ���٥��Ƚ��
            if(random(100) < 3) { # �西���� 30% �γ�Ψ�ǥ��٥�Ȥ�ȯ������
                # ͷ���ϤΥ��٥��
                $value = int($island->{'pop'} / 50) * 10; # �͸�����ͤ��Ȥ�1000�ȥ�ο�������
                $island->{'food'} -= $value;
                $str = "$value$HunitFood";

                logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value > 0);
            }

            # Ϸ�ಽȽ��
            if(random(100) < 2) {
                # ���ߤ�Ϸ�ಽ���������ı�
                logParkEnd($id, $name, landName($landKind, $lv), "($x, $y)");
                $land->[$x][$y] = $HlandPlains;
                $landValue->[$x][$y] = 0;
            }


        } elsif($landKind == $HlandZoo) {

	    $etc6 = $island->{'etc6'};
	    $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	    ($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

	    $zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;
	    $zookazus = $z0*2+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8*2+$z9+$z10+$z11+$z12*2+$z13*3+$z14*3+$z15*3+$z16*3+$z17*4+$z18*4+$z19*5+$z20*4+$z21*5+$z22*3+$z23*3+$z24*3+$z25*3+$z26*3+$z27*3+$z28*4+$z29+$z30*4;

            # ͷ����
            if ($zooflag > 0) {

            } else {

	    $zooflag = 1;
	    $mshurui = 0;
	    foreach $i (0..30) {
		    if($z->{"$i"} > 0) {
			$mshurui++;
		    }
	    }

            my($lName);
            $lName = landName($landKind, $lv);
            my($value);
            $value = $zookazus*15+$mshurui*150;
            $valuef = $zookazu*250;

	    if($island->{'shouhi'} > $island->{'ene'}) {
            $value = int($value/10);
            }


            if(random(1000) < 25 + $s08) {
		my($i,$sx,$sy);
		my($zlv) = (0);
		for($i = 0; $i < $HpointNumber; $i++){
		    $sx = $Hrpx[$i];
		    $sy = $Hrpy[$i];
			if($land->[$sx][$sy] == $HlandZoo){
			    $zlv += $landValue->[$sx][$sy];
			}
		}

		my($siire);
		$siire = random(12);
	            if(random(100) < 20) {
			$siire = random(10)+13;
	            }

		$prize = $island->{'prize'};
		my($flags, $monsters, $turns);
		$prize =~ /([0-9]*),([0-9]*),(.*)/;
		$flags = $1;
		$monsters= $2;
		$turns = $3;
		$prize = '';
		$f = 1;
		for($i = 0; $i < $HmonsterNumber; $i++) {
		    if($monsters & $f) {
			$taiji->{"$i"}++;
		    }
		    $f *= 2;
		}

		if(($taiji->{"$siire"} > 0) && ($zlv > $zookazu)) {
		$z->{"$siire"}++;
		$value = $value*$siire;
                logSiire($id, $name, landName($landKind, $lv), "$HmonsterName[$siire]", "($x, $y)");
		$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
		}

            }

            if ($value > 0) {
                $island->{'money'} += $value;
                # ��������
                my($str) = "$value$HunitMoney";
                my($str2) = "$valuef$HunitFood";
                logOilMoney2($id, $name, landName($landKind, $lv), "($x, $y)", $str, $str2);
            }

            }


		if(($island->{'rena'} < $zookazus*25) && (random(100) < 15)) {
		$nigekaiju = random(30);
	            if ($z->{"$nigekaiju"} > 0) {
			$z->{"$nigekaiju"} -= 1;
			$kind = $nigekaiju;
			$lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
			$land->[$x][$y] = $HlandMonster;
			$landValue->[$x][$y] = $lv;
			my($mKind, $mName, $mHp) = monsterSpec($lv);
			logNige($id, $name, landName($landKind, $lv), $mName, "($x, $y)");
			logMonsMove($id, $name, landName($landKind, $lv), "($x, $y)", $mName);
			$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
	            }
		}

		if(($island->{'rena'} < $zookazus*50) || ($island->{'shouhi'} > $island->{'ene'})) {
		$nigekaiju = random(30);
	            if ($z->{"$nigekaiju"} > 0) {
			$nigeflag = 0;
			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
			    $sx = $x + $ax[$i];
			    $sy = $y + $ay[$i];

			    # �Ԥˤ�����Ĵ��
			    if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			    }

			    $landKind = $land->[$sx][$sy];
			    $lv = $landValue->[$sx][$sy];
			    $point = "($sx, $sy)";

			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {
			    } else {
				# �ϰ���ξ��
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandSea) ||
				   ($landKind == $HlandIce) ||
				   ($landKind == $HlandOil) ||
				   ($landKind == $HlandFune) ||
				   ($landKind == $HlandFrocity) ||
				   ($landKind == $HlandUmiamu) ||
				   ($landKind == $HlandSeacity) ||
				   ($landKind == $HlandSeatown) ||
				   ($landKind == $HlandMonster) ||
				   ($landKind == $HlandZoo) ||
				   ($landKind == $HlandUmishuto) ||
				   ($landKind == $HlandSbase)) {
				} else {
				    if ($nigeflag == 0) {
					$nigeflag++;
					$z->{"$nigekaiju"} -= 1;
					$kind = $nigekaiju;
					$lv = $lv = ($kind << 4)
					+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
					$land->[$sx][$sy] = $HlandMonster;
					$landValue->[$sx][$sy] = $lv;
					my($mKind, $mName, $mHp) = monsterSpec($lv);
					logNige($id, $name, landName($landKind, $lv), $mName, "($x, $y)");
					$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
				    }
				}
			    }

			}
	            }
		}

        } elsif($landKind == $HlandKyujokai) {

	$yosengameendm=0;
	if($HmaxIsland < 21) {
	    $hcgameseigen=1;
	} else {
	    $hcgameseigen=3;
	}

	$eisei4 = $island->{'eisei4'};
	$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);

	    if(($HislandTurn % 100) == 0) {
		$stwin = 0;
		$stdrow = 0;
		$stlose = 0;
		$stshoka = 1;

		if($island->{'hcsankaflag'} == 0) {
		$stsanka++;
		$island->{'hcsankaflag'} = 1;
		}


		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

		if ($stsanka == 1) {
		$island->{'stsankahantei'}++;
		}

	    }

	    foreach $i (1..10) {
	    if(($HislandTurn % 100) == $i) {

		if(($stshoka == 1) &&
		   ($yosengameendm == 0) &&
		   ($yosengameend < $hcgameseigen)) {
	        my($tIsland);
	        my($i);
	        for($i = 0; $i < $HislandNumber; $i++) {
	            $tIsland = $Hislands[$i];

		    if ($island->{'id'} == $tIsland->{'id'}){
		    } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		    if (($tStshoka == 1) &&
			($yosengameendm == 0) &&
			($yosengameend < $hcgameseigen)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 5; $k++) {
			    if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			    }
			}
			for($k = 0; $k < 3; $k++) {
			    if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			    }
			}

			if($goal > $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka++;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($id, $name, "����", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($uphey-$tuphey)/2)+5;
				if($stup == 0) {
				    $tSto += $uppoint;
				    $tStd += $uppoint;
				} elsif($stup == 1) {
				    $tStd += $uppoint;
				    $tStk += $uppoint;
				} else {
				    $tStk += $uppoint;
				    $tSto += $uppoint;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$stshoka++;
			$tStshoka++;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "����", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($tuphey-$uphey)/2)+5;
				if($stup == 0) {
				    $sto += $uppoint;
				    $std += $uppoint;
				} elsif($stup == 1) {
				    $std += $uppoint;
				    $stk += $uppoint;
				} else {
				    $stk += $uppoint;
				    $sto += $uppoint;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup ͽ���裱��", $goal, $tgoal);

		    }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	    }
	    }

	    if(($HislandTurn % 100) == 11) {
		if($stshoka == 1) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup ͽ���裱������ﾡ");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	    }
	    }

	    foreach $i (11..20) {
	    if(($HislandTurn % 100) == $i) {

		if(($stshoka == 2) &&
		   ($yosengameendm == 0) &&
		   ($yosengameend < $hcgameseigen)) {
	        my($tIsland);
	        my($i);
	        for($i = 0; $i < $HislandNumber; $i++) {
	            $tIsland = $Hislands[$i];

		    if ($island->{'id'} == $tIsland->{'id'}){
		    } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		    if (($tStshoka == 2) &&
			($yosengameendm == 0) &&
			($yosengameend < $hcgameseigen)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 5; $k++) {
			    if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			    }
			}
			for($k = 0; $k < 3; $k++) {
			    if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			    }
			}

			if($goal > $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka++;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($id, $name, "����", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($uphey-$tuphey)/2)+5;
				if($stup == 0) {
				    $tSto += $uppoint;
				    $tStd += $uppoint;
				} elsif($stup == 1) {
				    $tStd += $uppoint;
				    $tStk += $uppoint;
				} else {
				    $tStk += $uppoint;
				    $tSto += $uppoint;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$stshoka++;
			$tStshoka++;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "����", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($tuphey-$uphey)/2)+5;
				if($stup == 0) {
				    $sto += $uppoint;
				    $std += $uppoint;
				} elsif($stup == 1) {
				    $std += $uppoint;
				    $stk += $uppoint;
				} else {
				    $stk += $uppoint;
				    $sto += $uppoint;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup ͽ���裲��", $goal, $tgoal);

		    }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	    }
	    }

	    if(($HislandTurn % 100) == 21) {
		if($stshoka == 2) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup ͽ���裲������ﾡ");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	    }
	    }

	    foreach $i (21..30) {
	    if(($HislandTurn % 100) == $i) {

		if(($stshoka == 3) &&
		   ($yosengameendm == 0) &&
		   ($yosengameend < $hcgameseigen)) {
	        my($tIsland);
	        my($i);
	        for($i = 0; $i < $HislandNumber; $i++) {
	            $tIsland = $Hislands[$i];

		    if ($island->{'id'} == $tIsland->{'id'}){
		    } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		    if (($tStshoka == 3) &&
			($yosengameendm == 0) &&
			($yosengameend < $hcgameseigen)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 5; $k++) {
			    if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			    }
			}
			for($k = 0; $k < 3; $k++) {
			    if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			    }
			}

			if($goal > $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka++;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($id, $name, "����", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($uphey-$tuphey)/2)+5;
				if($stup == 0) {
				    $tSto += $uppoint;
				    $tStd += $uppoint;
				} elsif($stup == 1) {
				    $tStd += $uppoint;
				    $tStk += $uppoint;
				} else {
				    $tStk += $uppoint;
				    $tSto += $uppoint;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$stshoka++;
			$tStshoka++;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "����", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($tuphey-$uphey)/2)+5;
				if($stup == 0) {
				    $sto += $uppoint;
				    $std += $uppoint;
				} elsif($stup == 1) {
				    $std += $uppoint;
				    $stk += $uppoint;
				} else {
				    $stk += $uppoint;
				    $sto += $uppoint;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup ͽ���裳��", $goal, $tgoal);

		    }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	    }
	    }

	    if(($HislandTurn % 100) == 31) {
		if($stshoka == 3) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup ͽ���裳������ﾡ");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	    }
	    }

	    foreach $i (31..40) {
	    if(($HislandTurn % 100) == $i) {

		if(($stshoka == 4) &&
		   ($yosengameendm == 0) &&
		   ($yosengameend < $hcgameseigen)) {
	        my($tIsland);
	        my($i);
	        for($i = 0; $i < $HislandNumber; $i++) {
	            $tIsland = $Hislands[$i];

		    if ($island->{'id'} == $tIsland->{'id'}){
		    } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		    if (($tStshoka == 4) &&
			($yosengameendm == 0) &&
			($yosengameend < $hcgameseigen)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 5; $k++) {
			    if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			    }
			}
			for($k = 0; $k < 3; $k++) {
			    if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			    }
			}

			if($goal > $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka++;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($id, $name, "����", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($uphey-$tuphey)/2)+5;
				if($stup == 0) {
				    $tSto += $uppoint;
				    $tStd += $uppoint;
				} elsif($stup == 1) {
				    $tStd += $uppoint;
				    $tStk += $uppoint;
				} else {
				    $tStk += $uppoint;
				    $tSto += $uppoint;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$stshoka++;
			$tStshoka++;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "����", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($tuphey-$uphey)/2)+5;
				if($stup == 0) {
				    $sto += $uppoint;
				    $std += $uppoint;
				} elsif($stup == 1) {
				    $std += $uppoint;
				    $stk += $uppoint;
				} else {
				    $stk += $uppoint;
				    $sto += $uppoint;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup ͽ���裴��", $goal, $tgoal);

		    }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	    }
	    }

	    if(($HislandTurn % 100) == 41) {
		if($stshoka == 4) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup ͽ���裴������ﾡ");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	    }
	    }

	    foreach $i (42..46) {
	    if(($HislandTurn % 100) == $i) {

		if($stshoka < 6) {
		$stshoka = 11;
		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
		}

		if(($stshoka == 6) &&
		   ($yosengameendm == 0) &&
		   ($yosengameend < 1)) {
	        my($tIsland);
	        my($i);
	        for($i = 0; $i < $HislandNumber; $i++) {
	            $tIsland = $Hislands[$i];

		    if ($island->{'id'} == $tIsland->{'id'}){
		    } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		    if (($tStshoka == 6) &&
			($yosengameendm == 0) &&
			($yosengameend < 1)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 3; $k++) {
			    if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			    }
			}
			for($k = 0; $k < 3; $k++) {
			    if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			    }
			}
			if($goal == $tgoal) {
				if(random(100) < 60) {
				    $goal++;
				} else {
				    $tgoal++;
				}
			}
			if($goal > $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka = 12;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($id, $name, "��辡�ʽ�", $str);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				    $tSto += 30;
				} elsif($stup == 1) {
				    $tStd += 30;
				} else {
				    $tStk += 30;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$tStshoka++;
			$stshoka = 12;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "��辡�ʽ�", $str);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				    $sto += 30;
				} elsif($stup == 1) {
				    $std += 30;
				} else {
				    $stk += 30;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup �ࡹ�辡��", $goal, $tgoal);

		    }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	    }
	    }

	    if(($HislandTurn % 100) == 46) {
		if($stshoka == 6) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup �ࡹ�辡������ﾡ");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	    }
	    }

	    foreach $i (47..49) {
	    if(($HislandTurn % 100) == $i) {

		if(($stshoka == 7) &&
		   ($yosengameendm == 0) &&
		   ($yosengameend < 1)) {
	        my($tIsland);
	        my($i);
	        for($i = 0; $i < $HislandNumber; $i++) {
	            $tIsland = $Hislands[$i];

		    if ($island->{'id'} == $tIsland->{'id'}){
		    } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		    if (($tStshoka == 7) &&
			($yosengameendm == 0) &&
			($yosengameend < 1)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 3; $k++) {
			    if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			    }
			}
			for($k = 0; $k < 3; $k++) {
			    if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			    }
			}
			if($goal == $tgoal) {
				if(random(100) < 60) {
				    $goal++;
				} else {
				    $tgoal++;
				}
			}
			if($goal > $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka = 13;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($id, $name, "�辡�ʽ�", $str);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				    $tSto += 30;
				} elsif($stup == 1) {
				    $tStd += 30;
				} else {
				    $tStk += 30;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$tStshoka++;
			$stshoka = 13;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "�辡�ʽ�", $str);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				    $sto += 30;
				} elsif($stup == 1) {
				    $std += 30;
				} else {
				    $stk += 30;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup ��辡��", $goal, $tgoal);

		    }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	    }
	    }

	    if(($HislandTurn % 100) == 49) {
		if($stshoka == 7) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup ��辡������ﾡ");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	    }
	    }

	    foreach $i (50..51) {
	    if(($HislandTurn % 100) == $i) {

		if(($stshoka == 8) &&
		   ($yosengameendm == 0) &&
		   ($yosengameend < 1)) {
	        my($tIsland);
	        my($i);
	        for($i = 0; $i < $HislandNumber; $i++) {
	            $tIsland = $Hislands[$i];

		    if ($island->{'id'} == $tIsland->{'id'}){
		    } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		    if (($tStshoka == 8) &&
			($yosengameendm == 0) &&
			($yosengameend < 1)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 3; $k++) {
			    if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			    }
			}
			for($k = 0; $k < 3; $k++) {
			    if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			    }
			}
			if($goal == $tgoal) {
				if(random(100) < 60) {
				    $goal++;
				} else {
				    $tgoal++;
				}
			}
			if($goal > $tgoal) {
			$stwin++;
			$stwint++;
			$styusho++;
			$stshoka++;
			$tStshoka = 14;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000)*2;

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "Auction�����$value$HunitMoney";

				$yushouflag = 1;
				$yushounamber = $island->{'id'};
				$yushounamber2 = $tIsland->{'id'};

				logHCwin($id, $name, "ͥ��", $str);
				$hcturn = int($HislandTurn/100)*100;
				logHCwintop($id, $name, $hcturn);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				    $tSto += 50;
				} elsif($stup == 1) {
				    $tStd += 50;
				} else {
				    $tStk += 50;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$tStyusho++;
			$tStshoka++;
			$stshoka = 14;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000)*2;

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "Auction�����$value$HunitMoney";

				$yushouflag = 2;
				$yushounamber = $tIsland->{'id'};
				$yushounamber2 = $island->{'id'};

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "ͥ��", $str);
				$hcturn = int($HislandTurn/100)*100;
				logHCwintop($tIsland->{'id'}, $tIsland->{'name'}, $hcturn);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				    $sto += 50;
				} elsif($stup == 1) {
				    $std += 50;
				} else {
				    $stk += 50;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup �辡��", $goal, $tgoal);

		    }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	    }
	    }

	    if(($HislandTurn % 100) == 51) {
		if($stshoka == 8) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$styusho++;
			logHCantiwin($id, $name, "Hakoniwa Cup �辡������ﾡ");
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000)*2;

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "Auction�����$value$HunitMoney";

				logHCwin($id, $name, "�Ȥꤢ������ͥ��", $str);
				$hcturn = int($HislandTurn/100)*100;
				logHCwintop($id, $name, $hcturn);
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	    }
	    }

	    if(($HislandTurn % 100) == 52) {
		if($stshoka != 9) {
		$stshoka = 10;
		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
		}
	    }

	    if(($stshoka == 10) ||
		($stshoka == 11)) {
		my($stup);
		$stup = random(3);
		if($stup == 0) {
		    $sto++;
		} elsif($stup == 1) {
		    $std++;
		} else {
		   $stk++;
		}
		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	    }

            # �����
            if (($island->{'kyu'} > 1) ||
		($island->{'amu'} > 1)) {
            } else {
            my($nt) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19) - 6);
            my($ns) = ( 1 + 2 * countAround($land, $x, $y, $HlandPark, 19));
            my($nr) = ( 1 + 3 * countAround($land, $x, $y, $HlandUmiamu, 19));
            my($nu) = ( 10 + random(10));
            my($value);
            $value = ($nt * $nu * $ns * $nr + int($island->{'pop'} / 25));

	    if($island->{'shouhi'} > $island->{'ene'}) {
            $value = int($value/5);
            }

            if ($value > 0) {
                $island->{'money'} += $value;

                # ��������
                my($str) = "$value$HunitMoney";
                logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str);
            }
            }

            # ���٥��Ƚ��
            if(random(100) < 10) { # �西���� 30% �γ�Ψ�ǥ��٥�Ȥ�ȯ������
                # ����Υ��٥��
                $value = int($island->{'pop'} / 50) * 10; # �͸�����ͤ��Ȥ�1000�ȥ�ο�������
                $island->{'food'} -= $value;
                $str = "$value$HunitFood";

                logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value > 0);
            }


        } elsif($landKind == $HlandKyujo) {
            # ����
            if (($island->{'kyu'} > 1) ||
		($island->{'amu'} > 1)) {
            } else {
            my($nt) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19) - 6);
            my($ns) = ( 1 + 2 * countAround($land, $x, $y, $HlandPark, 19));
            my($nr) = ( 1 + 3 * countAround($land, $x, $y, $HlandUmiamu, 19));
            my($nu) = ( 10 + random(10));
            my($value);
            $value = ($nt * $nu * $ns * $nr + int($island->{'pop'} / 25));

	    if($island->{'shouhi'} > $island->{'ene'}) {
            $value = int($value/5);
            }

            if ($value > 0) {
                $island->{'money'} += $value;

                # ��������
                my($str) = "$value$HunitMoney";
                logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str);
            }
            }

            # ���٥��Ƚ��
            if(random(100) < 10) { # �西���� 30% �γ�Ψ�ǥ��٥�Ȥ�ȯ������
                # ����Υ��٥��
                $value = int($island->{'pop'} / 50) * 10; # �͸�����ͤ��Ȥ�1000�ȥ�ο�������
                $island->{'food'} -= $value;
                $str = "$value$HunitFood";

                logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value > 0);
            }

            # Ϸ�ಽȽ��
            if(random(100) < 1) {
                # ���ߤ�Ϸ�ಽ���������ı�
                logParkEnd($id, $name, landName($landKind, $lv), "($x, $y)");
                $land->[$x][$y] = $HlandPlains;
                $landValue->[$x][$y] = 0;
            }
	    if(random(100) < 3) {
	        my($value, $str, $lName);
	        $lName = landName($landKind, $lv);
	        $value = 500+ random(500);
	        $island->{'money'} += $value;
	        $str = "$value$HunitMoney";
                # ��������
                logYusho($id, $name, $lName, "($x, $y)", $str) if ($value > 0);
	    }

        } elsif($landKind == $HlandUmiamu) {
            # �����ߤ�
            if (($island->{'kyu'} > 1) ||
		($island->{'amu'} > 1)) {
            } else {
            my($no) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19) - 3);
            my($np) = ( 1 + 3 * countAround($land, $x, $y, $HlandPark, 19));
            my($nq) = ( 1 + 4 * countAround($land, $x, $y, $HlandKyujo, 19));
            my($nqk) = ( 1 + 4 * countAround($land, $x, $y, $HlandKyujokai, 19));
            my($nu) = ( 5 + random(5));
            my($value);
            $value = ($no * $np * $nq * $nqk * $nu + int($island->{'pop'} / 25)+ random(200));

	    if($island->{'shouhi'} > $island->{'ene'}) {
            $value = int($value/7);
            }

            if ($value > 0) {
                $island->{'money'} += $value;

                # ��������
                my($str) = "$value$HunitMoney";
                logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str);
            }
            }

            # ���٥��Ƚ��
            if(random(100) < 10) { # �西���� 30% �γ�Ψ�ǥ��٥�Ȥ�ȯ������
                # ����Υ��٥��
                $value = int($island->{'pop'} / 50) * 10; # �͸�����ͤ��Ȥ�1000�ȥ�ο�������
                $island->{'food'} -= $value;
                $str = "$value$HunitFood";

                logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value > 0);
            }

        } elsif(($landKind == $HlandRottenSea) && ($lv < 20)) {
        # �峤
	$landValue->[$x][$y]++;
        my($i, $sx, $sy, $kind, $lv);
            for($i = 1; $i < 7; $i++) {
                $sx = $x + $ax[$i];
                $sy = $y + $ay[$i];

                    # �Ԥˤ�����Ĵ��
                    if((($sy % 2) == 0) && (($y % 2) == 1)) {
                        $sx--;
                    }

		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    # �ϰϳ�
		    next;
		}

                $landKind = $land->[$sx][$sy];
                $lv   = $landValue->[$sx][$sy];
	        $lName = landName($landKind, $lv);
		# �������𡢳����Իԡ����ġ����á�������ǰ��ʳ�
		if(($land->[$sx][$sy] != $HlandSea) &&
		   ($land->[$sx][$sy] != $HlandSbase) &&
		   ($land->[$sx][$sy] != $HlandIce) &&
		   ($land->[$sx][$sy] != $HlandSeacity) &&
		   ($land->[$sx][$sy] != $HlandSeatown) &&
		   ($land->[$sx][$sy] != $HlandUmishuto) &&
		   ($land->[$sx][$sy] != $HlandFune) &&
		   ($land->[$sx][$sy] != $HlandFrocity) &&
		   ($land->[$sx][$sy] != $HlandUmiamu) &&
		   ($land->[$sx][$sy] != $HlandOil) &&
		   ($land->[$sx][$sy] != $HlandNursery) &&
		   ($land->[$sx][$sy] != $HlandRottenSea)) {
	        my($n) = countAround($land, $sx, $sy, $HlandRottenSea, 7);
	        my($point) = "($sx, $sy)";
	            if (($n >= 4) && ((rand(1000)+$island->{'m73'}*100) < 300)) {
	                # ���Ϥ��峤�����ޥ��ʾ夢��� ����% �γ�Ψ�ǰ��߹���
	                 logRottenSeaGrow($id, $name, $lName, $point);
	                 $land->[$sx][$sy] = $HlandRottenSea;
	                 $landValue->[$sx][$sy] = 1;
	            } elsif ($n && ((rand(1000)+$island->{'m73'}*100) < 200)) {
	                 # ���Ϥ��峤�����ޥ��ʾ夢��У���% �γ�Ψ�ǰ��߹���
	                 logRottenSeaGrow($id, $name, $lName, $point);
	                 $land->[$sx][$sy] = $HlandRottenSea;
	                 $landValue->[$sx][$sy] = 1;
	            }
	        }
	    }

        } elsif(($landKind == $HlandRottenSea) && ($lv >= 20)) {
	$landValue->[$x][$y]++;
		if($landValue->[$x][$y] > 4000) {
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		} elsif(($landValue->[$x][$y] > 1000) && (random(250) == 0)) {
		    $land->[$x][$y] = $HlandMonument;
		    $landValue->[$x][$y] = 80+random(3);
		} elsif(($landValue->[$x][$y] > 750) && (random(250) == 0)) {
		    $land->[$x][$y] = $HlandMonument;
		    $landValue->[$x][$y] = 73;
		} elsif(($landValue->[$x][$y] > 500) && (random(250) == 0)) {
		    $land->[$x][$y] = $HlandMonument;
		    $landValue->[$x][$y] = 74+random(5);
		} elsif(($landValue->[$x][$y] > 250) && (random(250) == 0)) {
		    $land->[$x][$y] = $HlandMonument;
		    $landValue->[$x][$y] = 87;
		} elsif(($landValue->[$x][$y] > 125) && (random(250) == 0) && ($island->{'m84'} < 4)) {
		    $land->[$x][$y] = $HlandMonument;
		    $landValue->[$x][$y] = 84;
		}

	} elsif($landKind == $HlandCollege) {
	    # �����Ǥμ��Ф�
	    my($clv) = $landValue->[$x][$y];

	    if($clv == 4) {

	    my($i,$sx,$sy);
	    for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster) {
		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		if($tKind == 28) {
		} else {
		    my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);
		    for($i = 0; $i < 7; $i++) {
			$ssx = $sx + $ax[$i];
			$ssy = $sy + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
			    $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# �ϰϳ�Ƚ��
			if(($ssx < 0) || ($ssx >= $HislandSize) ||
			   ($ssy < 0) || ($ssy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
				next;
			} else {
			    # 2�إå���
			    if($take < 1) {
			    if(($landKind == $HlandWaste) &&
				($island->{'c28'} == 0)) {
				$eisei5 = $island->{'eisei5'};
				$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

				$kind = 28;
				$lv = $lv = ($kind << 4)
				+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind])+$mshp;
				$land->[$ssx][$ssy] = $HlandMonster;
				$landValue->[$ssx][$ssy] = $lv;
				logMstakeon($id, $name, "��ʪ��ؤΥޥ����åȤ��Τ�","($x, $y)");

				$landValue->[$x][$y] = 99;
				$take++;
				$island->{'co99'}++;
				$island->{'monsterlive'}++;
				}
			    }
			}
		    }
		    }
		}
		}
	    }

	    if($clv == 98) {

	    my($i,$sx,$sy);
	    for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster) {
		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		if($tKind == 30) {
		} else {
		    my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);
		    for($i = 0; $i < 7; $i++) {
			$ssx = $sx + $ax[$i];
			$ssy = $sy + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
			    $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# �ϰϳ�Ƚ��
			if(($ssx < 0) || ($ssx >= $HislandSize) ||
			   ($ssy < 0) || ($ssy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
				next;
			} else {
			    # 2�إå���
			    if($take < 1) {
			    if(($landKind == $HlandWaste) &&
				($island->{'c28'} == 0)) {
				$eisei5 = $island->{'eisei5'};
				$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

				$kind = 30;
				$lv = $lv = ($kind << 4)
				+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind])+$mshp;
				$land->[$ssx][$ssy] = $HlandMonster;
				$landValue->[$ssx][$ssy] = $lv;
				logMstakeon($id, $name, "Ķ���åƥȥ�","($x, $y)");

				$landValue->[$x][$y] = 99;
				$take++;
				$island->{'co99'}++;
				$island->{'monsterlive'}++;
				}
			    }
			}
		    }
		    }
		}
		}
	    }

	    if($clv == 99) {
		if($island->{'c28'} == 0) {
                $land->[$x][$y] = $HlandPlains;
                $landValue->[$x][$y] = 0;
		logMstakeoff($id, $name, landName($landKind, $lv),"($x, $y)");
		}
	    }

	    if($clv == 80) {
		my($shutoCount) = (0);
		my($houseCount) = (0);
		my($foodimCount) = (0);
		my($htfCount) = (0);
		my($shtfCount) = (0);
		my($i, $sx, $sy, $kind, $lv);
		for($i = 1; $i < 7; $i++) {
		    $sx = $x + $ax[$i];
		    $sy = $y + $ay[$i];

		    # �Ԥˤ�����Ĵ��
		    if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		    }

		    $landKind = $land->[$sx][$sy];
		    $lv = $landValue->[$sx][$sy];
		    $point = "($sx, $sy)";

		    if(($sx < 0) || ($sx >= $HislandSize) ||
		       ($sy < 0) || ($sy >= $HislandSize)) {
		    } else {
			# �ϰ���ξ��
			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";
			if(($landKind == $HlandShuto) || ($landKind == $HlandUmishuto)) {
			    $shutoCount++;
			} elsif($landKind == $HlandHouse) {
			    $houseCount++;
			} elsif(($landKind == $HlandFoodim) && ($lv == 500)) {
			    $foodimCount++;
			} elsif(($landKind == $HlandHTFactory) && ($lv == 500)) {
			    $htfCount++;
			} elsif(($landKind == $HlandSHTF) && ($lv == 500)) {
			    $shtfCount++;
			}
		    }
		}

		if(($island->{'ownf'} == 0) && ($shutoCount == 1) && ($houseCount == 1) && ($foodimCount == 1) && ($htfCount == 1) && ($shtfCount == 1)) {
		    my($onm);
		    $onm = $island->{'onm'};
		    logOwnFac($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]),"($x, $y)", "$onm");
		    $land->[$x][$y] = $HlandOWNF;
		    $landValue->[$x][$y] = 111;
			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
			    $sx = $x + $ax[$i];
			    $sy = $y + $ay[$i];
			    if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			    }
			    $landKind = $land->[$sx][$sy];
			    $lv = $landValue->[$sx][$sy];
			    $point = "($sx, $sy)";
			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {
			    } else {
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandFoodim) && ($lv == 500)) {
				    $land->[$sx][$sy] = $HlandPlains2;
				    $landValue->[$sx][$sy] = 0;
				} elsif(($landKind == $HlandHTFactory) && ($lv == 500)) {
				    $land->[$sx][$sy] = $HlandPlains2;
				    $landValue->[$sx][$sy] = 0;
				} elsif(($landKind == $HlandSHTF) && ($lv == 500)) {
				    $land->[$sx][$sy] = $HlandPlains2;
				    $landValue->[$sx][$sy] = 0;
				}
			    }
			}
		}

	    }

	    if(($clv == 77) || ($clv == 78) || ($clv == 79) || ($clv == 80)) {
		if(($island->{'co0'} < 1) ||
		   ($island->{'co01'} < 1) ||
		   ($island->{'co2'} < 1) ||
		   ($island->{'co3'} < 1) ||
		   ($island->{'co4'} < 1) ||
		   ($island->{'co5'} < 1) ||
		   ($island->{'co6'} < 1) ||
		   ($island->{'co7'} < 1) ||
		   ($island->{'co8'} < 1) ||
		   ($island->{'eis7'} < 1000000) ||
		   ($island->{'rena'} < 10000) ||
		   ($island->{'pts'} < $HouseLevel7)) {
		$land->[$x][$y] = $HlandYakusho;
		$landValue->[$x][$y] = 0;
		}
	    }

	} elsif($landKind == $HlandOWNF) {
	    $ownfe = int($lv/1000);
	    $shts = int($lv/100)%10;
	    $hts = int($lv%100/10);
	    $noujous = $lv%10;
	    $totals = $shts + $hts + $noujous;
	    $etc5 = $island->{'etc5'};
	    $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	    $costseisaku = $s01+$s03+$s05+$s07+$s09+$s11+$s13+$s15+$s17+$s19+$s21+$s23+$s25+$s27+$s29+$s02+$s04+$s06+$s08+$s10+$s12+$s14+$s16+$s18+$s20+$s22+$s24+$s26+$s28+$s30;

	    my($onm);
	    $onm = $island->{'onm'};
	    my($unemployed);
	    $unemployed = ($island->{'pop'} - ($island->{'farm'} + $island->{'factoryt'} + $island->{'mountain'}) * 10) / $island->{'pop'} * 100;
		if($unemployed < 0) {
		    $unemployed = -1*$unemployed;
		}
		if($island->{'ownf'} > 1) {
		    $land->[$x][$y] = $HlandPlains2;
		    $landValue->[$x][$y] = 0;
		    $island->{'ownf'} -= 1;
		}

	            if($island->{'urikireflag'} == 1) {
			$landValue->[$x][$y] = "$shts$hts$noujous";
		    }

	            if((random(1000) < int($island->{'rena'}/1000)) && ($ownfe == 0)) {
			$landValue->[$x][$y] = "1$shts$hts$noujous";
			logMiyage2($id, $name, "$onm", "($x, $y)", "�峤���Ǿä���");
		    }

		my($shutoCount) = (0);
		my($houseCount) = (0);
		my($i, $sx, $sy, $kind, $lv);
		for($i = 1; $i < 7; $i++) {
		    $sx = $x + $ax[$i];
		    $sy = $y + $ay[$i];

		    # �Ԥˤ�����Ĵ��
		    if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		    }

		    $landKind = $land->[$sx][$sy];
		    $lv = $landValue->[$sx][$sy];
		    $point = "($sx, $sy)";

		    if(($sx < 0) || ($sx >= $HislandSize) ||
		       ($sy < 0) || ($sy >= $HislandSize)) {
		    } else {
			# �ϰ���ξ��
			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";
			if(($landKind == $HlandShuto) || ($landKind == $HlandUmishuto)) {
			    $shutoCount++;
			} elsif($landKind == $HlandHouse) {
			    $houseCount++;
			}
		    }
		}
			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
			    $sx = $x + $ax[$i];
			    $sy = $y + $ay[$i];
			    if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			    }
			    $landKind = $land->[$sx][$sy];
			    $lv = $landValue->[$sx][$sy];
			    $point = "($sx, $sy)";
			    if(($sx < 0) || ($sx >= $HislandSize) ||
			       ($sy < 0) || ($sy >= $HislandSize)) {
			    } else {
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandFoodim) && ($lv == 500) && ($noujous < 8) && ((8-$noujous)*20 > $unemployed) && ($shutoCount == 1) && ($houseCount == 1) && ($noujous*15 < $costseisaku) && ((24-$totals)*5 > $unemployed) && ($totals*5 < $costseisaku) && ($totals*800 < $island->{'rena'}) && ($noujous*1875 < $island->{'rena'})) {
					logOwnFac2($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), landName($land->[$sx][$sy], $landValue->[$sx][$sy]),"($x, $y)", "$onm");
				    $land->[$sx][$sy] = $HlandPlains2;
				    $landValue->[$sx][$sy] = 0;
				    $landValue->[$x][$y] += 1;
				    $noujous++;
				    $totals++;
				} elsif(($landKind == $HlandHTFactory) && ($lv == 500) && ($hts < 8) && ((8-$hts)*20 > $unemployed) && ($shutoCount == 1) && ($houseCount == 1) && ($hts*15 < $costseisaku) && ((24-$totals)*5 > $unemployed) && ($totals*5 < $costseisaku) && ($totals*800 < $island->{'rena'}) && ($hts*1875 < $island->{'rena'})) {
					logOwnFac2($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), landName($land->[$sx][$sy], $landValue->[$sx][$sy]),"($x, $y)", "$onm");
				    $land->[$sx][$sy] = $HlandPlains2;
				    $landValue->[$sx][$sy] = 0;
				    $landValue->[$x][$y] += 10;
				    $hts++;
				    $totals++;
				} elsif(($landKind == $HlandSHTF) && ($lv == 500) && ($shts < 8) && ((8-$shts)*20 > $unemployed) && ($shutoCount == 1) && ($houseCount == 1) && ($shts*15 < $costseisaku) && ((24-$totals)*5 > $unemployed) && ($totals*5 < $costseisaku) && ($totals*800 < $island->{'rena'}) && ($shts*1875 < $island->{'rena'})) {
					logOwnFac2($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), landName($land->[$sx][$sy], $landValue->[$sx][$sy]),"($x, $y)", "$onm");
				    $land->[$sx][$sy] = $HlandPlains2;
				    $landValue->[$sx][$sy] = 0;
				    $landValue->[$x][$y] += 100;
				    $shts++;
				    $totals++;
				}
			    }
			}

	} elsif($landKind == $HlandMonument) {

	     # �����Ǥμ��Ф�
	     my($molv) = $landValue->[$x][$y];

	     if(($molv == 0) ||
		($molv == 15) ||
		($molv == 16) ||
	        ($molv == 10)) {
	            if(random(100) < 5) {
		    # ����
		    my($value, $str, $lName);
		    $lName = landName($landKind, $lv);
		    $value = 1+ random(49);
		    $island->{'money'} += $value;
		    $str = "$value$HunitMoney";
	            logMiyage($id, $name, $lName, "($x, $y)", $str) if ($value > 0);
		    }
	    } elsif($molv == 1) {
	            if(random(100) < 1) {
		    # ����
		    my($value, $str, $lName);
		    $lName = landName($landKind, $lv);
	            $value = int($island->{'pop'} / 100) * 10+ random(11); # �͸�����ͤ��Ȥ�1000�ȥ�ο�������
	            $island->{'food'} += $value;
	            $str = "$value$HunitFood";

	                logParkEventt($id, $name, $lName, "($x, $y)", $str) if ($value > 0);
		    }

	    } elsif($molv == 80) {
	            if(random(100) < 5) {
		    # ������
		    for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			    $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# �ϰϳ�Ƚ��
			if(($sx < 0) || ($sx >= $HislandSize) ||
			   ($sy < 0) || ($sy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
			    # �濴�������1�إå���
		            if(random(100) < 5) {
				$kind = 13;  # �ߥ�����
			    } elsif(random(100) < 25) {
				$kind = 29;  # �ƥȥ�
			    } elsif(random(100) < 35) {
				$kind = 14;  # ����쥸��
			    } elsif(random(100) < 25) {
				$kind = 12;  # �ϤͤϤ�
			    } else {
				$kind = 1;  # ���Τ�(�Ϥ���)
			    }

				$lv = $lv = ($kind << 4)
				    + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				$land->[$sx][$sy] = $HlandMonster;
				$landValue->[$sx][$sy] = $lv;
				    my($mKind, $mName, $mHp) = monsterSpec($lv);
				    logEggBomb($id, $name, $landName, $mName, $point);

			} else {
			    # 2�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandOil) ||
			       ($landKind == $HlandMountain) ||
			       ($landKind == $HlandGold) ||
			       ($landKind == $HlandOnsen) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandFune) ||
			       ($landKind == $HlandFrocity) ||
			       ($landKind == $HlandSbase)) {
				next;
			    } else {
				$landName = landName($landKind, $lv);
				logEggDamage($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			    }
			}
		    }
		}

	    } elsif($molv == 81) {
	            if(random(100) < 3) {
		    # ������
		    for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			    $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# �ϰϳ�Ƚ��
			if(($sx < 0) || ($sx >= $HislandSize) ||
			   ($sy < 0) || ($sy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
			    # �濴�������1�إå���
		            if(random(100) < 3) {
				$kind = 13;  # �ߥ�����
			    } elsif(random(100) < 20) {
				$kind = 29;  # �ƥȥ�
			    } elsif(random(100) < 40) {
				$kind = 14;  # ����쥸��
			    } elsif(random(100) < 15) {
				$kind = 12;  # �ϤͤϤ�
			    } else {
				$kind = 1;  # ���Τ�(�Ϥ���)
			    }

				$lv = $lv = ($kind << 4)
				    + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				$land->[$sx][$sy] = $HlandMonster;
				$landValue->[$sx][$sy] = $lv;
				    my($mKind, $mName, $mHp) = monsterSpec($lv);
				    logEggBomb($id, $name, $landName, $mName, $point);

			} else {
			    # 2�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandOil) ||
			       ($landKind == $HlandMountain) ||
			       ($landKind == $HlandGold) ||
			       ($landKind == $HlandOnsen) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandFune) ||
			       ($landKind == $HlandFrocity) ||
			       ($landKind == $HlandSbase)) {
				next;
			    } else {
				$landName = landName($landKind, $lv);
				logEggDamage($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			    }
			}
		    }
		}

	    } elsif($molv == 82) {
	            if(random(100) < 3) {
		    # ������
		    for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			    $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# �ϰϳ�Ƚ��
			if(($sx < 0) || ($sx >= $HislandSize) ||
			   ($sy < 0) || ($sy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
			    # �濴�������1�إå���
		            if(random(100) < 3) {
				$kind = 13;  # �ߥ�����
			    } elsif(random(100) < 30) {
				$kind = 29;  # �ƥȥ�
			    } elsif(random(100) < 40) {
				$kind = 14;  # ����쥸��
			    } elsif(random(100) < 30) {
				$kind = 12;  # �ϤͤϤ�
			    } else {
				$kind = 1;  # ���Τ�(�Ϥ���)
			    }

				$lv = $lv = ($kind << 4)
				    + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				$land->[$sx][$sy] = $HlandMonster;
				$landValue->[$sx][$sy] = $lv;
				    my($mKind, $mName, $mHp) = monsterSpec($lv);
				    logEggBomb($id, $name, $landName, $mName, $point);

			} else {
			    # 2�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandOil) ||
			       ($landKind == $HlandMountain) ||
			       ($landKind == $HlandGold) ||
			       ($landKind == $HlandOnsen) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandFune) ||
			       ($landKind == $HlandFrocity) ||
			       ($landKind == $HlandSbase)) {
				next;
			    } else {
				$landName = landName($landKind, $lv);
				logEggDamage($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			    }
			}
		    }
		}

	    } elsif($molv == 83) {
	            if(random(100) < 5) {
		    # ������
		    for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			    $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# �ϰϳ�Ƚ��
			if(($sx < 0) || ($sx >= $HislandSize) ||
			   ($sy < 0) || ($sy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
			    # �濴�������1�إå���
		            if(random(100) < 10) {
				$kind = 13;  # �ߥ�����
			    } elsif(random(100) < 25) {
				$kind = 29;  # �ƥȥ�
			    } elsif(random(100) < 30) {
				$kind = 14;  # ����쥸��
			    } elsif(random(100) < 30) {
				$kind = 12;  # �ϤͤϤ�
			    } else {
				$kind = 1;  # ���Τ�(�Ϥ���)
			    }

				$lv = $lv = ($kind << 4)
				    + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				$land->[$sx][$sy] = $HlandMonster;
				$landValue->[$sx][$sy] = $lv;
				    my($mKind, $mName, $mHp) = monsterSpec($lv);
				    logEggBomb($id, $name, $landName, $mName, $point);

			} else {
			    # 2�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandOil) ||
			       ($landKind == $HlandMountain) ||
			       ($landKind == $HlandGold) ||
			       ($landKind == $HlandOnsen) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandFune) ||
			       ($landKind == $HlandFrocity) ||
			       ($landKind == $HlandSbase)) {
				next;
			    } else {
				$landName = landName($landKind, $lv);
				logEggDamage($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			    }
			}
		    }
		}

	    } elsif($molv == 84) {
	            if(random(100) < 75) {
		    # ����
		    my($lName);
		    $lName = landName($landKind, $lv);
	            my($nt) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
	            my($value);
	            $value = random($nt * 20 + $lv * 5 + int($island->{'pop'} / 20)) + random(100) + 100;
	            if ($value > 0) {
	                $island->{'money'} += $value;

			$m84income += $value;
	            }
		    }
	    } elsif($molv == 93) {
		    # ����
		    my($value, $str, $lName);
		    $lName = landName($landKind, $lv);
		    $value = $HoilMoney+ random(500);
		    $island->{'money'} += $value;
		    $str = "$value$HunitMoney";

	            $value = int($island->{'pop'} / 20) + random(11); # �͸�����ͤ��Ȥ�1000�ȥ�ο�������
	            $island->{'food'} += $value;
	            $str = "$value$HunitFood";

	    } elsif($molv == 94) {

		    my($i,$sx,$sy);
		    for($i = 1; $i < 7; $i++) {
		        $sx = $x + $ax[$i];
		        $sy = $y + $ay[$i];
			    if($land->[$sx][$sy] == $HlandMonster){
				# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��

				# �оݤȤʤ���äγ����Ǽ��Ф�
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
				my($tlv) = $landValue->[$sx][$sy];
				my($tspecial) = $HmonsterSpecial[$tKind];

				    logBariaAttack($id, $name, $tName, "($sx, $sy)");
			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 1;
			    next;
			    }
		    }
	    }

	} elsif($landKind == $HlandFrocity) {

	    if($addpop < 0) {
		# ��­
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		    next;
		}
	    } else {
		# ��Ĺ
		if($lv < 100) {
		    $lv += random($addpop) + 1;
		    if($lv > 100) {
			$lv = 100;
		    }
		} else {
		    # �ԻԤˤʤ����Ĺ�٤�
		    if($addpop2 > 0) {
			$lv += random($addpop2) + 1;
		    }
		}
	    }
	    if($lv > 200) {
		$lv = 200;
	    }
	    $landValue->[$x][$y] = $lv;

	    # ư�����������
	    my($d, $sx, $sy);
	    my($i);
	    for($i = 0; $i < 3; $i++) {
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}

		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}

		# �������𡢳����Իԡ����ġ����á�������ǰ��ʳ�
		if(($land->[$sx][$sy] != $HlandWaste) &&
		   ($land->[$sx][$sy] != $HlandPlains) &&
		   ($land->[$sx][$sy] != $HlandPlains2) &&
		   ($land->[$sx][$sy] != $HlandTown) &&
		   ($land->[$sx][$sy] != $HlandForest) &&
		   ($land->[$sx][$sy] != $HlandFarm) &&
		   ($land->[$sx][$sy] != $HlandEneAt) &&
		   ($land->[$sx][$sy] != $HlandEneFw) &&
		   ($land->[$sx][$sy] != $HlandEneWt) &&
		   ($land->[$sx][$sy] != $HlandEneWd) &&
		   ($land->[$sx][$sy] != $HlandEneBo) &&
		   ($land->[$sx][$sy] != $HlandEneSo) &&
		   ($land->[$sx][$sy] != $HlandEneCs) &&
		   ($land->[$sx][$sy] != $HlandConden) &&
		   ($land->[$sx][$sy] != $HlandConden2) &&
		   ($land->[$sx][$sy] != $HlandConden3) &&
		   ($land->[$sx][$sy] != $HlandConden4) &&
		   ($land->[$sx][$sy] != $HlandFoodim) &&
		   ($land->[$sx][$sy] != $HlandFoodka) &&
		   ($land->[$sx][$sy] != $HlandFarmchi) &&
		   ($land->[$sx][$sy] != $HlandFarmpic) &&
		   ($land->[$sx][$sy] != $HlandFarmcow) &&
		   ($land->[$sx][$sy] != $HlandCollege) &&
		   ($land->[$sx][$sy] != $HlandYakusho) &&
		   ($land->[$sx][$sy] != $HlandFactory) &&
		   ($land->[$sx][$sy] != $HlandHTFactory) &&
		   ($land->[$sx][$sy] != $HlandSHTF) &&
		   ($land->[$sx][$sy] != $HlandOWNF) &&
		   ($land->[$sx][$sy] != $HlandBase) &&
		   ($land->[$sx][$sy] != $HlandDefence) &&
		   ($land->[$sx][$sy] != $HlandMinato) &&
		   ($land->[$sx][$sy] != $HlandSeki) &&
		   ($land->[$sx][$sy] != $HlandPark) &&
		   ($land->[$sx][$sy] != $HlandHaribote) &&
		   ($land->[$sx][$sy] != $HlandSbase) &&
		   ($land->[$sx][$sy] != $HlandSeacity) &&
		   ($land->[$sx][$sy] != $HlandFune) &&
		   ($land->[$sx][$sy] != $HlandIce) &&
		   ($land->[$sx][$sy] != $HlandFrocity) &&
		   ($land->[$sx][$sy] != $HlandUmiamu) &&
		   ($land->[$sx][$sy] != $HlandOil) &&
		   ($land->[$sx][$sy] != $HlandGold) &&
		   ($land->[$sx][$sy] != $HlandMountain) &&
		   ($land->[$sx][$sy] != $HlandOnsen) &&
		   ($land->[$sx][$sy] != $HlandMonument) &&
		   ($land->[$sx][$sy] != $HlandMine) &&
		   ($land->[$sx][$sy] != $HlandNursery) &&
		   ($land->[$sx][$sy] != $HlandKyujo) &&
		   ($land->[$sx][$sy] != $HlandKyujokai) &&
		   ($land->[$sx][$sy] != $HlandZoo) &&
		   ($land->[$sx][$sy] != $HlandRottenSea) &&
		   ($land->[$sx][$sy] != $HlandProcity) &&
		   ($land->[$sx][$sy] != $HlandNewtown) &&
		   ($land->[$sx][$sy] != $HlandBigtown) &&
		   ($land->[$sx][$sy] != $HlandBettown) &&
		   ($land->[$sx][$sy] != $HlandSkycity) &&
		   ($land->[$sx][$sy] != $HlandUmicity) &&
		   ($land->[$sx][$sy] != $HlandSeatown) &&
		   ($land->[$sx][$sy] != $HlandRizort) &&
		   ($land->[$sx][$sy] != $HlandKajino) &&
		   ($land->[$sx][$sy] != $HlandBigRizort) &&
		   ($land->[$sx][$sy] != $HlandShuto) &&
		   ($land->[$sx][$sy] != $HlandUmishuto) &&
		   ($land->[$sx][$sy] != $HlandHouse) &&
		   ($land->[$sx][$sy] != $HlandTaishi) &&
		   ($land->[$sx][$sy] != $HlandTrain) &&
		   ($land->[$sx][$sy] != $HlandKura) &&
		   ($land->[$sx][$sy] != $HlandKuraf) &&
		   ($land->[$sx][$sy] != $HlandMonster)) {
		    last;
		}
	    }

	    if($i == 3) {
		# ư���ʤ��ä�
		next;
	    }

	    # ư��������Ϸ��ˤ���å�����
	    my($l) = $land->[$sx][$sy];
	    my($lv) = $landValue->[$sx][$sy];
	    my($lName) = landName($l, $lv);
	    my($point) = "($sx, $sy)";

	    # ��ư
	    $land->[$sx][$sy] = $land->[$x][$y];
	    $landValue->[$sx][$sy] = $landValue->[$x][$y];

	    # ��ȵ錄���֤���Ϥ�
	    $land->[$x][$y] = $HlandSea;
	    $landValue->[$x][$y] = 0;

	} elsif($landKind == $HlandFune) {
	    # ����
	    if($funeMove[$x][$y] == 2) {
		# ���Ǥ�ư������
		next;
	    }

	    # �����Ǥμ��Ф�
	    my($flv) = $landValue->[$x][$y];
	    my($funespe) = $HfuneSpecial[$lv];

            # Ϸ�ಽȽ��
	    my($lName) = &landName($landKind, $lv);
	    if(($flv == 8) ||
	       ($flv == 9) ||
	       ($flv == 19) ||
	       ($flv == 10)) {
		if(random(1000) < 5) {
                # ���ߤ�Ϸ�ಽ���������ı�
                logParkEndf($id, $name, $lName, "($x, $y)");
                $land->[$x][$y] = $HlandSea;
                $landValue->[$x][$y] = 0;
                }
            } else {
		if(random(100) < 3) {
                # ���ߤ�Ϸ�ಽ���������ı�
                logParkEndf($id, $name, $lName, "($x, $y)");
                $land->[$x][$y] = $HlandSea;
                $landValue->[$x][$y] = 0;
                }
            }

	    my($flv) = $landValue->[$x][$y];
	    my($funespe) = $HfuneSpecial[$lv];

	    if($flv == 0) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 1+ random(399);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
            logHoken($id, $name, $lName, "($x, $y)", $str) if ($value > 0);

	    }
	    elsif($flv == 1) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 5;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

            $value = 290+ random(30); # 
            $island->{'food'} += $value;
            $str = "$value$HunitFood";
            $gyosenincome += $value;

	    }
	    elsif($flv == 2) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 20;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

            $value = 490+ random(40); # 
            $island->{'food'} += $value;
            $str = "$value$HunitFood";
            $gyosenincome += $value;

	    }
	    elsif($flv == 3) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 300;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

		    if(random(1000) < 5) {
		    my($value, $str, $lName);
		    $lName = landName($landKind, $lv);
		    $value = 1+ random(49999);
		    $island->{'money'} += $value;
		    $str = "$value$HunitMoney";
	            # ��������
	            logTansaku($id, $name, $lName, "($x, $y)", $str) if ($value > 0);
		    }
	    }
	    elsif($flv == 4) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 150+ random(250);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
            # ��������
            logParkMoneyf($id, $name, $lName, "($x, $y)", $str) if ($value > 0);

            $value = 1000; # 
            $island->{'food'} -= $value;
            $str = "$value$HunitFood";
	    }
	    elsif($flv == 5) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 60;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

            $value = 690+ random(40); # 
            $island->{'food'} += $value;
            $str = "$value$HunitFood";
            $gyosenincome += $value;

	    }
	    elsif($flv == 6) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 30;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

            $value = 490+ random(40); # 
            $island->{'food'} += $value;
            $str = "$value$HunitFood";
            $gyosenincome += $value;

	    }
	    elsif($flv == 7) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 500;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

		    if(random(100) < 1) {
		    my($value, $str, $lName);
		    $lName = landName($landKind, $lv);
		    $value = 1+ random(29999);
		    $island->{'money'} += $value;
		    $str = "$value$HunitMoney";
	            # ��������
	            logTansaku($id, $name, $lName, "($x, $y)", $str) if ($value > 0);
		    }
	    }
	    elsif($flv == 8) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 1500+  int($island->{'pop'} / 10) * 1;
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
            # ��������
            logParkMoneyf($id, $name, $lName, "($x, $y)", $str) if ($value > 0);
            $value = 3000; # 
            $island->{'food'} -= $value;
            $str = "$value$HunitFood";
            if(random(100) < 10) {
                # ���ߤ�Ϸ�ಽ���������ı�
                logTitanic($id, $name, $lName, "($x, $y)");
	    $lName = landName($landKind, $lv);
	    $value = int($island->{'pop'} / 10) * 2;
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
            # ��������
            logTitanicEnd($id, $name, $lName, "($x, $y)", $str) if ($value > 0);

                $land->[$x][$y] = $HlandIce;
                $landValue->[$x][$y] = 0;
            }
	    }

	    elsif($flv == 9) {
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 100;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

	    my($i,$sx,$sy);
	    for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster) {
		if($kougekiseigen < 2) {
		# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��

		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

		if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
                   (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
		   (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
		# �оݤ��Ų���ʤ���̤ʤ�
	    next;
	    }

	    logMonsAttackt($id, $name, $lName, "($x, $y)", $tName, $tPoint);
	    $kougekiseigen++;

	    $tHp--;
	    if($tHp != 0){
	    # �оݤ����Ϥ򸺤餹
	    $tlv--;
		$landValue->[$sx][$sy] = $tlv;
	    }else{
	    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	    # �󾩶�
		my($value) = $HmonsterValue[$tKind];
		   $island->{'money'} += $value;
		   logMsMonMoney($id, $tName, $value);
		}
	    next;
	    }
	    }
	}
	}
	    elsif($flv == 10) {
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 400;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

	    my($i,$sx,$sy);
	    for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster){
		# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 3000;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		    logFuneAttack($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");

		    my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);

		    for($i = 0; $i < 7; $i++) {
			$ssx = $sx + $ax[$i];
			$ssy = $sy + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
			    $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# �ϰϳ�Ƚ��
			if(($ssx < 0) || ($ssx >= $HislandSize) ||
			   ($ssy < 0) || ($ssy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
			    # �濴�������1�إå���
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = 1;
				    logFuneMonsterSea($id, $name, $landName, $point);

			} else {
			    # 2�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandOil) ||
			       ($landKind == $HlandIce) ||
			       ($landKind == $HlandWaste) ||
			       ($landKind == $HlandMountain) ||
			       ($landKind == $HlandGold) ||
			       ($landKind == $HlandOnsen) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandFune) ||
			       ($landKind == $HlandFrocity) ||
			       ($landKind == $HlandSbase)) {
				next;
			    } elsif($landKind == $HlandMonster) {
				logWideDamageMonster($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			    } else {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			    }
			}
		    }

	    next;
	    }
	}
	}
	    elsif($flv == 11) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 60;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

            $value = 690+ random(40); # 
            $island->{'food'} += $value;
            $str = "$value$HunitFood";
            $gyosenincome += $value;

	    }

	    elsif($flv == 19) {
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 1000;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

	    my($i,$sx,$sy);
	    for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster){
		# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = 50000;
	    $island->{'money'} -= $value;
	    $str = "$value$HunitMoney";

		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		    logFuneAttackSSS($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			$heat++;

		$rena = $island->{'rena'};
		if (rand($rena) > (3000+$heat*1000)) {
		    logFuneAttackSSSR($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
		} else {

		    logFuneAttackSSST($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
		    my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);

		    for($i = 0; $i < 4; $i++) {
			$ssx = $x + $ax[$i];
			$ssy = $y + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($ssy % 2) == 0) && (($y % 2) == 1)) {
			    $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# �ϰϳ�Ƚ��
			if(($ssx < 0) || ($ssx >= $HislandSize) ||
			   ($ssy < 0) || ($ssy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
			    # �濴�������1�إå���
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = 0;
			} else {
			    # 2�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandOil) ||
			       ($landKind == $HlandIce) ||
			       ($landKind == $HlandWaste) ||
			       ($landKind == $HlandMountain) ||
			       ($landKind == $HlandGold) ||
			       ($landKind == $HlandOnsen) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandFune) ||
			       ($landKind == $HlandFrocity) ||
			       ($landKind == $HlandSbase)) {
				next;
			    } elsif($landKind == $HlandMonster) {
				logWideDamageMonster($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			    } else {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			    }
			}
		    }
		}

	    next;
	    }
	}
	}

	    # ư�����������
	    my($d, $sx, $sy);
	    my($i);
	    for($i = 0; $i < 3; $i++) {
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}

		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}

		# �������𡢳����Իԡ����ġ����á�������ǰ��ʳ�
		if(($land->[$sx][$sy] != $HlandWaste) &&
		   ($land->[$sx][$sy] != $HlandPlains) &&
		   ($land->[$sx][$sy] != $HlandPlains2) &&
		   ($land->[$sx][$sy] != $HlandTown) &&
		   ($land->[$sx][$sy] != $HlandForest) &&
		   ($land->[$sx][$sy] != $HlandFarm) &&
		   ($land->[$sx][$sy] != $HlandEneAt) &&
		   ($land->[$sx][$sy] != $HlandEneFw) &&
		   ($land->[$sx][$sy] != $HlandEneWt) &&
		   ($land->[$sx][$sy] != $HlandEneWd) &&
		   ($land->[$sx][$sy] != $HlandEneBo) &&
		   ($land->[$sx][$sy] != $HlandEneSo) &&
		   ($land->[$sx][$sy] != $HlandEneCs) &&
		   ($land->[$sx][$sy] != $HlandConden) &&
		   ($land->[$sx][$sy] != $HlandConden2) &&
		   ($land->[$sx][$sy] != $HlandConden3) &&
		   ($land->[$sx][$sy] != $HlandConden4) &&
		   ($land->[$sx][$sy] != $HlandFoodim) &&
		   ($land->[$sx][$sy] != $HlandFoodka) &&
		   ($land->[$sx][$sy] != $HlandFarmchi) &&
		   ($land->[$sx][$sy] != $HlandFarmpic) &&
		   ($land->[$sx][$sy] != $HlandFarmcow) &&
		   ($land->[$sx][$sy] != $HlandCollege) &&
		   ($land->[$sx][$sy] != $HlandYakusho) &&
		   ($land->[$sx][$sy] != $HlandFactory) &&
		   ($land->[$sx][$sy] != $HlandHTFactory) &&
		   ($land->[$sx][$sy] != $HlandSHTF) &&
		   ($land->[$sx][$sy] != $HlandOWNF) &&
		   ($land->[$sx][$sy] != $HlandBase) &&
		   ($land->[$sx][$sy] != $HlandDefence) &&
		   ($land->[$sx][$sy] != $HlandMinato) &&
		   ($land->[$sx][$sy] != $HlandSeki) &&
		   ($land->[$sx][$sy] != $HlandPark) &&
		   ($land->[$sx][$sy] != $HlandHaribote) &&
		   ($land->[$sx][$sy] != $HlandSbase) &&
		   ($land->[$sx][$sy] != $HlandSeacity) &&
		   ($land->[$sx][$sy] != $HlandFune) &&
		   ($land->[$sx][$sy] != $HlandIce) &&
		   ($land->[$sx][$sy] != $HlandFrocity) &&
		   ($land->[$sx][$sy] != $HlandUmiamu) &&
		   ($land->[$sx][$sy] != $HlandOil) &&
		   ($land->[$sx][$sy] != $HlandGold) &&
		   ($land->[$sx][$sy] != $HlandMountain) &&
		   ($land->[$sx][$sy] != $HlandOnsen) &&
		   ($land->[$sx][$sy] != $HlandMonument) &&
		   ($land->[$sx][$sy] != $HlandMine) &&
		   ($land->[$sx][$sy] != $HlandNursery) &&
		   ($land->[$sx][$sy] != $HlandKyujo) &&
		   ($land->[$sx][$sy] != $HlandKyujokai) &&
		   ($land->[$sx][$sy] != $HlandZoo) &&
		   ($land->[$sx][$sy] != $HlandRottenSea) &&
		   ($land->[$sx][$sy] != $HlandProcity) &&
		   ($land->[$sx][$sy] != $HlandNewtown) &&
		   ($land->[$sx][$sy] != $HlandBigtown) &&
		   ($land->[$sx][$sy] != $HlandBettown) &&
		   ($land->[$sx][$sy] != $HlandSkycity) &&
		   ($land->[$sx][$sy] != $HlandUmicity) &&
		   ($land->[$sx][$sy] != $HlandSeatown) &&
		   ($land->[$sx][$sy] != $HlandRizort) &&
		   ($land->[$sx][$sy] != $HlandKajino) &&
		   ($land->[$sx][$sy] != $HlandBigRizort) &&
		   ($land->[$sx][$sy] != $HlandShuto) &&
		   ($land->[$sx][$sy] != $HlandUmishuto) &&
		   ($land->[$sx][$sy] != $HlandHouse) &&
		   ($land->[$sx][$sy] != $HlandTaishi) &&
		   ($land->[$sx][$sy] != $HlandTrain) &&
		   ($land->[$sx][$sy] != $HlandKura) &&
		   ($land->[$sx][$sy] != $HlandKuraf) &&
		   ($land->[$sx][$sy] != $HlandMonster)) {
		    last;
		}
	    }

	    if($i == 3) {
		# ư���ʤ��ä�
		next;
	    }

	    # ư��������Ϸ��ˤ���å�����
	    my($l) = $land->[$sx][$sy];
	    my($lv) = $landValue->[$sx][$sy];
	    my($lName) = landName($l, $lv);
	    my($point) = "($sx, $sy)";

	    # ��ư
	    $land->[$sx][$sy] = $land->[$x][$y];
	    $landValue->[$sx][$sy] = $landValue->[$x][$y];

	    # ��ȵ錄���֤���Ϥ�
	    $land->[$x][$y] = $HlandSea;
	    $landValue->[$x][$y] = 0;

		if ($flv == 3) { # ���ĸ��ä�
		if (rand(1000) < 30 - $island->{'oil'} * 3)
		{
	        my($l) = $land->[$sx][$sy];
	        my($lv) = $landValue->[$sx][$sy];
	        my($lName) = landName($l, $lv);
	        my($point) = "($x, $y)";
		logTansakuoil($id, $name, $lName, $point);
		$land->[$x][$y] = $HlandOil;
		$landValue->[$x][$y] = 0;
		$island->{'oil'}++;
		}
		}
		elsif ($flv == 7) { # ���ĸ��ä�
		if (rand(1000) < 40 - $island->{'oil'} * 4)
		{
	        my($l) = $land->[$sx][$sy];
	        my($lv) = $landValue->[$sx][$sy];
	        my($lName) = landName($l, $lv);
	        my($point) = "($x, $y)";
		logTansakuoil($id, $name, $lName, $point);
		$land->[$x][$y] = $HlandOil;
		$landValue->[$x][$y] = 0;
		$island->{'oil'}++;
		}
		}

	    # ��ư�Ѥߥե饰
	    if($funespe == 2) {
		# ��ư�Ѥߥե饰��Ω�Ƥʤ�
	    } elsif($funespe == 1) {
		# ®������
		$funeMove[$sx][$sy] = $funeMove[$x][$y] + 1;
	    } else {
		# ���̤β���
		$funeMove[$sx][$sy] = 2;
	    }

	} elsif($landKind == $HlandMonster) {
	    # ����
	    if($monsterMove[$x][$y] == 2) {
		# ���Ǥ�ư������
		next;
	    }

	    # �����Ǥμ��Ф�
	    my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	    my($special) = $HmonsterSpecial[$mKind];

	    if($mKind == 13) {
	    # ����
	    my($value, $str, $lName);
	    $lName = landName($landKind, $lv);
	    $value = $HoilMoney+ random(500);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";

            $value = int($island->{'pop'} / 20) + random(11); # �͸�����ͤ��Ȥ�1000�ȥ�ο�������
            $island->{'food'} += $value;
            $str = "$value$HunitFood";

	    }

	    # �Ų���?
	    if((($special == 3) && (($HislandTurn % 2) == 1)) ||
               (($special == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
	       (($special == 4) && (($HislandTurn % 2) == 0))) {
		# �Ų���
		next;


	    } elsif (($mKind == 16)&&(($HislandTurn % 2) == 0)&&($mHp < 4)&&(rand(1000) < 700)) {
                    logMonsBomb($id, $name, $lName, "($x, $y)", $mName);
		# �����ﳲ�롼����
		wideDamage($id, $name, $land, $landValue, $x, $y);
		                if (rand(1000) < 250) {
		                    $land->[$x][$y] = $HlandMonument;
		                    $landValue->[$x][$y] = 78;
		                }

            } elsif ($mKind == 17) {
		my($tx, $ty, $landKind, $lv, $point);
		# ȯ��
		$tx = random($HislandSize);
		$ty = random($HislandSize);
		$landKind = $land->[$tx][$ty];
		$lv = $landValue->[$tx][$ty];
		$point = "($tx, $ty)";

		if (rand(1000) < 600) {

		      if(($landKind == $HlandSea) ||
			($landKind == $HlandMountain) ||
			($landKind == $HlandGold) ||
			($landKind == $HlandOnsen) ||
			($landKind == $HlandIce) ||
			($landKind == $HlandSeacity) ||
			($landKind == $HlandSeatown) ||
			($landKind == $HlandUmishuto) ||
			($landKind == $HlandUmiamu) ||
			($landKind == $HlandSbase)) {
			logMekaNdamage($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($tx, $ty)");

			next;
		        }

			$land->[$tx][$ty] = $HlandWaste;
			$landValue->[$tx][$ty] = 1;
			logMekaNmiss($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($tx, $ty)");


		} elsif (rand(1000) < 400) {
			logMekaSmiss($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($tx, $ty)");
		    my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);
		    for($i = 0; $i < 7; $i++) {
			$ssx = $tx + $ax[$i];
			$ssy = $ty + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($ssy % 2) == 0) && (($ty % 2) == 1)) {
			    $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# �ϰϳ�Ƚ��
			if(($ssx < 0) || ($ssx >= $HislandSize) ||
			   ($ssy < 0) || ($ssy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
			    # �濴�������1�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandSbase)) {
				next;
			       }
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = 1;
				    logFuneMonsterSea($id, $name, $landName, $point);

			} else {
			    # 2�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandOil) ||
			       ($landKind == $HlandIce) ||
			       ($landKind == $HlandWaste) ||
			       ($landKind == $HlandMountain) ||
			       ($landKind == $HlandGold) ||
			       ($landKind == $HlandOnsen) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandFune) ||
			       ($landKind == $HlandFrocity) ||
			       ($landKind == $HlandSbase)) {
				next;
			    } elsif($landKind == $HlandMonster) {
				logWideDamageMonster($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			    } else {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			    }
			}
		    }
	        }
		      elsif (rand(1000) < 200) {
			my($sx, $sy, $landKind, $lv, $point);
			# �
			$sx = random($HislandSize);
			$sy = random($HislandSize);
			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";

			# ��å�����
			logMekaAB($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($sx, $sy)");

			# �����ﳲ�롼����
			wideDamage($id, $name, $land, $landValue, $sx, $sy);
		    }

            } elsif ($mKind == 18) {
		    my($i,$sx,$sy);
		    for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
		    if($land->[$sx][$sy] == $HlandMonster) {
			# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��

			# �оݤȤʤ���äγ����Ǽ��Ф�
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
			my($tlv) = $landValue->[$sx][$sy];
			my($tspecial) = $HmonsterSpecial[$tKind];

		        if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
	                   (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
			   (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
			# �оݤ��Ų���ʤ���̤ʤ�
		        next;
		        }
			if (rand(1000) < 600) {
		            if ($tKind == 18) {
			    } elsif(($tKind == 28) ||
				    ($tKind == 30)) {

			    logItiAttackms($id, $name, $mName, "($x, $y)", $tName, $tPoint);
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$sx][$sy] = $tlv;

				if($tHp < 1){
				# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
				# �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				    logMsMonMoney($id, $tName, $value);
				}

			    }else{
			    logItiAttack($id, $name, $mName, "($x, $y)", $tName, $tPoint);

			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				   logMsMonMoney($id, $tName, $value);
			    }
			}
		    }
		}
		if (rand(1000) < 600) {
		my($tx, $ty, $landKind, $lv, $point);
		# ȯ��
		$tx = random($HislandSize);
		$ty = random($HislandSize);
		$landKind = $land->[$tx][$ty];
		$lv = $landValue->[$tx][$ty];
		$point = "($tx, $ty)";

		      if(($landKind == $HlandSea) ||
			($landKind == $HlandMountain) ||
			($landKind == $HlandGold)) {
			next;
		        }

			$land->[$tx][$ty] = $HlandSea;
			$landValue->[$tx][$ty] = 1;
			logUrieruMeteo($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($tx, $ty)");

		                if (rand(1000) < 100) {
		                    $land->[$tx][$ty] = $HlandMonument;
		                    $landValue->[$tx][$ty] = 79;
		                }

		}


            } elsif ($mKind == 22) {
		    my($i,$sx,$sy);
		    for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
		    if($land->[$sx][$sy] == $HlandMonster) {
			# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��

			# �оݤȤʤ���äγ����Ǽ��Ф�
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
			my($tlv) = $landValue->[$sx][$sy];
			my($tspecial) = $HmonsterSpecial[$tKind];

		        if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
	                   (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
			   (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
			# �оݤ��Ų���ʤ���̤ʤ�
		        next;
		        }
			if (rand(1000) < 600) {
		            if ($tKind == 22) {
			    } elsif(($tKind == 28) ||
				    ($tKind == 30)) {

			    logIceAttack($id, $name, $mName, "($x, $y)", $tName, "($sx, $sy)");
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$sx][$sy] = $tlv;

				if($tHp < 1){
				# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
				# �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				    logMsMonMoney($id, $tName, $value);
				}
			    }else{
			    logIceAttack($id, $name, $mName, "($x, $y)", $tName, "($sx, $sy)");

			    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$sx][$sy] = $HlandIce;
				$landValue->[$sx][$sy] = 0;

		                if (rand(1000) < 100) {
		                    $land->[$sx][$sy] = $HlandMonument;
		                    $landValue->[$sx][$sy] = 76;
		                }
			    # �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				   logMsMonMoney($id, $tName, $value);
			    }
			}
		    } elsif(($land->[$sx][$sy] == $HlandBase) ||
			    ($land->[$sx][$sy] == $HlandDefence) ||
			    ($land->[$sx][$sy] == $HlandOil) ||
			    ($land->[$sx][$sy] == $HlandFune)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
			$tKind = $land->[$sx][$sy];
			$tlv = $landValue->[$sx][$sy];

			if (rand(1000) < 200) {
			    logIceAttack($id, $name, $mName, "($x, $y)", landName($tKind, $tlv), "($sx, $sy)");
				$land->[$sx][$sy] = $HlandIce;
				$landValue->[$sx][$sy] = 0;
		                if (rand(1000) < 100) {
		                    $land->[$sx][$sy] = $HlandMonument;
		                    $landValue->[$sx][$sy] = 76;
		                }
			}
		    }
		}


	    } elsif ($mKind == 19) {
	      if (rand(1000) < 333) {
			logMgMeteo($id, $name, $mName, "($x, $y)");
		my($sx, $sy, $landKind, $lv, $point, $first);
		$first = 1;
		while((random(3) == 0) || ($first == 1)) {
		    $first = 0;
		    # �
		    $sx = random($HislandSize);
		    $sy = random($HislandSize);
		    $landKind = $land->[$sx][$sy];
		    $lv = $landValue->[$sx][$sy];
		    $point = "($sx, $sy)";

		    if(($landKind == $HlandSea) && ($lv == 0)){
			# ���ݥ���
			logMeteoSea($id, $name, landName($landKind, $lv),
				    $point);
		    } elsif($landKind == $HlandMountain) {
			# ���˲�
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			next;
		    } elsif($landKind == $HlandGold) {
			# ���˲�
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			next;
		    } elsif($landKind == $HlandOnsen) {
			# ���˲�
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			next;
		    } elsif($landKind == $HlandSbase) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandSeacity) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandSeatown) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandUmishuto) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandFune) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandFrocity) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandUmiamu) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandMonster) {
			logMeteoMonster($id, $name, landName($landKind, $lv),
					$point);
		    } elsif($landKind == $HlandSea) {
			# ����
			logMeteoSea1($id, $name, landName($landKind, $lv),
				     $point);
		    } elsif($landKind == $HlandIce) {
			# ����
			logMeteoSea1($id, $name, landName($landKind, $lv),
				     $point);
		    } else {
			logMeteoNormal($id, $name, landName($landKind, $lv),
				       $point);
		    }
		    $land->[$sx][$sy] = $HlandSea;
		    $landValue->[$sx][$sy] = 0;
		    }
		}

	      if (rand(1000) < 400) {
			logMgMeteo($id, $name, $mName, "($x, $y)");
		my($sx, $sy, $landKind, $lv, $point);

		# �
		$sx = random($HislandSize);
		$sy = random($HislandSize);
		$landKind = $land->[$sx][$sy];
		$lv = $landValue->[$sx][$sy];
		$point = "($sx, $sy)";

		# ��å�����
		logHugeMeteo($id, $name, $point);

		# �����ﳲ�롼����
		wideDamage($id, $name, $land, $landValue, $sx, $sy);
	    }

	    if(random(1000) < 450) {
		logMgEarthquake($id, $name, $mName, "($x, $y)");

		# �Ͽ�ȯ��
		logEarthquake($id, $name);
		my($sx, $sy, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
		    $sx = $Hrpx[$i];
		    $sy = $Hrpy[$i];
		    $landKind = $land->[$sx][$sy];
		    $lv = $landValue->[$sx][$sy];

		    if((($landKind == $HlandTown) && ($lv >= 100)) ||
		       (($landKind == $HlandFoodim) && ($lv < 480)) ||
		       (($landKind == $HlandProcity) && ($lv < 130)) ||
		       (($landKind == $HlandNewtown) && ($lv < 300)) ||
		       (($landKind == $HlandBigtown) && ($lv < 300)) ||
		       (($landKind == $HlandHTFactory) && ($lv < 500)) ||
		       (($landKind == $HlandSHTF) && ($lv < 500)) ||
		       ($landKind == $HlandRizort) ||
		       ($landKind == $HlandKajino) ||
		       ($landKind == $HlandBigRizort) ||
		       ($landKind == $HlandHaribote) ||
	               ($landKind == $HlandPark) ||
		       ($landKind == $HlandMinato) ||
	               ($landKind == $HlandKyujo) ||
	               ($landKind == $HlandKyujokai) ||
	               ($landKind == $HlandOnsen) ||
		       ($landKind == $HlandFactory)) {
			# 1/4�ǲ���
			if(random(4) == 0) {
			    logEQDamage($id, $name, landName($landKind, $lv),
					"($sx, $sy)");
			    $land->[$sx][$sy] = $HlandWaste;
			    $landValue->[$sx][$sy] = 0;
				if ($kind == $HlandOnsen) {
                        	# �⻳�ϻ������
                        	$land->[$sx][$sy] = $HlandMountain; # ���ˤʤ�
                        	$landValue->[$sx][$sy] = 0;
                    		}
			}
		    }

		}
	    }

		    my($i,$sx,$sy);
		    for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
		    if($land->[$sx][$sy] == $HlandMonster){
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
			my($tlv) = $landValue->[$sx][$sy];
			my($tspecial) = $HmonsterSpecial[$tKind];
		    if($tKind != 19){
		    if($tHp > $mHp){
			if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
	                   (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
			   (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
		    next;
		    }

		    logMgDrain($id, $name, $mName, $tName, "($x, $y)");


		    $tlv-=($tHp-$mHp);
			$landValue->[$sx][$sy] = $tlv;
		    if($mHp < 9){$lv+=($tHp-$mHp);}
			$landValue->[$x][$y] = $lv;
		    }else{
		    }
		    next;
		    }
		    }
		}


	    } elsif ($mKind == 20) {
	        $lv+=2;
		$landValue->[$x][$y] = $lv;
		if (random(1000) < 200) {
		$island->{'food'} -= int($island->{'food'} / 2);
		logFushoku($id, $name, $mName, "($x, $y)");
            	}
		if ($mHp > 13) {
		logUmlimit($id, $name, $mName, "($x, $y)");
		# �����ﳲ�롼����
		wideDamage($id, $name, $land, $landValue, $x, $y);

		my($sx, $sy, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
		    $sx = $Hrpx[$i];
		    $sy = $Hrpy[$i];
		    $landKind = $land->[$sx][$sy];
		    $lv = $landValue->[$sx][$sy];

		    if((($landKind == $HlandTown) && ($lv >= 100)) ||
		       (($landKind == $HlandFoodim) && ($lv < 480)) ||
		       (($landKind == $HlandProcity) && ($lv < 130)) ||
		       ($landKind == $HlandHaribote) ||
	               ($landKind == $HlandPark) ||
		       ($landKind == $HlandMinato) ||
	               ($landKind == $HlandKyujo) ||
	               ($landKind == $HlandKyujokai) ||
		       ($landKind == $HlandBase) ||
		       ($landKind == $HlandFactory)) {
			# 1/6�ǲ���
			if(random(6) == 0) {
			    logUmlimitDamage($id, $name, $mName, landName($landKind, $lv),
					"($sx, $sy)");
			    $land->[$sx][$sy] = $HlandWaste;
			    $landValue->[$sx][$sy] = 0;

		                if (rand(1000) < 150) {
		                    $land->[$sx][$sy] = $HlandMonument;
		                    $landValue->[$sx][$sy] = 74;
		                }
			}
		    }
		}
		    $kind = 21;
		    $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		    $land->[$x][$y] = $HlandMonster;
		    $landValue->[$x][$y] = $lv;
            	}


	    } elsif ($mKind == 21) {
		if($mHp < 9){$lv+=3;}
		$landValue->[$x][$y] = $lv;
		if (random(1000) < 150) {
		$island->{'money'} -= int($island->{'money'} / 2);
		logKyoukou($id, $name, $mName, "($x, $y)");
            	}
		if (random(1000) < 200) {
		$island->{'food'} = 0;
		logFushoku($id, $name, $mName, "($x, $y)");
            	}
		    my($i,$sx,$sy);
		    for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
			 if(($land->[$sx][$sy] == $HlandPlains) ||
			    ($land->[$sx][$sy] == $HlandPlains2) ||
			    ($land->[$sx][$sy] == $HlandForest) ||
			    ($land->[$sx][$sy] == $HlandNursery) ||
			    ($land->[$sx][$sy] == $HlandFarmchi) ||
			    ($land->[$sx][$sy] == $HlandFarmpic) ||
			    ($land->[$sx][$sy] == $HlandFarmcow) ||
			    ($land->[$sx][$sy] == $HlandRottenSea)) {
			# �оݤȤʤ���äγ����Ǽ��Ф�
			$tKind = $land->[$sx][$sy];
			$tlv = $landValue->[$sx][$sy];

			if (rand(1000) < 200) {
			    logHellAttack($id, $name, $mName, "($x, $y)", landName($tKind, $tlv), "($sx, $sy)");
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
		                if (rand(1000) < 100) {
		                    $land->[$sx][$sy] = $HlandMonument;
		                    $landValue->[$sx][$sy] = 78;
		                }
		                if (rand(1000) < 100) {
		                    $land->[$sx][$sy] = $HlandMonument;
		                    $landValue->[$sx][$sy] = 74;
		                }
			}
		    }
		}

	    } elsif ($mKind == 30) {


	    if($island->{'monsterlive'} - $island->{'c28'} == 0){
		# �ƥȥ����������
		if($island->{'co99'} == 0){
			logMstakeiede($id, $name, "�з����Ķ���åƥȥ�","($sx, $sy)",landName($landKind, $lv));
	        } else {
			my($i,$sx,$sy);
			for($i = 1; $i < $HpointNumber; $i++){
			    $sx = $Hrpx[$i];
			    $sy = $Hrpy[$i];
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
			if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
			$landValue->[$sx][$sy] = 98;
			logMstakeokaeri($id, $name, "�з����Ķ���åƥȥ�","($sx, $sy)",landName($landKind, $lv));
		        }
		        }
		}
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
	    }


	    my($i,$sx,$sy);
	    for($i = 1; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster){
		if($msseigen < 1) {
		# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��

		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

		if(($tKind == 30)||($tKind == 23)) {
		} else {

		$eisei5 = $island->{'eisei5'};
		$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

		$attackdamege = random($msap-$tKind);
		$counterdamege = random($tKind-$msdp);
		if($attackdamege < 1){
		$attackdamege = 2;
		}
		if($counterdamege < 1){
		$counterdamege = 1;
		}

		if(rand(5+$tKind) > $mssp){
		$attackdamege = 0;
		}
		if(rand(5+$tKind) < $mssp){
		$counterdamege = 0;
		}

		logMsAttackt($id, $name, "Ķ���åƥȥ�", $attackdamege, $counterdamege, $tName, "($sx, $sy)");
		$msseigen++;
		$tHp -= $attackdamege;
		$tlv -= $attackdamege;
		$landValue->[$sx][$sy] = $tlv;
		$mHp -= $counterdamege;
		$lv -= $counterdamege;
		$landValue->[$x][$y] = $lv;

		if($tHp < 1){
		# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
		if($tKind == 13) {
		$land->[$sx][$sy] = $HlandMonument;
		$landValue->[$sx][$sy] = 93;
		logMsAttackmika($id, $name, "Ķ���åƥȥ�", $attackdamege, $counterdamege, $tName, $tPoint);
		}
		# �󾩶�
		my($value) = $HmonsterValue[$tKind];
		   $island->{'money'} += $value;

		if(rand(1000) < $value) {
		    if(rand(100) < 30) {
		    $msap++;
		    } elsif (rand(100) < 30) {
		    $msdp++;
		    } elsif (rand(100) < 30) {
		    $mssp++;
		    } else {
		    $mshp++;
			if($mshp > 15){
			$mshp = 15;
			}
		    }
		}

		    $msexe += $HmonsterExp[$tKind];
		    $mswin ++;
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";

		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
		    logMsMonMoney($id, $tName, $value);
		}
		if($mHp < 1){
		# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
		# �󾩶�
		my($value) = $HmonsterValue[$mKind];
		   $island->{'money'} += $value;
		   logMsMonMoney($id, $mName, $value);
		}
	    }
	    }
	    next;
	    }
	    }



	    } elsif ($mKind == 29) {

	    if($island->{'monsterlive'} == 1){
		# ���ƥȥ����������
		if($island->{'co99'} == 0){
	        } else {
			my($i,$sx,$sy);
			for($i = 1; $i < $HpointNumber; $i++){
			    $sx = $Hrpx[$i];
			    $sy = $Hrpy[$i];
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
			if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
			$landValue->[$sx][$sy] = 98;
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			logMstakeokaeri($id, $name, "�ƥȥ�","($sx, $sy)",landName($landKind, $lv));
		        }
		        }
		}
	    }


	    } elsif ($mKind == 28) {

	    if($island->{'monsterlive'} - $island->{'c28'} == 0){
		# �ޥ����åȤ��Τ����������
		if($island->{'co99'} == 0){
			logMstakeiede($id, $name, "�з���Υޥ����åȤ��Τ�","($sx, $sy)",landName($landKind, $lv));
	        } else {
			my($i,$sx,$sy);
			for($i = 1; $i < $HpointNumber; $i++){
			    $sx = $Hrpx[$i];
			    $sy = $Hrpy[$i];
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
			if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
			$landValue->[$sx][$sy] = 4;
			logMstakeokaeri($id, $name, "�з���Υޥ����åȤ��Τ�","($sx, $sy)",landName($landKind, $lv));
		        }
		        }
		}
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
	    }


	    my($i,$sx,$sy);
	    for($i = 1; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster){
		if($msseigen < 1) {
		# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��

		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

		if(($tKind == 28)||($tKind == 23)) {
		} else {

		$eisei5 = $island->{'eisei5'};
		$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

		$attackdamege = random($msap-$tKind);
		$counterdamege = random($tKind-$msdp);
		if($attackdamege < 1){
		$attackdamege = 1;
		}
		if($counterdamege < 1){
		$counterdamege = 1;
		}

		if(rand(5+$tKind) > $mssp){
		$attackdamege = 0;
		}
		if(rand(5+$tKind) < $mssp){
		$counterdamege = 0;
		}

		logMsAttackt($id, $name, "�ޥ����åȤ��Τ�", $attackdamege, $counterdamege, $tName, "($sx, $sy)");
		$msseigen++;
		$tHp -= $attackdamege;
		$tlv -= $attackdamege;
		$landValue->[$sx][$sy] = $tlv;
		$mHp -= $counterdamege;
		$lv -= $counterdamege;
		$landValue->[$x][$y] = $lv;

		if($tHp < 1){
		# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
		# �󾩶�
		my($value) = $HmonsterValue[$tKind];
		   $island->{'money'} += $value;

		if(rand(1000) < $value) {
		    if(rand(100) < 30) {
		    $msap++;
		    } elsif (rand(100) < 30) {
		    $msdp++;
		    } elsif (rand(100) < 30) {
		    $mssp++;
		    } else {
		    $mshp++;
			if($mshp > 15){
			$mshp = 15;
			}
		    }
		}

		    $msexe += $HmonsterExp[$tKind];
		    $mswin ++;
                                # �����༣��
                                $island->{'taiji'}++;

				# �޴ط�
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";

		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
		    logMsMonMoney($id, $tName, $value);
		}
		if($mHp < 1){
		# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
		# �󾩶�
		my($value) = $HmonsterValue[$mKind];
		   $island->{'money'} += $value;
		   logMsMonMoney($id, $mName, $value);
		}
	    }
	    }
	    next;
	    }
	    }



	    } elsif(($special == 6) ||
		  ($mKind == 13)) {
	    my($i,$sx,$sy);
	    for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster){
		if($kougekiseigenm < 2) {
		# ����2Hex���̤β��ä������硢���β��ä򹶷⤹��

		# �оݤȤʤ���äγ����Ǽ��Ф�
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

	    if($mHp > $tHp){ # �оݤ�����Ϥ�¿���ä����
		if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
                   (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
		   (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
		# �оݤ��Ų���ʤ���̤ʤ�
	    next;
	    }

	    if($mKind == 13) {
	    logMonsAttackt($id, $name, $mName, "($x, $y)", $tName, $tPoint);
	    }else{
	    logMonsAttack($id, $name, $mName, "($x, $y)", $tName, $tPoint);
	    }

	    $kougekiseigenm++;

	    $tHp--;
	    if($tHp != 0){
	    # �оݤ����Ϥ򸺤餹
	    $tlv--;
		$landValue->[$sx][$sy] = $tlv;
	    }else{
	    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	    # �󾩶�
		my($value) = $HmonsterValue[$tKind];
		   $island->{'money'} += $value;
		   logMsMonMoney($id, $tName, $value);
		}
	    # �оݤβ��ä����Ϥ�å�äƼ�ʬ�����Ϥ����
	    if($mHp < 9){$lv++;}
		$landValue->[$x][$y] = $lv;
	    }else{ # �оݤ�����Ϥ��㤫�ä����
	    # ���⤷�ʤ�
	    }
	    next;
	    }
	    }
	}
	}

	    # ư�����������
	    my($d, $sx, $sy);
	    my($i);
	    for($i = 0; $i < 3; $i++) {
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# �Ԥˤ�����Ĵ��
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		    $sx--;
		}

		# �ϰϳ�Ƚ��
		if(($sx < 0) || ($sx >= $HislandSize) ||
		   ($sy < 0) || ($sy >= $HislandSize)) {
		    next;
		}

		# �������𡢳����Իԡ����ġ����á�������ǰ��ʳ�
		if(($land->[$sx][$sy] != $HlandSea) &&
		   ($land->[$sx][$sy] != $HlandSbase) &&
		   ($land->[$sx][$sy] != $HlandSeacity) &&
		   ($land->[$sx][$sy] != $HlandSeatown) &&
		   ($land->[$sx][$sy] != $HlandBigtown) &&
		   ($land->[$sx][$sy] != $HlandBettown) &&
		   ($land->[$sx][$sy] != $HlandSkycity) &&
		   ($land->[$sx][$sy] != $HlandUmicity) &&
		   ($land->[$sx][$sy] != $HlandShuto) &&
		   ($land->[$sx][$sy] != $HlandUmishuto) &&
		   ($land->[$sx][$sy] != $HlandFune) &&
		   ($land->[$sx][$sy] != $HlandFrocity) &&
		   ($land->[$sx][$sy] != $HlandUmiamu) &&
		   ($land->[$sx][$sy] != $HlandOil) &&
		   ($land->[$sx][$sy] != $HlandZoo) &&
		   ($land->[$sx][$sy] != $HlandNursery) &&
		   ($land->[$sx][$sy] != $HlandBigRizort) &&
		   ($land->[$sx][$sy] != $HlandKajino) &&
		   ($land->[$sx][$sy] != $HlandGold) &&
		   ($land->[$sx][$sy] != $HlandMountain) &&
		   ($land->[$sx][$sy] != $HlandOnsen) &&
		   ($land->[$sx][$sy] != $HlandMonument) &&
		   ($land->[$sx][$sy] != $HlandRottenSea) &&
		   ($land->[$sx][$sy] != $HlandHouse) &&
		   ($land->[$sx][$sy] != $HlandTaishi) &&
		   ($land->[$sx][$sy] != $HlandMonster)) {
		    last;
		}
	    }

	    if($i == 3) {
		# ư���ʤ��ä�
		next;
	    }

	    if (($mKind == 28) ||
		($mKind == 30)) {
		if($land->[$sx][$sy] != $HlandWaste) {
		    next;
		}
	    }

	    # ư��������Ϸ��ˤ���å�����
	    my($l) = $land->[$sx][$sy];
	    my($lv) = $landValue->[$sx][$sy];
	    my($lName) = landName($l, $lv);
	    my($point) = "($sx, $sy)";

	    # ��ư
	    $land->[$sx][$sy] = $land->[$x][$y];
	    $landValue->[$sx][$sy] = $landValue->[$x][$y];

	    # ��ȵ錄���֤���Ϥ�
	    $land->[$x][$y] = $HlandWaste;
	    $landValue->[$x][$y] = 0;

		if ($mKind == 11) {
		    if((rand(1000) < 900) &&
		       ($island->{'monsterlive'} < 7)) { # ���饤��ʤ飹��% �γ�Ψ��ʬ������
		    my($point) = "($x, $y)";
		    $kind = 11;
		    $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		    $land->[$x][$y] = $HlandMonster;
		    $landValue->[$x][$y] = $lv;
		    } elsif((rand(20000) < 400-$island->{'monsterlive'}) &&
		       ($island->{'monsterlive'} > 7)) {
		    my($point) = "($x, $y)";
		    $kind = 11;
		    $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		    $land->[$x][$y] = $HlandMonster;
		    $landValue->[$x][$y] = $lv;
			lognewMonsterBorn($id, $name, $point);
		    }
		}

		if (($mKind == 15) ||
		    ($mKind == 19)) { # ���饤��ʤ�(���Τ��ή��)
		if ((rand(1000) < 600) &&
		($island->{'monsterlive'} < 7)) {
		my($point) = "($x, $y)";
		    $kind = random($HmonsterLevel3) + 1;
		    $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		    $land->[$x][$y] = $HlandMonster;
		    $landValue->[$x][$y] = $lv;
		    my($mKind, $mName, $mHp) = monsterSpec($lv);
		if ($mKind == 15) {
			lognewKaiju($id, $name, $mName, $point);
		}else{
		    my($l) = $land->[$sx][$sy];
		    my($lv) = $landValue->[$sx][$sy];
		    my($nName) = landName($l, $lv);
			logShoukan($id, $name, $nName, $mName, $point);
		}
		}
		}

            if ($mKind == 8) { # ������ʤ顡���������ɲ�
                if (rand(1000) < 400) {
                    # 0.1% �γ�Ψ���峤�����ޤ��
                    my($point) = "($x, $y)";
                    logRottenSeaBorn($id, $name, $point);
                    $land->[$x][$y] = $HlandRottenSea;
                    $landValue->[$x][$y] = 1;
                } elsif (rand(1000) < 200) {
                    # æ��
                    my($point) = "($x, $y)";
                    logNuginugi($id, $name, $point);
                    $land->[$x][$y] = $HlandMonument;
                    $landValue->[$x][$y] = 87;
		    $kind = 8;
		    $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random(3);
		    $land->[$sx][$sy] = $HlandMonster;
		    $landValue->[$sx][$sy] = $lv;
                }
            }#�����ޤ��ɲ�

            # ���ä����Ϥ�Ƥ��Ԥ���ǽ��
            if (($special == 7) ||
		($mKind == 16)) {
                my($i, $ssx, $ssy, $kind, $lv);
                for($i = 1; $i < 7; $i++) {
                    $ssx = $sx + $ax[$i];
                    $ssy = $sy + $ay[$i];

                    # �Ԥˤ�����Ĵ��
                    if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
                        $ssx--;
                    }
		    if(($ssx < 0) || ($ssx >= $HislandSize) ||
		       ($ssy < 0) || ($ssy >= $HislandSize)) {
		        # �ϰϳ�
		        next;
		    }

                    $kind = $land->[$ssx][$ssy];
                    $lv   = $landValue->[$ssx][$ssy];

                    if (($kind == $HlandSea) ||
                        ($kind == $HlandSeacity) ||
                        ($kind == $HlandSeatown) ||
                        ($kind == $HlandUmishuto) ||
                        ($kind == $HlandIce) ||
                        ($kind == $HlandWaste) ||
                        ($kind == $HlandUmiamu) ||
                        ($kind == $HlandSbase)) {
                        # ���ȳ�����ϤϾƤ���ʤ�
                        next;
                    } elsif ($kind == $HlandOil) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandSea; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandFune) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandSea; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandFrocity) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandSea; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandNursery) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandSea; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 1;
	            } elsif ($kind == $HlandGold) {
                        # �⻳�ϻ������
                        $land->[$ssx][$ssy] = $HlandMountain; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
	            } elsif ($kind == $HlandOnsen) {
                        # �⻳�ϻ������
                        $land->[$ssx][$ssy] = $HlandMountain; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif (($kind == $HlandMountain) && ($lv > 0)) {
                        # �η���ϻ������
                        $landValue->[$ssx][$ssy] = 0; # �η���κ�Ȱ��ϲ���
	            } elsif ($kind == $HlandMonster) {
                        # ���ä�
			# �оݤȤʤ���äγ����Ǽ��Ф�
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$ssx][$ssy]);
			my($tlv) = $landValue->[$ssx][$ssy];
			my($tspecial) = $HmonsterSpecial[$tKind];
			    if(($tKind == 28) ||
				($tKind == 30)) {
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$ssx][$ssy] = $tlv;

				if($tHp < 1){
				# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
				# �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				    logMsMonMoney($id, $tName, $value);
				}
			    }

                    } else {
                        # ���Ƥ��Ƥ��Ԥ������
                        $land->[$ssx][$ssy] = $HlandWaste; # �Ӥ��Ϥˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    }

                    # �������������
                    logMonsFire($id, $name, landName($kind, $lv), "($ssx, $ssy)", $mName);
                }
            }
            # ���ä����Ϥ�Ƥ��Ԥ���ǽ��
            if (($mKind == 13) ||
		($mKind == 18)) {
                my($i, $ssx, $ssy, $kind, $lv);
                for($i = 1; $i < 19; $i++) {
                    $ssx = $sx + $ax[$i];
                    $ssy = $sy + $ay[$i];

                    # �Ԥˤ�����Ĵ��
                    if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
                        $ssx--;
                    }
		    if(($ssx < 0) || ($ssx >= $HislandSize) ||
		       ($ssy < 0) || ($ssy >= $HislandSize)) {
		        # �ϰϳ�
		        next;
		    }

                    $kind = $land->[$ssx][$ssy];
                    $lv   = $landValue->[$ssx][$ssy];

                    if (($kind == $HlandSea) ||
                        ($kind == $HlandIce) ||
                        ($kind == $HlandSeacity) ||
                        ($kind == $HlandSeatown) ||
                        ($kind == $HlandUmishuto) ||
                        ($kind == $HlandWaste) ||
                        ($kind == $HlandUmiamu) ||
                        ($kind == $HlandSbase)) {
                        # ���ȳ�����ϤϾƤ���ʤ�
                        next;
                    } elsif ($kind == $HlandOil) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandSea; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandFune) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandSea; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandFrocity) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandSea; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandNursery) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandSea; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 1;
	            } elsif ($kind == $HlandGold) {
                        # �⻳�ϻ������
                        $land->[$ssx][$ssy] = $HlandMountain; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
	            } elsif ($kind == $HlandOnsen) {
                        # �⻳�ϻ������
                        $land->[$ssx][$ssy] = $HlandMountain; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif (($kind == $HlandMountain) && ($lv > 0)) {
                        # �η���ϻ������
                        $landValue->[$ssx][$ssy] = 0; # �η���κ�Ȱ��ϲ���

	            } elsif ($kind == $HlandMonster) {
                        # ���ä�
			# �оݤȤʤ���äγ����Ǽ��Ф�
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$ssx][$ssy]);
			my($tlv) = $landValue->[$ssx][$ssy];
			my($tspecial) = $HmonsterSpecial[$tKind];
			    if(($tKind == 28) ||
				($tKind == 30)) {
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$ssx][$ssy] = $tlv;

				if($tHp < 1){
				# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
				# �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				    logMsMonMoney($id, $tName, $value);
				}
			    }

                    } else {
                        # ���Ƥ��Ƥ��Ԥ������
                        $land->[$ssx][$ssy] = $HlandWaste; # �Ӥ��Ϥˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    }

                    # �������������
                    logMonsFire($id, $name, landName($kind, $lv), "($ssx, $ssy)", $mName);
                }
            }


            # �ե꡼�����ȡ���
            if (($special == 9) ||
		($mKind == 22)) {
                my($i, $ssx, $ssy, $kind, $lv);
                for($i = 1; $i < 7; $i++) {
                    $ssx = $sx + $ax[$i];
                    $ssy = $sy + $ay[$i];

                    # �Ԥˤ�����Ĵ��
                    if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
                        $ssx--;
                    }
		    if(($ssx < 0) || ($ssx >= $HislandSize) ||
		       ($ssy < 0) || ($ssy >= $HislandSize)) {
		        # �ϰϳ�
		        next;
		    }

                    $kind = $land->[$ssx][$ssy];
                    $lv   = $landValue->[$ssx][$ssy];

                    if (($kind == $HlandSeacity) ||
                        ($kind == $HlandSeatown) ||
                        ($kind == $HlandUmishuto) ||
                        ($kind == $HlandIce) ||
                        ($kind == $HlandUmiamu) ||
                        ($kind == $HlandSbase)) {
                        # ���ȳ�����ϤϾƤ���ʤ�
                        next;
                    } elsif ($kind == $HlandOil) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandIce; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandFune) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandIce; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandFrocity) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandIce; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    } elsif ($kind == $HlandNursery) {
                        # ���Ĥϳ������
                        $land->[$ssx][$ssy] = $HlandIce; # ���ˤʤ�
                        $landValue->[$ssx][$ssy] = 1;
	            } elsif ($kind == $HlandMonster) {
                        # ���ä�
			# �оݤȤʤ���äγ����Ǽ��Ф�
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$ssx][$ssy]);
			my($tlv) = $landValue->[$ssx][$ssy];
			my($tspecial) = $HmonsterSpecial[$tKind];
			    if(($tKind == 28) ||
				($tKind == 30)) {
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$ssx][$ssy] = $tlv;

				if($tHp < 1){
				# �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
				$land->[$ssx][$ssy] = $HlandIce;
				$landValue->[$ssx][$ssy] = 0;
				# �󾩶�
				my($value) = $HmonsterValue[$tKind];
				   $island->{'money'} += $value;
				    logMsMonMoney($id, $tName, $value);
				}
			    }
                    } else {
                        # ���Ƥ��Ƥ��Ԥ������
                        $land->[$ssx][$ssy] = $HlandIce; # �Ӥ��Ϥˤʤ�
                        $landValue->[$ssx][$ssy] = 0;
                    }

                    # �������������
                    logMonsCold($id, $name, landName($kind, $lv), "($ssx, $ssy)", $mName);
                }
            }


            if (($mKind == 14) &&
		($island->{'monsterlive'} < 7)) {
                my($i, $ssx, $ssy, $kind, $lv);
                for($i = 1; $i < 7; $i++) {
                    $ssx = $sx + $ax[$i];
                    $ssy = $sy + $ay[$i];

                    # �Ԥˤ�����Ĵ��
                    if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
                        $ssx--;
                    }
		    if(($ssx < 0) || ($ssx >= $HislandSize) ||
		       ($ssy < 0) || ($ssy >= $HislandSize)) {
		        # �ϰϳ�
		        next;
		    }

                    $kind = $land->[$ssx][$ssy];
                    $lv   = $landValue->[$ssx][$ssy];

                    if (($kind == $HlandSea) ||
                        ($kind == $HlandSeacity) ||
                        ($kind == $HlandSeatown) ||
                        ($kind == $HlandUmishuto) ||
                        ($kind == $HlandOil) ||
                        ($kind == $HlandFune) ||
                        ($kind == $HlandFrocity) ||
                        ($kind == $HlandNursery) ||
                        ($kind == $HlandUmiamu) ||
                        ($kind == $HlandMountain) ||
                        ($kind == $HlandGold) ||
                        ($kind == $HlandOnsen) ||
                        ($kind == $HlandMonster) ||
                        ($kind == $HlandSbase)) {
                        # ���ȳ�����ϤϾƤ���ʤ�
                        next;
                    } else {
                        # ���Ƥ��Ƥ��Ԥ������
		    $kind = 11;
		    $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		    $land->[$ssx][$ssy] = $HlandMonster;
		    $landValue->[$ssx][$ssy] = $lv;
                    }
		                if (rand(1000) < 50) {
		                    $land->[$ssx][$ssy] = $HlandMonument;
		                    $landValue->[$ssx][$ssy] = 77;
		                }
                    # �������������
		    lognewMonsterBorn($id, $name, "($ssx, $ssy)");
                }
            }

	    # ��ư�Ѥߥե饰
	    if($HmonsterSpecial[$mKind] == 2) {
		# ��ư�Ѥߥե饰��Ω�Ƥʤ�
	    } elsif($HmonsterSpecial[$mKind] == 1) {
		# ®������
		$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
	    } else {
		# ���̤β���
		$monsterMove[$sx][$sy] = 2;
	    }

	    if(($l == $HlandDefence) && ($HdBaseAuto == 1)) {
		# �ɱһ��ߤ�Ƨ���
		logMonsMoveDefence($id, $name, $lName, $point, $mName);

		# �����ﳲ�롼����
		wideDamage($id, $name, $land, $landValue, $sx, $sy);
            } elsif ($l == $HlandMine) {
                # �����Ƨ���
                if ($mHp < $lv) {
                    # ��˴���ƻ��Τ����ӻ��ä�
                    logMonsMineKill($id, $name, $lName, $point, $mName);
                } elsif ($mHp == $lv) {
                    # ��˴���ƻ��Τ��Ĥä�
                    logMonsMineDead($id, $name, $lName, $point, $mName);

                    # ����
                    my($value) = $HmonsterValue[$mKind];
                    if($value > 0) {
                        $island->{'money'} += $value;
                        logMsMonMoney($id, $mName, $value);
                    }

                                # �����༣��
                                $island->{'taiji'}++;

                    # �޴ط�
                    my($prize) = $island->{'prize'};
                    $prize =~ /([0-9]*),([0-9]*),(.*)/;
                    my($flags) = $1;
                    my($monsters) = $2;
                    my($turns) = $3;
                    my($v) = 2 ** $mKind;
                    $monsters |= $v;
                    $island->{'prize'} = "$flags,$monsters,$turns";
                } else {
                    # �����Ĥä�
                    logMonsMineHit($id, $name, $lName, $point, $mName);
                    $landValue->[$sx][$sy] -= $lv;
                    next;
                }

                # ���äϹ��Ϥ�
                $land->[$sx][$sy] = $HlandWaste;
                $landValue->[$sx][$sy] = 1;
	    } else {
		# �Ԥ��褬���Ϥˤʤ�
                    if ($l == $HlandWaste) {
                    } else {
		    logMonsMove($id, $name, $lName, $point, $mName);
                    }
	    }
	}

	if(($landKind == $HlandConden4) && ($lv == 99)) {
	    my($l) = $land->[$x][$y];
	    my($lv) = $landValue->[$x][$y];
	    my($point) = "($x, $y)";
	    my($lName) = landName($l, $lv);
	    $etc9 = $island->{'etc9'};
	    $etc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($co7, $magicf, $magici, $magica, $magicw, $magicl, $magicd) = ($1, $2, $3, $4, $5, $6, $7);

	    if($magica != $magicl) {
	    logRouden2($id, $name, $lName, $point);

		    my($sx, $sy, $i, $landKind, $landName, $lv, $point);

		    my($yh) = 19;
			# �ϰϳ�Ƚ��
			if($s02 >= 25) {
			    $yh = 7;
			}

		    for($i = 1; $i < $yh; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			    $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# �ϰϳ�Ƚ��
			if(($sx < 0) || ($sx >= $HislandSize) ||
			   ($sy < 0) || ($sy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 7) {
			    # �濴�������1�إå���
			    if($landKind == $HlandSea) {
				$landValue->[$sx][$sy] = 0;
				next;
			    } elsif(($landKind == $HlandSbase) ||
				    ($landKind == $HlandSeacity) ||
				    ($landKind == $HlandSeatown) ||
				    ($landKind == $HlandUmishuto) ||
				    ($landKind == $HlandFune) ||
				    ($landKind == $HlandIce) ||
				    ($landKind == $HlandFrocity) ||
				    ($landKind == $HlandUmiamu) ||
				    ($landKind == $HlandOil)) {
				logWideDamageSea2($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			    } else {

				    logBariaAttack($id, $name, $landName, $point);

				$land->[$sx][$sy] = $HlandSea;
				if($i == 0) {
				    # ��
				    $landValue->[$sx][$sy] = 0;
				} else {
				    # ����
				    $landValue->[$sx][$sy] = 1;
				}
			    }
			} else {
			    # 2�إå���
			    if(($landKind == $HlandSea) ||
			       ($landKind == $HlandIce) ||
			       ($landKind == $HlandOil) ||
			       ($landKind == $HlandWaste) ||
			       ($landKind == $HlandMountain) ||
			       ($landKind == $HlandGold) ||
			       ($landKind == $HlandOnsen) ||
			       ($landKind == $HlandSeacity) ||
			       ($landKind == $HlandUmishuto) ||
			       ($landKind == $HlandSeatown) ||
			       ($landKind == $HlandFune) ||
			       ($landKind == $HlandFrocity) ||
			       ($landKind == $HlandUmiamu) ||
			       ($landKind == $HlandSbase)) {
				next;
			    } else {
				logBariaAttack($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
			    }
			}
		    }

	    }
	}

	if((($landKind == $HlandConden2) || ($landKind == $HlandConden3)) && ($island->{'roudenflag'} == 0)) {
	    my($l) = $land->[$x][$y];
	    my($lv) = $landValue->[$x][$y];
	    my($point) = "($x, $y)";
	    my($lName) = landName($l, $lv);

	    if(random(150000) < 125+$island->{'co8'}/2.5) {
	    logRouden($id, $name, $lName, $point);
	    $land->[$x][$y] = $HlandConden4;
	    $island->{'roudenflag'}++;

		if($landKind == $HlandConden2) {
		$landValue->[$x][$y] = 2;
		}
		if($landKind == $HlandConden3) {
		$landValue->[$x][$y] = 3;
		}
	    }
	}

	if((($landKind == $HlandConden2) || ($landKind == $HlandConden3) || (($landKind == $HlandCollege) && ($lv == 8))) && ($island->{'roudenflag'} == 0)) {
	    my($l) = $land->[$x][$y];
	    my($lv) = $landValue->[$x][$y];
	    my($point) = "($x, $y)";
	    my($lName) = landName($l, $lv);
	# �淿���Ƚ��

	if((random(333333) < 100+$island->{'co8'}/3) && ($island->{'ene'} > 5000000)) {

	    my($i, $count, $sx, $sy);
	    $count = 0;
	    for($i = 0; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # �Ԥˤ�����Ĵ��
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
		     $sx--;
		 }

		 if(($sx < 0) || ($sx >= $HislandSize) ||
		    ($sy < 0) || ($sy >= $HislandSize)) {
		     # �ϰϳ��ξ��
		     if($kind == $HlandSea) {
			 # ���ʤ�û�
			 $count++;
		     }
		 } else {
		     # �ϰ���ξ��
		     if(($land->[$sx][$sy] == $HlandDefence) && ($landValue->[$sx][$sy] == 77)) {
			logTrainEnd2($id, $name, "�ɱһ��ߡ���", "($sx, $sy)");
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			 $count++;
		     }
		 }
	    }

	        if(($count > 0) && ($island->{'eis5'} >= 1)) {

		logMidMeteo2($id, $name, $point);
		$island->{'roudenflag'}++;
		$island->{'eis5'} -= random(50);
		        if($island->{'eis5'} < 1) {
		           $island->{'eis5'} = 0;
				logEiseiEnd($id, $name, "�ɱұ���");
		        }

		} else {

		logMidMeteo($id, $name, $point);
		$island->{'roudenflag'}++;

		    for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# �Ԥˤ�����Ĵ��
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			    $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# �ϰϳ�Ƚ��
			if(($sx < 0) || ($sx >= $HislandSize) ||
			   ($sy < 0) || ($sy >= $HislandSize)) {
			    next;
			}

			# �ϰϤˤ��ʬ��
			if($i < 1) {
			    if($landKind == $HlandSea) {
				$landValue->[$sx][$sy] = 0;
				next;
			    } elsif(($landKind == $HlandSbase) ||
				    ($landKind == $HlandSeacity) ||
				    ($landKind == $HlandSeatown) ||
				    ($landKind == $HlandUmishuto) ||
				    ($landKind == $HlandFune) ||
				    ($landKind == $HlandIce) ||
				    ($landKind == $HlandFrocity) ||
				    ($landKind == $HlandUmiamu) ||
				    ($landKind == $HlandOil)) {
				logWideDamageSea2($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 1;
			    }
			    # �濴�������1�إå���
				logWideDamageSea($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 1;
			    } else {
			    if(($landKind == $HlandSea) ||
				    ($landKind == $HlandSbase) ||
				    ($landKind == $HlandSeacity) ||
				    ($landKind == $HlandSeatown) ||
				    ($landKind == $HlandUmishuto) ||
				    ($landKind == $HlandFune) ||
				    ($landKind == $HlandIce) ||
				    ($landKind == $HlandFrocity) ||
				    ($landKind == $HlandUmiamu) ||
				    ($landKind == $HlandWaste) ||
				    ($landKind == $HlandOil)) {
				next;
			    }
				if(random(100) < 40) {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
				}
			    }
		    }
		}
	    }
	}

	# �к�Ƚ��
	if((($landKind == $HlandTown) && ($lv > 30)) ||
	   ($landKind == $HlandHaribote) ||
	   ($landKind == $HlandMinato) ||
	   ($landKind == $HlandFoodim) ||
	   ($landKind == $HlandFoodka) ||
	   ($landKind == $HlandOnsen) ||
	   ($landKind == $HlandKura) ||
	   ($landKind == $HlandKuraf) ||
	   ($landKind == $HlandHTFactory) ||
	   ($landKind == $HlandSHTF) ||
	   ($landKind == $HlandFactory)) {
	    if(random(1000) < $HdisFire-int($island->{'eis1'}/20)) {
		# ���Ϥο��ȵ�ǰ��������
		if((countAround($land, $x, $y, $HlandForest, 7) +
		    countAround($land, $x, $y, $HlandProcity, 7) +
		    countAround($land, $x, $y, $HlandHouse, 7) +
		    countAround($land, $x, $y, $HlandTaishi, 7) +
		    countAround($land, $x, $y, $HlandMonument, 7)) == 0) {
		    # ̵���ä���硢�кҤǲ���
		    my($l) = $land->[$x][$y];
		    my($lv) = $landValue->[$x][$y];
		    my($point) = "($x, $y)";
		    my($lName) = landName($l, $lv);
		    logFire($id, $name, $lName, $point);
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
				if ($kind == $HlandOnsen) {
                        	# �⻳�ϻ������
                        	$land->[$x][$y] = $HlandMountain; # ���ˤʤ�
                        	$landValue->[$x][$y] = 0;
                    		}
		}
	    }
	} 

	# �к�Ƚ��2
	if(($landKind == $HlandNewtown) ||
	   ($landKind == $HlandRizort) ||
	   ($landKind == $HlandKajino) ||
	   ($landKind == $HlandBigRizort) ||
	   ($landKind == $HlandBettown) ||
	   ($landKind == $HlandSkycity) ||
	   ($landKind == $HlandUmicity) ||
	   ($landKind == $HlandBigtown)) {
	    if(random(750) < $HdisFire-int($island->{'eis1'}/20)) {
		# ���Ϥο��ȵ�ǰ��������
		if((countAround($land, $x, $y, $HlandForest, 7) +
		    countAround($land, $x, $y, $HlandProcity, 7) +
		    countAround($land, $x, $y, $HlandHouse, 7) +
		    countAround($land, $x, $y, $HlandTaishi, 7) +
		    countAround($land, $x, $y, $HlandMonument, 7)) == 0) {
		    # ̵���ä���硢�кҤǲ���
		    my($l) = $land->[$x][$y];
		    my($lv) = $landValue->[$x][$y];
		    my($point) = "($x, $y)";
		    my($lName) = landName($l, $lv);
		    logFirenot($id, $name, $lName, $point);
	            $landValue->[$x][$y] -= random(100)+50;
		}
			if($landValue->[$x][$y] <= 0) {
			    # ʿ�Ϥ��᤹
			    my($l) = $land->[$x][$y];
			    my($lv) = $landValue->[$x][$y];
			    my($point) = "($x, $y)";
			    my($lName) = landName($l, $lv);
			    $land->[$x][$y] = $HlandWaste;
			    $landValue->[$x][$y] = 0;
		    	    logFire($id, $name, $lName, $point);
			    next;
			}
	    }
	} 
    }

    if ($rizortincome > 0) {
    logParkMoney($id, $name, "$rizortincome$HunitMoney", $island->{'riz'},"�꥾���Ȼ���");
    }

    if ($m84income > 0) {
    logParkMoney($id, $name, "$m84income$HunitMoney", $island->{'m84'},"�������");
    }

    if ($island->{'par'} > 0) {
    logParkMoney($id, $name, "$parkincome$HunitMoney", $island->{'par'},"ͷ����");
    }

    if ($island->{'oil'} > 0) {
    logParkMoney($id, $name, "$oilincome$HunitMoney", $island->{'oil'},"����");
    }

    if ($island->{'gyo'} > 0) {
    logParkMoney($id, $name, "$gyosenincome$HunitFood", $island->{'gyo'},"����");
    }

    if ($island->{'trainmoney'} > 0) {
    logParkMoney($id, $name, "$island->{'trainmoney'}$HunitMoney", $island->{'tra1'},"�����ż�");
    }
    if ($island->{'trainmoney2'} > 0) {
    logParkMoney($id, $name, "$island->{'trainmoney2'}$HunitMoney", $island->{'tra2'},"��ʪ���");
    }

}


# ���Ϥ�Į�����줬���뤫Ƚ��
sub countGrow {
    my($land, $landValue, $x, $y) = @_;
    my($i, $sx, $sy);
    for($i = 1; $i < 7; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # �Ԥˤ�����Ĵ��
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	     $sx--;
	 }

	 if(($sx < 0) || ($sx >= $HislandSize) ||
	    ($sy < 0) || ($sy >= $HislandSize)) {
	 } else {
	     # �ϰ���ξ��
	     if(($land->[$sx][$sy] == $HlandTown) ||
		($land->[$sx][$sy] == $HlandProcity) ||
		($land->[$sx][$sy] == $HlandNewtown) ||
		($land->[$sx][$sy] == $HlandRizort) ||
		($land->[$sx][$sy] == $HlandKajino) ||
		($land->[$sx][$sy] == $HlandBigRizort) ||
		($land->[$sx][$sy] == $HlandBettown) ||
		($land->[$sx][$sy] == $HlandSkycity) ||
		($land->[$sx][$sy] == $HlandUmicity) ||
		($land->[$sx][$sy] == $HlandBigtown) ||
		($land->[$sx][$sy] == $HlandFarm)) {
		 if($landValue->[$sx][$sy] != 1) {
		     return 1;
		 }
	     }
	 }
    }
    return 0;
}


# ���ȼԤϤɤ��ء�
sub doIslandunemployed {
    my($number, $island) = @_;

    # Ƴ����
    my($name) = $island->{'name'};
    my($id) = $island->{'id'};
    my($land) = $island->{'land'};
    my($landValue) = $island->{'landValue'};

    # ���ȼԤΰ�̱
    if(($island->{'unemployed'} >= 100) && (rand(100) < 25)) {
        # ���ȼԤ������Ͱʾ夤��� 25% �γ�Ψ�ǰ�̱���˾����

        my(@order) = randomArray($HislandNumber);
        my($migrate);

        # ��̱���õ��
        my($tIsland);
        my($n) = min($HislandNumber, 5);
        my($i);
        for($i = 0; $i < $n; $i++) { # ����ޤ�Ĵ�٤�
            $tIsland = $Hislands[$order[$i]];

            # �Ż��Τ�����˰�̱����
            if ($tIsland->{'unemployed'} < 0) {
                $migrate = min($island->{'unemployed'}, -$tIsland->{'unemployed'});
		$migrate2 = $migrate;
                last;
            }
        }

        if ($i >= $n) {
            # ��̱�褬���Ĥ���ʤ���С�˽ư���ǥ�Կ�

            $migrate = random($island->{'unemployed'} - 100) + 100;
            $n = 0;
            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $land->[$x][$y];
                $lv = $landValue->[$x][$y];

                if(($landKind == $HlandFarm) ||
                   ($landKind == $HlandFactory) ||
                   ($landKind == $HlandHTFactory) ||
                   ($landKind == $HlandSHTF) ||
                   ($landKind == $HlandOWNF) ||
                   ($landKind == $HlandFarmchi) ||
                   ($landKind == $HlandFarmpic) ||
                   ($landKind == $HlandFarmcow) ||
                   ($landKind == $HlandEneAt) ||
                   ($landKind == $HlandEneFw) ||
                   ($landKind == $HlandEneWt) ||
                   ($landKind == $HlandEneWd) ||
                   ($landKind == $HlandEneBo) ||
                   ($landKind == $HlandEneSo) ||
                   ($landKind == $HlandEneCs) ||
                   ($landKind == $HlandCollege) ||
                   ($landKind == $HlandYakusho) ||
                   ($landKind == $HlandBase) ||
		   ($landKind == $HlandFoodim) ||
		   ($landKind == $HlandFoodka) ||
	           ($landKind == $HlandNursery) ||
	           ($landKind == $HlandMine) ||
                   ($landKind == $HlandPark) ||
                   ($landKind == $HlandKyujo) ||
                   ($landKind == $HlandKyujokai) ||
                   ($landKind == $HlandZoo) ||
                   ($landKind == $HlandKura) ||
                   ($landKind == $HlandKuraf) ||
                   ($landKind == $HlandDefence)) {
                    # 25% �γ�Ψ�ǲ���
                    if(rand(100) < 25) {
                        $n++;
                        logUnemployedRiot($id, $name, landName($landKind, $lv), $migrate2, "($x, $y)");
                        $land->[$x][$y] = $HlandWaste;
                        $landValue->[$x][$y] = 0;
                    }
                }
            }

            # ��������ʤ��Ȥ��ϥǥ�Կʤ�Ԥ�
            logUnemployedDemo($id, $name, $migrate2) if ($n == 0);

        } else {
            # ��̱�褬���Ĥ��ä��Τǰ�̱
            my($tLand) = $tIsland->{'land'};
            my($tLandValue) = $tIsland->{'landValue'};

            my($employed) = $migrate;
            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $tLand->[$x][$y];
                $lv = $tLandValue->[$x][$y];

	        if($landKind == $HlandSeki) {
                   logUnemployedReturn($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, $migrate2);
		 return 1;
		 }
	    }

            # ��̱���Į�˲Ȥ��Ѱդ���
            my($employed) = $migrate;
            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $tLand->[$x][$y];
                $lv = $tLandValue->[$x][$y];

                if(($landKind == $HlandTown) ||
                   ($landKind == $HlandMinato) ||
                   ($landKind == $HlandNewtown) ||
                   ($landKind == $HlandFrocity) ||
                   ($landKind == $HlandOnsen) ||
                   ($landKind == $HlandSeacity)) {
                    # Į
                    $n = int((255 - $lv) / 2);
                    $n = min(int($n + rand($n)), $employed);
                    $employed -= $n;
                    $tLandValue->[$x][$y] += $n;
                } elsif ($landKind == $HlandPlains) {
                    # ʿ��
                    $n = int((255 - $lv) / 2);
                    $n = min(int($n + rand($n)), $employed);
                    $employed -= $n;
                    $tLand->[$x][$y] = $HlandTown;
                    $tLandValue->[$x][$y] = $n;
                }

                last if ($employed <= 0);
            }
            $migrate -= $employed;
            $island->{'unemployed'} -= $migrate;
            $tIsland->{'unemployed'} += $migrate;
            $island->{'pop'} -= $migrate;
            $tIsland->{'pop'} += $migrate;

            # ���ޤǽ���Ǥ����Ȥ��ʬ����
            $employed = $migrate;
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $land->[$x][$y];
                $lv = $landValue->[$x][$y];

                if((($landKind == $HlandTown) && ($lv > 1)) ||
		  (($landKind == $HlandMinato) && ($lv > 1)) ||
		  (($landKind == $HlandProcity) && ($lv > 1)) ||
		  (($landKind == $HlandFrocity) && ($lv > 1)) ||
		  (($landKind == $HlandNewtown) && ($lv > 1)) ||
		  (($landKind == $HlandBigtown) && ($lv > 1)) ||
		  (($landKind == $HlandBettown) && ($lv > 1)) ||
		  (($landKind == $HlandSkycity) && ($lv > 1)) ||
		  (($landKind == $HlandUmicity) && ($lv > 1)) ||
		  (($landKind == $HlandSeatown) && ($lv > 1)) ||
		  (($landKind == $HlandShuto) && ($lv > 1)) ||
		  (($landKind == $HlandUmishuto) && ($lv > 1)) ||
		  (($landKind == $HlandOnsen) && ($lv > 1)) ||
		  (($landKind == $HlandSeacity) && ($lv > 1))) {
                    # Į
                    $n = min($lv - 1, $employed);
                    $landValue->[$x][$y] -= $n;
                    $employed -= $n;

			if($landValue->[$x][$y] <= 0) {
			    $land->[$x][$y] = $HlandPlains;
			    $landValue->[$x][$y] = 0;
			}

                }
            }

            logUnemployedMigrate($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, $migrate2);
        }
    }
}

# ������
sub doIslandProcess {
    my($number, $island) = @_;

    # Ƴ����
    my($name) = $island->{'name'};
    my($id) = $island->{'id'};
    my($land) = $island->{'land'};
    my($landValue) = $island->{'landValue'};


    $etc5 = $island->{'etc5'};
    $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);


    $etc7 = $island->{'etc7'};
    $etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
    ($msjotai, $nokotan, $msid) = ($1, $2, $3);
	$nokotan -= 1;
	$island->{'etc7'} = "$msjotai,$nokotan,$msid";
	if ($nokotan < 1) {
	    $island->{'etc7'} = '0,0,0';
	}

    if ($island->{'stsankahantei'} == 1) {
	$value = $stsanka*random(2000);
	$island->{'money'} += $value;
	$str = "$value$HunitMoney";
	logHCstart($id, $name, $str);
    }


    if ($island->{'htf'} > 0) {
	    if($anothermood == 1) {
		$pika2 = int($island->{'amarimoney'}/2)
	    } else {
		$pika2 = int($island->{'pika'}/2);
	    }
	if ($pika2 < 0) {
	    $pika2 = 0;
	}
	$island->{'money'} -= $pika2;
    }

    elsif ($island->{'shtf'} > 0) {
	    if($anothermood == 1) {
		$pika2 = int($island->{'amarimoney'}/5)
	    } else {
		$pika2 = int($island->{'pika'}/5);
	    }
	if ($pika2 < 0) {
	    $pika2 = 0;
	}
	$island->{'money'} -= $pika2;
    }

    if(($HislandTurn % 100) == 0) {
	$island->{'ip8'} = 0;
    }

	$etc8 = $island->{'etc8'};
	$etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);


        # �꥾����˰�����ޤ���
    if(($island->{'riz'} > 0) && (rand(40) > $s06) && (rand(500+$s06*2) < 15)) {

        my(@order) = randomArray($HislandNumber);
        my($migrate);

        # ��̱���õ��
        my($tIsland);
        my($n) = min($HislandNumber, 5);
        my($i);
        for($i = 0; $i < $n; $i++) { # ����ޤ�Ĵ�٤�
            $tIsland = $Hislands[$order[$i]];

	    $tetc5 = $tIsland->{'etc5'};
	    $tetc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($ts00,$ts01,$ts02,$ts03,$ts04,$ts05,$ts06,$ts07,$ts08,$ts09,$ts10,$ts11,$ts12,$ts13,$ts14,$ts15,$ts16,$ts17,$ts18,$ts19,$ts20,$ts21,$ts22,$ts23,$ts24,$ts25,$ts26,$ts27,$ts28,$ts29,$ts30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	    $ts06b = int($ts06/5);

            # �Ż��Τ�����˰�̱����
            if (($island->{'pop'} > $tIsland->{'pop'}) && ($tIsland->{'riz'} > 0) && ($s06 <= $ts06) && ($island->{'id'} != $tIsland->{'id'})) {
                $migrate = ($ts06 - $s06 + 1) * (random(5) + 1);
		        if ($migrate <= 0) {
			    $migrate = 1;
		        }
		$migrate2 = $migrate;
                last;
            }
        }

        if ($i >= $n) {

        } else {
            # ��̱�褬���Ĥ��ä��Τǰ�̱
            my($tLand) = $tIsland->{'land'};
            my($tLandValue) = $tIsland->{'landValue'};
            my($employed) = $migrate;

            # ��̱���Į�˲Ȥ��Ѱդ���
            my($employed) = $migrate;
            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $tLand->[$x][$y];
                $lv = $tLandValue->[$x][$y];

                if($landKind == $HlandRizort) {
                    # Į
                    $n = int((350 - $lv) / 2);
                    $n = min(int($n + rand($n)), $employed);
                    $employed -= $n;
                    $tLandValue->[$x][$y] += $n;
                } elsif ($landKind == $HlandBigRizort) {
                    # ʿ��
                    $n = int((800 - $lv) / 2);
                    $n = min(int($n + rand($n)), $employed);
                    $employed -= $n;
                    $tLandValue->[$x][$y] += $n;
                 } elsif ($landKind == $HlandKajino) {
                    # ʿ��
                    $n = int((2000 - $lv) / 2);
                    $n = min(int($n + rand($n)), $employed);
                    $employed -= $n;
                    $tLandValue->[$x][$y] += $n;
                }

                last if ($employed <= 0);
            }
            $migrate -= $employed;
            $island->{'pop'} -= $migrate;
            $tIsland->{'pop'} += $migrate;

            # ���ޤǽ���Ǥ����Ȥ��ʬ����
            $employed = $migrate;
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $land->[$x][$y];
                $lv = $landValue->[$x][$y];

                if((($landKind == $HlandRizort) && ($lv > 1)) ||
		  (($landKind == $HlandBigRizort) && ($lv > 1))) {
                    # Į
                    $n = min($lv - 1, $employed);
                    $landValue->[$x][$y] -= $n;
                    $employed -= $n;

			if($landValue->[$x][$y] <= 0) {
			    $land->[$x][$y] = $HlandPlains;
			    $landValue->[$x][$y] = 0;
			}

                }
            }

            logUnemployedMigrate2($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, $migrate2);
        }
    }   elsif(($island->{'riz'} > 0) && (rand(20) > $s06) && (rand(500+$s06) < 20)) {

        my(@order) = randomArray($HislandNumber);
        my($migrate);

        # ��̱���õ��
        my($tIsland);
        my($n) = min($HislandNumber, 5);
        my($i);
        for($i = 0; $i < $n; $i++) { # ����ޤ�Ĵ�٤�
            $tIsland = $Hislands[$order[$i]];

            # �Ż��Τ�����˰�̱����
            if (($island->{'pop'} > $tIsland->{'pop'}) &&($island->{'id'} != $tIsland->{'id'})) {
                $migrate = (25 - $s06 + 1) * (random(3) + 1);
		        if ($migrate <= 0) {
			    $migrate = 1;
		        }
		$migrate2 = $migrate;
                last;
            }
        }

        if ($i >= $n) {

        } else {
            # ��̱�褬���Ĥ��ä��Τǰ�̱
            my($tLand) = $tIsland->{'land'};
            my($tLandValue) = $tIsland->{'landValue'};
            my($employed) = $migrate;
            my($sekiflag) = 0;

            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $tLand->[$x][$y];
                $lv = $tLandValue->[$x][$y];

	        if($landKind == $HlandSeki) {
                    logUnemployedReturn2($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, $migrate2);
                    $sekiflag++;
		    $migrate = 0;
		}

	    }

            # ��̱���Į�˲Ȥ��Ѱդ���
            my($employed) = $migrate;
            my($x, $y, $landKind, $lv);
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $tLand->[$x][$y];
                $lv = $tLandValue->[$x][$y];

                if(($landKind == $HlandTown) ||
		  ($landKind == $HlandMinato) ||
		  ($landKind == $HlandProcity) ||
		  ($landKind == $HlandFrocity) ||
		  ($landKind == $HlandNewtown) ||
		  ($landKind == $HlandBigtown) ||
		  ($landKind == $HlandBettown) ||
		  ($landKind == $HlandSeatown) ||
		  ($landKind == $HlandOnsen) ||
		  ($landKind == $HlandSeacity)) {
                    # Į
                    $n = int((2000 - $lv) / 2);
                    $n = min(int($n + rand($n)), $employed);
                    $employed -= $n;
                    $tLandValue->[$x][$y] += $n;
                } elsif ($landKind == $HlandPlains) {
                    # ʿ��
                    $n = int((255 - $lv) / 2);
                    $n = min(int($n + rand($n)), $employed);
                    $employed -= $n;
                    $tLand->[$x][$y] = $HlandTown;
                    $tLandValue->[$x][$y] = $n;
                }

                last if ($employed <= 0);
            }
            $migrate -= $employed;
            $island->{'pop'} -= $migrate;
            $tIsland->{'pop'} += $migrate;

            # ���ޤǽ���Ǥ����Ȥ��ʬ����
            $employed = $migrate;
            for($i = 0; $i < $HpointNumber; $i++) {
                $x = $Hrpx[$i];
                $y = $Hrpy[$i];
                $landKind = $land->[$x][$y];
                $lv = $landValue->[$x][$y];

                if((($landKind == $HlandRizort) && ($lv > 1)) ||
		  (($landKind == $HlandBigRizort) && ($lv > 1)) ||
		  (($landKind == $HlandKajino) && ($lv > 1))) {
                    # Į
                    $n = min($lv - 1, $employed);
                    $landValue->[$x][$y] -= $n;
                    $employed -= $n;

			if($landValue->[$x][$y] <= 0) {
			    $land->[$x][$y] = $HlandPlains;
			    $landValue->[$x][$y] = 0;
			}

                }
            }

	        if($sekiflag == 0) {
		    logUnemployedMigrate3($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, $migrate2);
		}

        }
    }


    # �Ͽ�Ƚ��
    if(random(1000) < (($island->{'prepare2'} + 1) * $HdisEarthquake)-int($island->{'eis2'}/15)-int($s04/10)) {
	# �Ͽ�ȯ��
	logEarthquake($id, $name);

    if($toto2 > 0) {
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
    } else {

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    $lv = $landValue->[$x][$y];

	    if((($landKind == $HlandTown) && ($lv >= 100)) ||
	       (($landKind == $HlandFoodim) && ($lv < 480)) ||
	       (($landKind == $HlandProcity) && ($lv < 130)) ||
	       ($landKind == $HlandHaribote) ||
               ($landKind == $HlandPark) ||
	       ($landKind == $HlandMinato) ||
	       ($landKind == $HlandOnsen) ||
               ($landKind == $HlandKyujo) ||
               ($landKind == $HlandKyujokai) ||
	       ($landKind == $HlandFactory)) {
		# 1/4�ǲ���
		if(random(4+$island->{'co5'}*5) == 0) {
		    logEQDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
				if ($kind == $HlandOnsen) {
                        	# �⻳�ϻ������
                        	$land->[$x][$y] = $HlandMountain; # ���ˤʤ�
                        	$landValue->[$x][$y] = 0;
                    		}
		}
	    }
	    if((($landKind == $HlandBigtown) && ($lv >= 100)) ||
	       (($landKind == $HlandBettown) && ($lv >= 100)) ||
	       (($landKind == $HlandSkycity) && ($lv >= 100)) ||
	       (($landKind == $HlandShuto) && ($lv >= 100)) ||
	       (($landKind == $HlandUmishuto) && ($lv >= 100)) ||
	       (($landKind == $HlandRizort) && ($lv >= 10)) ||
	       (($landKind == $HlandKajino) && ($lv >= 10)) ||
	       (($landKind == $HlandBigRizort) && ($lv >= 10)) ||
	       (($landKind == $HlandHTFactory) && ($lv >= 10)) ||
	       (($landKind == $HlandSHTF) && ($lv >= 10)) ||
	       (($landKind == $HlandNewtown) && ($lv >= 100))) {
		# 1/4�ǲ���
		if(random(3+$island->{'co5'}*5) == 0) {
		    logEQDamagenot($id, $name, landName($landKind, $lv),
				"($x, $y)");
	            $landValue->[$x][$y] -= random(100)+50;
		}
			if($landValue->[$x][$y] <= 0) {
			    # ʿ�Ϥ��᤹
			    $land->[$x][$y] = $HlandWaste;
			    $landValue->[$x][$y] = 0;
		    	    logEQDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
			    next;
			}
	    }
	    if(($landKind == $HlandFarmchi) ||
               ($landKind == $HlandFarmpic) ||
	       ($landKind == $HlandFarmcow)) {
		if(random(6) == 0) {
		    logEQDamagenot($id, $name, landName($landKind, $lv),
				"($x, $y)");
	            $landValue->[$x][$y] -= random(400)+50;
		}
		if($landValue->[$x][$y] <= 0) {
		    # ʿ�Ϥ��᤹
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		        logEQDamage($id, $name, landName($landKind, $lv),
			"($x, $y)");
		    next;
		}
	    }
	}
    }
    }



    # ���Ǥˤ���뽻̱
    if(random(100) < $island->{'eisei1'}-10-random(5)) {
	# ��­��å�����
	logKire($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    $lv = $landValue->[$x][$y];

	    if(($landKind == $HlandFarm) ||
               ($landKind == $HlandCollege) ||
               ($landKind == $HlandYakusho) ||
	       ($landKind == $HlandFactory) ||
	       ($landKind == $HlandSHTF) ||
	       ($landKind == $HlandOWNF) ||
	       ($landKind == $HlandHTFactory) ||
               ($landKind == $HlandNursery) ||
               ($landKind == $HlandEneAt) ||
               ($landKind == $HlandEneFw) ||
               ($landKind == $HlandEneWt) ||
               ($landKind == $HlandEneWd) ||
               ($landKind == $HlandEneBo) ||
               ($landKind == $HlandEneSo) ||
               ($landKind == $HlandEneCs) ||
	       ($landKind == $HlandBase) ||
	       ($landKind == $HlandPark) ||
	       ($landKind == $HlandKyujo) ||
	       ($landKind == $HlandKyujokai) ||
	       ($landKind == $HlandZoo) ||
	       ($landKind == $HlandHouse) ||
	       ($landKind == $HlandTaishi) ||
	       ($landKind == $HlandTrain) ||
	       ($landKind == $HlandKura) ||
	       ($landKind == $HlandKuraf) ||
	       ($landKind == $HlandDefence)) {
		# 1/4�ǲ���
		if(random(100) < $island->{'eisei1'}) {
		    logKireDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
                    # �Ǥ��ܿ���ʤ�����
                    if($landKind == $HlandNursery) {
                        $land->[$x][$y] = $HlandSea;
                        $landValue->[$x][$y] = 1;
                    }
		}
	    }
	    if(($landKind == $HlandTown) ||
               ($landKind == $HlandMinato) ||
	       ($landKind == $HlandFoodim) ||
               ($landKind == $HlandProcity) ||
	       ($landKind == $HlandFarmchi) ||
	       ($landKind == $HlandFarmpic) ||
	       ($landKind == $HlandFarmcow)) {
		# 1/4�ǲ���
		if(random(100) < $island->{'eisei1'}-30) {
		    logKireDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		}
	    }
	    if(($landKind == $HlandSbase) ||
	       ($landKind == $HlandSeacity) ||
	       ($landKind == $HlandUmiamu) ||
	       ($landKind == $HlandFrocity)) {
		# 1/4�ǲ���
		if(random(100) < $island->{'eisei1'}-60) {
		    logKireDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		}
	    }

	}
    }



    # ������­
    if($island->{'food'} <= 0) {
	# ��­��å�����
	logStarve($id, $name);
	$island->{'food'} = 0;


    if($island->{'eis7'} >= 1) {
	$eis7 = $island->{'eis7'};
	    $cstpop = int($eis7/100);
	    $csten = $eis7%100;
	    $tdmg = random(1000);
	    $cstpop = int($cstpop*$tdmg/1000);
           $island->{'eis7'} = $cstpop*100+$csten;
			if($cstpop < $tdmg) {
			$island->{'eis7'} = 0;
			logEiseiEndNopop($id, $name, "���襹�ơ������");
			}

	}


	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    $lv = $landValue->[$x][$y];

	    if(($landKind == $HlandFarm) ||
	       ($landKind == $HlandFoodim) ||
	       ($landKind == $HlandFoodka) ||
               ($landKind == $HlandFarmchi) ||
               ($landKind == $HlandFarmpic) ||
               ($landKind == $HlandFarmcow) ||
               ($landKind == $HlandCollege) ||
               ($landKind == $HlandYakusho) ||
	       ($landKind == $HlandFactory) ||
	       ($landKind == $HlandHTFactory) ||
	       ($landKind == $HlandSHTF) ||
	       ($landKind == $HlandOWNF) ||
               ($landKind == $HlandNursery) ||
	       ($landKind == $HlandBase) ||
               ($landKind == $HlandMine) ||
               ($landKind == $HlandKura) ||
	       ($landKind == $HlandKuraf) ||
	       ($landKind == $HlandDefence)) {
		# 1/4�ǲ���
		if(random(4) == 0) {
		    logSvDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
                    # �Ǥ��ܿ���ʤ�����
                    if($landKind == $HlandNursery) {
                        $land->[$x][$y] = $HlandSea;
                        $landValue->[$x][$y] = 1;
                    }
		}
	    }
	}
    }

    # ����Ƚ��
    if(random(1000) < $HdisTsunami-int($island->{'eis2'}/15)-int($s04/10)) {
	# ����ȯ��
	logTsunami($id, $name);

    if($toto2 > 0) {
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
    } else {

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    $lv = $landValue->[$x][$y];

	    if(($landKind == $HlandTown) ||
	       (($landKind == $HlandProcity) && ($lv < 110)) ||
	       ($landKind == $HlandFarm) ||
	       ($landKind == $HlandFarmchi) ||
	       ($landKind == $HlandFarmpic) ||
	       ($landKind == $HlandFarmcow) ||
	       ($landKind == $HlandEneAt) ||
	       ($landKind == $HlandEneFw) ||
	       ($landKind == $HlandEneWt) ||
	       ($landKind == $HlandEneWd) ||
	       ($landKind == $HlandEneBo) ||
	       ($landKind == $HlandEneSo) ||
	       ($landKind == $HlandEneCs) ||
	       ($landKind == $HlandConden) ||
	       ($landKind == $HlandConden2) ||
	       ($landKind == $HlandConden3) ||
	       ($landKind == $HlandConden4) ||
	       ($landKind == $HlandTrain) ||
	       ($landKind == $HlandCollege) ||
	       ($landKind == $HlandYakusho) ||
	       ($landKind == $HlandFoodim) ||
	       ($landKind == $HlandFoodka) ||
	       ($landKind == $HlandFactory) ||
	       ($landKind == $HlandHTFactory) ||
	       ($landKind == $HlandSHTF) ||
	       ($landKind == $HlandOWNF) ||
	       ($landKind == $HlandBase) ||
	       ($landKind == $HlandDefence) ||
               ($landKind == $HlandPark) ||
	       ($landKind == $HlandMinato) ||
	       ($landKind == $HlandFune) ||
	       ($landKind == $HlandSeki) ||
               ($landKind == $HlandMine) ||
               ($landKind == $HlandNursery) ||
               ($landKind == $HlandKyujo) ||
               ($landKind == $HlandKyujokai) ||
               ($landKind == $HlandZoo) ||
               ($landKind == $HlandNewtown) ||
               ($landKind == $HlandBigtown) ||
               ($landKind == $HlandBettown) ||
               ($landKind == $HlandRizort) ||
               ($landKind == $HlandKajino) ||
               ($landKind == $HlandUmicity) ||
               ($landKind == $HlandBigRizort) ||
               ($landKind == $HlandShuto) ||
               ($landKind == $HlandKura) ||
	       ($landKind == $HlandKuraf) ||
	       ($landKind == $HlandHaribote)) {
		# 1d12 <= (���Ϥγ� - 1) ������
		if(random(12+$island->{'co5'}*5) <
		   (countAround($land, $x, $y, $HlandOil, 7) +
		    countAround($land, $x, $y, $HlandSbase, 7) +
		    countAround($land, $x, $y, $HlandSeacity, 7) +
		    countAround($land, $x, $y, $HlandSeatown, 7) +
		    countAround($land, $x, $y, $HlandUmishuto, 7) +
		    countAround($land, $x, $y, $HlandFune, 7) +
		    countAround($land, $x, $y, $HlandFrocity, 7) +
		    countAround($land, $x, $y, $HlandUmiamu, 7) +
		    countAround($land, $x, $y, $HlandSea, 7) - 1)) {
		    logTsunamiDamage($id, $name, landName($landKind, $lv),
				     "($x, $y)");
		    if($landKind == $HlandFune) {
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
                    # �Ǥ��ܿ���ʤ�����
                    } elsif($landKind == $HlandNursery) {
                        $land->[$x][$y] = $HlandSea;
                        $landValue->[$x][$y] = 1;
		    } else {
		    $land->[$x][$y] = $HlandWaste;
		    $landValue->[$x][$y] = 0;
		    }
		}
	    }
	}
    }
    }

    # ����Ƚ��
    my($r) = random(10000);
    my($pop) = $island->{'pop'};
    do{
	if((($r < ($HdisMonster * $island->{'area'})) &&
	    ($pop >= $HdisMonsBorder1)) ||
	   ($island->{'monstersend'} > 0)) {
	    # ���ýи�
	    # ��������
	    my($lv, $kind);
	    if($island->{'monstersend'} > 0) {
		# ��¤
		$kind = $island->{'monstersendkind'};
		$island->{'monstersend'}--;
	    } elsif($pop >= $HdisMonsBorder4) {
		# level4�ޤ�
		$kind = random($HmonsterLevel4) + 1;
	    } elsif($pop >= $HdisMonsBorder3) {
		# level3�ޤ�
		$kind = random($HmonsterLevel3) + 1;
	    } elsif($pop >= $HdisMonsBorder2) {
		# level2�ޤ�
		$kind = random($HmonsterLevel2) + 1;
	    } else {
		# level1�Τ�
		$kind = random($HmonsterLevel1) + 1;
	    }

	    # lv���ͤ����
	    $lv = ($kind << 4)
		+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);

	    # �ɤ��˸���뤫����
	    my($bx, $by, $i);
	    for($i = 0; $i < $HpointNumber; $i++) {
		$bx = $Hrpx[$i];
		$by = $Hrpy[$i];
		if(($land->[$bx][$by] == $HlandTown) ||
		   ($land->[$bx][$by] == $HlandBigtown) ||
		   ($land->[$bx][$by] == $HlandBettown) ||
		   ($land->[$bx][$by] == $HlandSkycity) ||
		   ($land->[$bx][$by] == $HlandUmicity) ||
		   ($land->[$bx][$by] == $HlandRizort) ||
		   ($land->[$bx][$by] == $HlandKajino) ||
		   ($land->[$bx][$by] == $HlandBigRizort) ||
		   ($land->[$bx][$by] == $HlandNewtown)) {

		    # �Ϸ�̾
		    my($lName) = landName($HlandTown, $landValue->[$bx][$by]);

		    # ���Υإå�������ä�
		    $land->[$bx][$by] = $HlandMonster;
		    $landValue->[$bx][$by] = $lv;

		    # ���þ���
		    my($mKind, $mName, $mHp) = monsterSpec($lv);

		    # ��å�����
		    logMonsCome($id, $name, $mName, "($bx, $by)", $lName);
		    last;
		}
	    }
	}
    } while($island->{'monstersend'} > 0);

    # ��������Ƚ��
    if(($island->{'area'} > $HdisFallBorder) &&
       (random(1000) < $HdisFalldown)) {
	# ��������ȯ��
	logFalldown($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    $lv = $landValue->[$x][$y];

	    if(($landKind != $HlandSea) &&
	       ($landKind != $HlandIce) &&
	       ($landKind != $HlandSbase) &&
	       ($landKind != $HlandSeacity) &&
	       ($landKind != $HlandSeatown) &&
	       ($landKind != $HlandUmishuto) &&
	       ($landKind != $HlandFune) &&
	       ($landKind != $HlandUmiamu) &&
	       ($landKind != $HlandOil) &&
	       ($landKind != $HlandGold) &&
	       ($landKind != $HlandOnsen) &&
	       ($landKind != $HlandMountain)) {

		# ���Ϥ˳�������С��ͤ�-1��
		if(countAround($land, $x, $y, $HlandSea, 7) + 
		   countAround($land, $x, $y, $HlandSeacity, 7) + 
		   countAround($land, $x, $y, $HlandSeatown, 7) + 
		   countAround($land, $x, $y, $HlandUmishuto, 7) + 
		   countAround($land, $x, $y, $HlandFune, 7) + 
		   countAround($land, $x, $y, $HlandUmiamu, 7) +
		   countAround($land, $x, $y, $HlandSbase, 7)) {
		    logFalldownLand($id, $name, landName($landKind, $lv),
				"($x, $y)");
		    $land->[$x][$y] = -1;
		    $landValue->[$x][$y] = 0;
		}
	    }
	}

	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];

	    if($landKind == -1) {
		# -1�ˤʤäƤ�����������
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 1;
	    } elsif ($landKind == $HlandSea) {
		# �����ϳ���
		$landValue->[$x][$y] = 0;
	    }

	}
    }

    # ����Ƚ��
    if(random(1000) < $HdisTyphoon-int($island->{'eis1'}/10)) {
	# ����ȯ��
	logTyphoon($id, $name);
	$island->{'Typhoonflag'} = 1;

    if($toto2 > 0) {
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
    } else {

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    $lv = $landValue->[$x][$y];

	    if(($landKind == $HlandFarm) ||
	       ($landKind == $HlandEneWd) ||
	       ($landKind == $HlandHaribote)) {

		# 1d12 <= (6 - ���Ϥο�) ������
		if(random(12+$island->{'co5'}*5) < 
		   (6
		    - countAround($land, $x, $y, $HlandForest, 7)
		    - countAround($land, $x, $y, $HlandMonument, 7))) {
		    logTyphoonDamage($id, $name, landName($landKind, $lv),
				     "($x, $y)");
		    $land->[$x][$y] = $HlandPlains;
		    $landValue->[$x][$y] = 0;
		}
	    }

	    if(($landKind == $HlandFune) ||
	       ($landKind == $HlandNursery)) {

		if(random(100+$island->{'co5'}*50) < 10) {
		    logTyphoonHason($id, $name, landName($landKind, $lv),
				     "($x, $y)");
                        $land->[$x][$y] = $HlandSea;
                        $landValue->[$x][$y] = 1;
		}
	    }

	}
    }
    }

    # �������Ƚ��
    if(random(1000) < $HdisHugeMeteo-int($island->{'eis3'}/50)-int($s04/10)) {
	my($x, $y, $landKind, $lv, $point);

	# �
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";

	# ��å�����
	logHugeMeteo($id, $name, $point);

    if($island->{'h10'} >= 1) {
	logOmamori2($id, $name);
	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = 0;
    } elsif($toto2 > 1) {
	$toto2--;
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = 0;
    } else {

	# �����ﳲ�롼����
	wideDamage($id, $name, $land, $landValue, $x, $y);
		                if (rand(1000) < 100) {
		                    $land->[$x][$y] = $HlandMonument;
		                    $landValue->[$x][$y] = 79;
		                }
    }
    }

    # ����ߥ�����Ƚ��
    while($island->{'bigmissile'} > 0) {
	$island->{'bigmissile'} --;

	my($x, $y, $landKind, $lv, $point);

	# �
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";

	# ��å�����
	logMonDamage($id, $name, $point);

	# �����ﳲ�롼����
	wideDamage($id, $name, $land, $landValue, $x, $y);
    }

    # ���Ƚ��
    if(random(1000) < $HdisMeteo-int($island->{'eis3'}/40)-int($s04/10)) {

    if($island->{'h10'} >= 1) {
	# �
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";
	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = 0;
	# ��å�����
	logHugeMeteo4($id, $name, $point);
	logOmamori2($id, $name);
    } elsif($toto2 > 0) {
	# �
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";
	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = 0;
	# ��å�����
	logHugeMeteo4($id, $name, $point);
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
    } else {

	my($x, $y, $landKind, $lv, $point, $first);
	$first = 1;
	while((random(2) == 0) || ($first == 1)) {
	    $first = 0;
	    
	    # �
	    $x = random($HislandSize);
	    $y = random($HislandSize);
	    $landKind = $land->[$x][$y];
	    $lv = $landValue->[$x][$y];
	    $point = "($x, $y)";



	    my($i, $count, $sx, $sy);
	    $count = 0;
	    for($i = 0; $i < 19; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # �Ԥˤ�����Ĵ��
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
		     $sx--;
		 }

		 if(($sx < 0) || ($sx >= $HislandSize) ||
		    ($sy < 0) || ($sy >= $HislandSize)) {
		     # �ϰϳ��ξ��
		     if($kind == $HlandSea) {
			 # ���ʤ�û�
			 $count++;
		     }
		 } else {
		     # �ϰ���ξ��
		     if(($land->[$sx][$sy] == $HlandDefence) && ($landValue->[$sx][$sy] == 77)) {
		                if (rand(100) < 30) {
		                $land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
				logTrainEnd2($id, $name, "�ɱһ��ߡ���", "($sx, $sy)");
		                }
			 $count++;
		     }
		 }
	    }

	        if(($count > 0) && ($island->{'eis5'} >= 1)) {

		logMidMeteo3($id, $name, $point);
		$island->{'roudenflag'}++;
		$island->{'eis5'} -= random(50);
		        if($island->{'eis5'} < 1) {
		           $island->{'eis5'} = 0;
				logEiseiEnd($id, $name, "�ɱұ���");
		        }

		} else {

		    if(($landKind == $HlandSea) && ($lv == 0)){
			# ���ݥ���
			logMeteoSea($id, $name, landName($landKind, $lv),
				    $point);
		    } elsif($landKind == $HlandMountain) {
			# ���˲�
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			next;
		    } elsif($landKind == $HlandGold) {
			# ���˲�
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			next;
		    } elsif($landKind == $HlandOnsen) {
			# ���˲�
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			next;
		    } elsif($landKind == $HlandSbase) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandSeacity) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandUmishuto) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandSeatown) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandFune) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandFrocity) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandUmiamu) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				      $point);
		    } elsif($landKind == $HlandMonster) {
			logMeteoMonster($id, $name, landName($landKind, $lv),
					$point);
		    } elsif($landKind == $HlandSea) {
			# ����
			logMeteoSea1($id, $name, landName($landKind, $lv),
				     $point);
		    } elsif($landKind == $HlandIce) {
			# ����
			logMeteoSea1($id, $name, landName($landKind, $lv),
				     $point);
		    } else {
			logMeteoNormal($id, $name, landName($landKind, $lv),
				       $point);
		    }
		    $land->[$x][$y] = $HlandSea;
		    $landValue->[$x][$y] = 0;
		                if (rand(1000) < 50) {
		                    $land->[$x][$y] = $HlandMonument;
		                    $landValue->[$x][$y] = 79;
		                }
		    }
	    }
        }
    }

    # ʮ��Ƚ��
    if(random(1000) < $HdisEruption-int($island->{'eis2'}/40)-int($s04/10)) {
	my($x, $y, $sx, $sy, $i, $landKind, $lv, $point);
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";
	logEruption($id, $name, landName($landKind, $lv),
		    $point);
	$land->[$x][$y] = $HlandMountain;
	$landValue->[$x][$y] = 0;

        if($toto2 > 1) {
	$toto2--;
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
        } else {

		                if (rand(1000) < 50) {
		                    $land->[$x][$y] = $HlandMonument;
		                    $landValue->[$x][$y] = 78;
		                }
		                if (rand(1000) < 100) {
		                    $land->[$x][$y] = $HlandMonument;
		                    $landValue->[$x][$y] = 75;
		                }
	for($i = 1; $i < 7; $i++) {
	    $sx = $x + $ax[$i];
	    $sy = $y + $ay[$i];

	    # �Ԥˤ�����Ĵ��
	    if((($sy % 2) == 0) && (($y % 2) == 1)) {
		$sx--;
	    }

	    $landKind = $land->[$sx][$sy];
	    $lv = $landValue->[$sx][$sy];
	    $point = "($sx, $sy)";

	    if(($sx < 0) || ($sx >= $HislandSize) ||
	       ($sy < 0) || ($sy >= $HislandSize)) {
	    } else {
		# �ϰ���ξ��
		$landKind = $land->[$sx][$sy];
		$lv = $landValue->[$sx][$sy];
		$point = "($sx, $sy)";
		if(($landKind == $HlandSea) ||
		   ($landKind == $HlandIce) ||
		   ($landKind == $HlandOil) ||
		   ($landKind == $HlandFune) ||
		   ($landKind == $HlandFrocity) ||
		   ($landKind == $HlandUmiamu) ||
		   ($landKind == $HlandSeacity) ||
		   ($landKind == $HlandSeatown) ||
		   ($landKind == $HlandUmishuto) ||
		   ($landKind == $HlandSbase)) {
		    # ���ξ��
		    if(($lv == 1) ||
		       ($landKind == $HlandIce)) {
			# ����
			logEruptionSea1($id, $name, landName($landKind, $lv),
					$point);
		    } else {
			logEruptionSea($id, $name, landName($landKind, $lv),
				       $point);
			$land->[$sx][$sy] = $HlandSea;
			$landValue->[$sx][$sy] = 1;
			next;
		    }
		} elsif(($landKind == $HlandMountain) ||
			($landKind == $HlandMonster) ||
			($landKind == $HlandGold) ||
			($landKind == $HlandOnsen) ||
			($landKind == $HlandWaste)) {
		    next;
		} else {
		    # ����ʳ��ξ��
		    logEruptionNormal($id, $name, landName($landKind, $lv),
				      $point);
		}
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
		                if (rand(1000) < 50) {
		                    $land->[$sx][$sy] = $HlandMonument;
		                    $landValue->[$sx][$sy] = 75;
		                }
	    }
	}
    }
    }

    if($island->{'eis1'} >= 1) {
       $island->{'eis1'} -= random(2);
        if($island->{'eis1'} < 1) {
           $island->{'eis1'} = 0;
		logEiseiEnd($id, $name, "���ݱ���");
        }
    }
    if($island->{'eis2'} >= 1) {
       $island->{'eis2'} -= random(2);
        if($island->{'eis2'} < 1) {
           $island->{'eis2'} = 0;
		logEiseiEnd($id, $name, "��¬����");
        }
    }
    if($island->{'eis3'} >= 1) {
       $island->{'eis3'} -= random(2);
        if($island->{'eis3'} < 1) {
           $island->{'eis3'} = 0;
		logEiseiEnd($id, $name, "�޷����");
        }
    }
    if($island->{'eis4'} >= 1) {
       $island->{'eis4'} -= random(2);
        if($island->{'eis4'} < 1) {
           $island->{'eis4'} = 0;
		logEiseiEnd($id, $name, "��������");
        }
    }
    if($island->{'eis5'} >= 1) {
       $island->{'eis5'} -= random(2);
        if($island->{'eis5'} < 1) {
           $island->{'eis5'} = 0;
		logEiseiEnd($id, $name, "�ɱұ���");
        }
    }
    if($island->{'eis6'} >= 1) {
	    my($i,$sx,$sy);
	    for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster){
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		$point = int($island->{'rena'}/1000);

	    logIreAttackt($id, $name, "���쥮��顼", $point, $tName, "($sx, $sy)");

	    $island->{'eis6'} -= 10;

	    $tHp -= int($island->{'rena'}/1000);
	    $tlv -= int($island->{'rena'}/1000);
		$landValue->[$sx][$sy] = $tlv;
	    if($tHp < 1){
	    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	    # �󾩶�
		my($value) = $HmonsterValue[$tKind];
		   $island->{'money'} += $value;
		   logMsMonMoney($id, $tName, $value);
		}
	    next;
	    }
	}

       $island->{'eis6'} -= random(2);
        if($island->{'eis6'} < 1) {
           $island->{'eis6'} = 0;
		logEiseiEnd($id, $name, "���쥮��顼");
        }
    }

    if($island->{'eis7'} >= 1) {
	$eis7 = $island->{'eis7'};
	    $cstpop = int($eis7/100);
	    $csten = $eis7%100;

	    if($island->{'m17'} < int($cstpop/10000)+1) {
		logNoRokeCst($id, $name, $comName, $point);
		$cstpop -= 1000;
	    } else {
		$island->{'money'} -= $cstpop;
	    }

           $island->{'eis7'} = $cstpop*100+$csten;

        if($cstpop < 1) {
           $island->{'eis7'} = 0;
		logEiseiEndNopop($id, $name, "���襹�ơ������");
        }
        if($csten < 1) {
           $island->{'eis7'} = 0;
		logEiseiEnd($id, $name, "���襹�ơ������");
        }
    }

    if(($island->{'h11'} >= 1) && ($island->{'shouhi'} < $island->{'ene'})) {
	    my($i,$sx,$sy);
	    for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	    if($land->[$sx][$sy] == $HlandMonster){
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		$point = int($island->{'rena'}/1000);
		$island->{'shouhi'} += random(20000);
		logFuneAttackSSS3($id, $name, "ŷ����", $point, $tName, "($sx, $sy)");

	    # �оݤβ��ä��ݤ�ƹ��Ϥˤʤ�
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 1;
            }
        }
    }


    $auc4 = $island->{'auc4'};
    $auc4 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
    ($auc4a, $auc4b, $auc4c) = ($1, $2, $3);

    if((($HislandTurn % $HturnPrizeUnit) == 0) || ($auc4b == $aucshouhin)) {

	$hcturn = int($HislandTurn/100)*100;

	$auc9 = $island->{'auc9'};
	$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
	$auc9c2 = int($auc9c/10000);
	$auc9c3 = int($auc9c/10000)*10000;

	$auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);


	$auc6 = $island->{'auc6'};
	$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
	    if($auc6a > 2) {
		$auc6a--;
		$island->{'auc6'} = "$auc6a,$auc6x,$auc6y";
	    }

	if(($island->{'auc1'} == $topvalue1) && ($topvalue1 != 0) && ($island->{'money'}+$auc9c3 < $topvalue1*10000) && ($auc4b != $aucshouhin)) {
	    $island->{'auc6'} = "7,0,0";
	}

	if(($island->{'auc1'} == $topvalue1) && ($topvalue1 != 0) && ($island->{'money'}+$auc9c3 > $topvalue1*10000) && ($auc4b != $aucshouhin)) {

	    $shouhiauc9 = $auc9c2 - $topvalue1;

	    if($shouhiauc9 < 0) {
		$island->{'money'} -= ($topvalue1-$auc9c2)*10000;
		$auc9c2 = 0;
		$auc9c = $auc9c%10000;
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	    } else {
		$auc9c -= $topvalue1*10000;
		$auc9c2 = int($auc9c/10000);
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	    }

	    if($shuppin1 != 30) {
		$auc6 = $island->{'auc6'};
		$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
		($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
		$auc6a = 1;
		$island->{'auc6'} = "$auc6a,$auc6x,$auc6y";
	    }


	    $aucflag1 += $topvalue1;

	    $auc0 = $island->{'auc0'};
	    $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
	    if($topvalue1 > $auc0c) {
	    $island->{'auc0'} = "$shuppin1,$avalue1,$topvalue1,$hcturn,$auc0e";
	    }

	    if($shuppin1 == 0) {
		    $ac = '����';
		} elsif($shuppin1 == 1) {
		    $ac = '����';
		} elsif($shuppin1 == 2) {
		    $ac = 'ɹ��';
		} elsif($shuppin1 == 3) {
		    $ac = '����';
		} elsif($shuppin1 == 4) {
		    $ac = '����';
		} elsif($shuppin1 == 5) {
		    $ac = '����';
		} elsif($shuppin1 == 6) {
		    $ac = 'ŷ�ȥߥ�����';
		} elsif($shuppin1 == 7) {
		    $ac = '�������������ԥ���';
		} elsif($shuppin1 == 8) {
		    $ac = '���饤��쥸�����';
		} elsif($shuppin1 == 9) {
		    $ac = "�����$avalue1��";
		} elsif($shuppin1 == 10) {
		    $avalue1s = $avalue1 * 1000;
		    $ac = "�����ߤ�$avalue1s�͵���";
		} elsif($shuppin1 == 11) {
		    $avalue1s = $avalue1 * 1000;
		    $ac = "����$avalue1s�͵���";
		} elsif($shuppin1 == 12) {
		    $ac = "������$avalue1�����";
		} elsif($shuppin1 == 13) {
		    $ac = '����';
		} elsif($shuppin1 == 14) {
		    $ac = '��������';
		} elsif($shuppin1 == 15) {
		    $ac = '���襹�ơ������';
		} elsif($shuppin1 == 16) {
		    $ac = '����Υ���ǥ�';
		} elsif($shuppin1 == 17) {
		    $avalue1s = $avalue1 * 1000;
		    $ac = "�⻳$avalue1s�͵���";
		} elsif($shuppin1 == 18) {
		    $avalue1s = $avalue1 * 1000;
		    $ac = "�ܿ���$avalue1s�͵���";
		} elsif($shuppin1 == 19) {
		    $ac = '��¤����f02';
		} elsif($shuppin1 == 20) {
		    $ac = '�Ⲧ������';
		} elsif($shuppin1 == 21) {
		    $ac = 'unknown';
		} elsif($shuppin1 == 22) {
		    $ac = "���å�����������1.$avalue1��";
		} elsif($shuppin1 == 23) {
		    $ac = "��ʪ���ǽ��1.$avalue1��";
		} elsif($shuppin1 == 24) {
		    $ac = "��ʪ��طи���$avalue1";
		} elsif($shuppin1 == 25) {
		    $ac = '��';
		} elsif($shuppin1 == 26) {
		    $ac = '��ʪ���';
		} elsif($shuppin1 == 27) {
		    $ac = "����$avalue1�����";
		} elsif($shuppin1 == 28) {
		    $ac = "�Х����ޥ�$avalue1�����";
		} elsif($shuppin1 == 29) {
		    $ac = '����Ϥ��٤�';
		} elsif($shuppin1 == 30) {
		    my($island, $j, $name, $id, $ii);
		    for($ii = 0; $ii < $HislandNumber; $ii++) {
			$j = $ii + 1;
			$island = $Hislands[$ii];
			$id = $island->{'id'};
				if($avalue1 == $island->{'id'}) {
				    $dashiname = $island->{'auc7'};
				}
			}
		    $ac = "$dashiname";
		} else {
		    $ac = '��';
		}

	    if(($shuppin1 == 6) || ($shuppin1 == 7) || ($shuppin1 == 8) || ($shuppin1 == 19) || ($shuppin1 == 20) || ($shuppin1 == 21)) {

		my($i,$sx,$sy);
		my($zlv) = (0);
		for($i = 0; $i < $HpointNumber; $i++){
		    $sx = $Hrpx[$i];
		    $sy = $Hrpy[$i];
			if($land->[$sx][$sy] == $HlandZoo){
			    $zlv += $landValue->[$sx][$sy];
			}
		}

		$etc6 = $island->{'etc6'};
		$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

			if(($zlv > $zookazu) && ($island->{'zoo'} > 0)) {

				if($shuppin1 == 6) {
				    $ack = 13;
				} elsif($shuppin1 == 7) {
				    $ack = 22;
				} elsif($shuppin1 == 8) {
				    $ack = 14;
				} elsif($shuppin1 == 19) {
				    $ack = 17;
				} elsif($shuppin1 == 20) {
				    $ack = 21;
				} elsif($shuppin1 == 21) {
				    $ack = 23;
				}

				logMonsCome2($id, $name, $ac, $topvalue1);
				$z->{"$ack"}++;
				$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

			}

		} elsif($shuppin1 == 9) {

		    $etc8 = $island->{'etc8'};
		    $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
		    $toto2 += $avalue1;
		    $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

		    logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 14) {

		    $island->{'eis1'} = 200;
		    $island->{'eis2'} = 200;
		    $island->{'eis3'} = 200;
		    $island->{'eis4'} = 200;
		    $island->{'eis5'} = 200;
		    $island->{'eis6'} = 200;

		    logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 15) {

		    $island->{'eis7'} = 100099;

		    logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 22) {

		    $eisei4 = $island->{'eisei4'};
		    $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
		    $sto += int($sto * $avalue1 / 10);
		    $std += int($std * $avalue1 / 10);
		    $stk += int($stk * $avalue1 / 10);
		    $island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

		    logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 23) {

		    $eisei5 = $island->{'eisei5'};
		    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		    $msap += int($msap * $avalue1 / 10);
		    $msdp += int($msdp * $avalue1 / 10);
		    $mssp += int($mssp * $avalue1 / 10);
		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

		    logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 24) {

		    $eisei5 = $island->{'eisei5'};
		    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		    $msexe += $avalue1;
		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

		    logMonsCome2($id, $name, $ac, $topvalue1);

		} else {

		    # �ɤ��˸���뤫����
		    my($bx, $by, $i);
		    for($i = 0; $i < $HpointNumber; $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if(($land->[$bx][$by] == $HlandPlains) ||
			   ($land->[$bx][$by] == $HlandPlains2)) {

				if($shuppin1 == 0) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 74;
				} elsif($shuppin1 == 1) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 75;
				} elsif($shuppin1 == 2) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 76;
				} elsif($shuppin1 == 3) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 77;
				} elsif($shuppin1 == 4) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 78;
				} elsif($shuppin1 == 5) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 79;
				} elsif($shuppin1 == 10) {
				    $land->[$bx][$by] = $HlandUmiamu;
				    $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 11) {
				    $land->[$bx][$by] = $HlandFoodim;
				    $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 12) {
				    $land->[$bx][$by] = $HlandEneCs;
				    $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 13) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 74;
				} elsif($shuppin1 == 16) {
				    $land->[$bx][$by] = $HlandConden3;
				    $landValue->[$bx][$by] = 0;
				} elsif($shuppin1 == 17) {
				    $land->[$bx][$by] = $HlandGold;
				    $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 18) {
				    $land->[$bx][$by] = $HlandNursery;
				    $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 25) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 26) {
				    $land->[$bx][$by] = $HlandCollege;
				    $landValue->[$bx][$by] = 4;
				} elsif($shuppin1 == 27) {
				    $land->[$bx][$by] = $HlandEneWd;
				    $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 28) {
				    $land->[$bx][$by] = $HlandEneBo;
				    $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 30) {
				    my($tn) = $HidToNumber{$avalue1};
				    if($tn eq '') {

				    } else {
				    my($tIsland) = $Hislands[$tn];
				    my($tName) = $tIsland->{'name'};
				    my($tLand) = $tIsland->{'land'};
				    my($tLandValue) = $tIsland->{'landValue'};
					$tauc6 = $tIsland->{'auc6'};
					$tauc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc6a, $tauc6x, $tauc6y) = ($1, $2, $3);
					$tIsland->{'auc6'} = "0,0,0";
				    my($tx, $ty);
					$tx = $tauc6x;
					$ty = $tauc6y;
				    my($tL) = $tLand->[$tx][$ty];
				    my($tLv) = $tLandValue->[$tx][$ty];
				    my($tLname) = landName($tL, $tLv);
					$island->{'stocklandkind'} = $tLand->[$tx][$ty];
					$island->{'stocklandvalue'} = $tLandValue->[$tx][$ty];
					$tLand->[$tx][$ty] = $HlandPlains;
					$tLandValue->[$tx][$ty] = 0;
					$land->[$bx][$by] = $island->{'stocklandkind'};
					$landValue->[$bx][$by] = $island->{'stocklandvalue'};

					$tauc9 = $tIsland->{'auc9'};
					$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
					$tauc9c += $topvalue1*10000;
					$tauc9c2 = int($tauc9c/10000);
					$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
					$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";

					$island->{'auc8'} = "$tName����ʤ�$tLname";

					$aucland = $tL * $tLv;

						if($aucland != $topid1) {
							$tIsland->{'auc6'} = "77,0,0";
						}
				    }

				}

			    # ��å�����
			    logMonsCome2($id, $name, $ac, $topvalue1);
			    last;
			}
		    }
		}
	    }


	$auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);

	if(($island->{'auc2'} == $topvalue2) && ($topvalue2 != 0) && ($island->{'money'}+$auc9c3 < $topvalue2*10000) && ($auc4b != $aucshouhin)) {
	    $island->{'auc6'} = "7,0,0";
	}

	if(($island->{'auc2'} == $topvalue2) && ($topvalue2 != 0) && ($island->{'money'}+$auc9c3 > $topvalue2*10000) && ($auc4b != $aucshouhin)) {

	    $shouhiauc9 = $auc9c2 - $topvalue2;

	    if($shouhiauc9 < 0) {
		$island->{'money'} -= ($topvalue2-$auc9c2)*10000;
		$auc9c2 = 0;
		$auc9c = $auc9c%10000;
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	    } else {
		$auc9c -= $topvalue2*10000;
		$auc9c2 = int($auc9c/10000);
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	    }

	    if($shuppin2 != 30) {
		$auc6 = $island->{'auc6'};
		$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
		($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
		$auc6a = 1;
		$island->{'auc6'} = "$auc6a,$auc6x,$auc6y";
	    }

	    $aucflag2 += $topvalue2;

	    $auc0 = $island->{'auc0'};
	    $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	    ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
	    if($topvalue2 > $auc0c) {
	    $island->{'auc0'} = "$shuppin2,$avalue2,$topvalue2,$hcturn,$auc0e";
	    }

	    if($shuppin2 == 0) {
		    $ac = '����';
		} elsif($shuppin2 == 1) {
		    $ac = '����';
		} elsif($shuppin2 == 2) {
		    $ac = 'ɹ��';
		} elsif($shuppin2 == 3) {
		    $ac = '����';
		} elsif($shuppin2 == 4) {
		    $ac = '����';
		} elsif($shuppin2 == 5) {
		    $ac = '����';
		} elsif($shuppin2 == 6) {
		    $ac = 'ŷ�ȥߥ�����';
		} elsif($shuppin2 == 7) {
		    $ac = '�������������ԥ���';
		} elsif($shuppin2 == 8) {
		    $ac = '���饤��쥸�����';
		} elsif($shuppin2 == 9) {
		    $ac = "�����$avalue2��";
		} elsif($shuppin2 == 10) {
		    $avalue2s = $avalue2 * 1000;
		    $ac = "�����ߤ�$avalue2s�͵���";
		} elsif($shuppin2 == 11) {
		    $avalue2s = $avalue2 * 1000;
		    $ac = "����$avalue2s�͵���";
		} elsif($shuppin2 == 12) {
		    $ac = "������$avalue2�����";
		} elsif($shuppin2 == 13) {
		    $ac = '����';
		} elsif($shuppin2 == 14) {
		    $ac = '��������';
		} elsif($shuppin2 == 15) {
		    $ac = '���襹�ơ������';
		} elsif($shuppin2 == 16) {
		    $ac = '����Υ���ǥ�';
		} elsif($shuppin2 == 17) {
		    $avalue2s = $avalue2 * 1000;
		    $ac = "�⻳$avalue2s�͵���";
		} elsif($shuppin2 == 18) {
		    $avalue2s = $avalue2 * 1000;
		    $ac = "�ܿ���$avalue2s�͵���";
		} elsif($shuppin2 == 19) {
		    $ac = '��¤����f02';
		} elsif($shuppin2 == 20) {
		    $ac = '�Ⲧ������';
		} elsif($shuppin2 == 21) {
		    $ac = 'unknown';
		} elsif($shuppin2 == 22) {
		    $ac = "���å�����������1.$avalue2��";
		} elsif($shuppin2 == 23) {
		    $ac = "��ʪ���ǽ��1.$avalue2��";
		} elsif($shuppin2 == 24) {
		    $ac = "��ʪ��طи���$avalue2";
		} elsif($shuppin2 == 25) {
		    $ac = '��';
		} elsif($shuppin2 == 26) {
		    $ac = '��ʪ���';
		} elsif($shuppin2 == 27) {
		    $ac = "����$avalue2�����";
		} elsif($shuppin2 == 28) {
		    $ac = "�Х����ޥ�$avalue2�����";
		} elsif($shuppin2 == 29) {
		    $ac = '����Ϥ��٤�';
		} elsif($shuppin2 == 30) {
		    my($island, $j, $name, $id, $ii);
		    for($ii = 0; $ii < $HislandNumber; $ii++) {
			$j = $ii + 1;
			$island = $Hislands[$ii];
			$id = $island->{'id'};
				if($avalue2 == $island->{'id'}) {
				    $dashiname = $island->{'auc7'};
				}
			}
		    $ac = "$dashiname";
		} else {
		    $ac = '��';
		}

	    if(($shuppin2 == 6) || ($shuppin2 == 7) || ($shuppin2 == 8) || ($shuppin2 == 19) || ($shuppin2 == 20) || ($shuppin2 == 21)) {

		my($i,$sx,$sy);
		my($zlv) = (0);
		for($i = 0; $i < $HpointNumber; $i++){
		    $sx = $Hrpx[$i];
		    $sy = $Hrpy[$i];
			if($land->[$sx][$sy] == $HlandZoo){
			    $zlv += $landValue->[$sx][$sy];
			}
		}

		$etc6 = $island->{'etc6'};
		$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

			if(($zlv > $zookazu) && ($island->{'zoo'} > 0)) {

				if($shuppin2 == 6) {
				    $ack = 13;
				} elsif($shuppin2 == 7) {
				    $ack = 22;
				} elsif($shuppin2 == 8) {
				    $ack = 14;
				} elsif($shuppin2 == 19) {
				    $ack = 17;
				} elsif($shuppin2 == 20) {
				    $ack = 21;
				} elsif($shuppin2 == 21) {
				    $ack = 23;
				}

				logMonsCome2($id, $name, $ac, $topvalue2);
				$z->{"$ack"}++;
				$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

			}

		} elsif($shuppin2 == 9) {

		    $etc8 = $island->{'etc8'};
		    $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
		    $toto2 += $avalue2;
		    $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

		    logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 14) {

		    $island->{'eis1'} = 200;
		    $island->{'eis2'} = 200;
		    $island->{'eis3'} = 200;
		    $island->{'eis4'} = 200;
		    $island->{'eis5'} = 200;
		    $island->{'eis6'} = 200;

		    logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 15) {

		    $island->{'eis7'} = 100099;

		    logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 22) {

		    $eisei4 = $island->{'eisei4'};
		    $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
		    $sto += int($sto * $avalue2 / 10);
		    $std += int($std * $avalue2 / 10);
		    $stk += int($stk * $avalue2 / 10);
		    $island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

		    logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 23) {

		    $eisei5 = $island->{'eisei5'};
		    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		    $msap += int($msap * $avalue2 / 10);
		    $msdp += int($msdp * $avalue2 / 10);
		    $mssp += int($mssp * $avalue2 / 10);
		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

		    logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 24) {

		    $eisei5 = $island->{'eisei5'};
		    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		    $msexe += $avalue2;
		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

		    logMonsCome2($id, $name, $ac, $topvalue2);

		} else {

		    # �ɤ��˸���뤫����
		    my($bx, $by, $i);
		    for($i = 0; $i < $HpointNumber; $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if(($land->[$bx][$by] == $HlandPlains) ||
			   ($land->[$bx][$by] == $HlandPlains2)) {

				if($shuppin2 == 0) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 74;
				} elsif($shuppin2 == 1) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 75;
				} elsif($shuppin2 == 2) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 76;
				} elsif($shuppin2 == 3) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 77;
				} elsif($shuppin2 == 4) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 78;
				} elsif($shuppin2 == 5) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 79;
				} elsif($shuppin2 == 10) {
				    $land->[$bx][$by] = $HlandUmiamu;
				    $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 11) {
				    $land->[$bx][$by] = $HlandFoodim;
				    $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 12) {
				    $land->[$bx][$by] = $HlandEneCs;
				    $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 13) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 74;
				} elsif($shuppin2 == 16) {
				    $land->[$bx][$by] = $HlandConden3;
				    $landValue->[$bx][$by] = 0;
				} elsif($shuppin2 == 17) {
				    $land->[$bx][$by] = $HlandGold;
				    $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 18) {
				    $land->[$bx][$by] = $HlandNursery;
				    $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 25) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 26) {
				    $land->[$bx][$by] = $HlandCollege;
				    $landValue->[$bx][$by] = 4;
				} elsif($shuppin2 == 27) {
				    $land->[$bx][$by] = $HlandEneWd;
				    $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 28) {
				    $land->[$bx][$by] = $HlandEneBo;
				    $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 30) {
				    my($tn) = $HidToNumber{$avalue2};
				    if($tn eq '') {

				    } else {
				    my($tIsland) = $Hislands[$tn];
				    my($tName) = $tIsland->{'name'};
				    my($tLand) = $tIsland->{'land'};
				    my($tLandValue) = $tIsland->{'landValue'};
					$tauc6 = $tIsland->{'auc6'};
					$tauc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc6a, $tauc6x, $tauc6y) = ($1, $2, $3);
					$tIsland->{'auc6'} = "0,0,0";
				    my($tx, $ty);
					$tx = $tauc6x;
					$ty = $tauc6y;
				    my($tL) = $tLand->[$tx][$ty];
				    my($tLv) = $tLandValue->[$tx][$ty];
				    my($tLname) = landName($tL, $tLv);
					$island->{'stocklandkind'} = $tLand->[$tx][$ty];
					$island->{'stocklandvalue'} = $tLandValue->[$tx][$ty];
					$tLand->[$tx][$ty] = $HlandPlains;
					$tLandValue->[$tx][$ty] = 0;
					$land->[$bx][$by] = $island->{'stocklandkind'};
					$landValue->[$bx][$by] = $island->{'stocklandvalue'};

					$tauc9 = $tIsland->{'auc9'};
					$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
					$tauc9c += $topvalue2*10000;
					$tauc9c2 = int($tauc9c/10000);
					$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
					$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";

					$island->{'auc8'} = "$tName����ʤ�$tLname";

					$aucland = $tL * $tLv;

						if($aucland != $topid2) {
							$tIsland->{'auc6'} = "77,0,0";
						}
				    }

				}

			    # ��å�����
			    logMonsCome2($id, $name, $ac, $topvalue2);
			    last;
			}
		    }
		}
	    }


	$auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

	if(($island->{'auc3'} == $topvalue3) && ($topvalue3 != 0) && ($island->{'money'}+$auc9c3 < $topvalue3*10000) && ($auc4b != $aucshouhin)) {
	    $island->{'auc6'} = "7,0,0";
	}

	if((($island->{'auc3'} == $topvalue3) && ($topvalue3 != 0) && ($island->{'money'}+$auc9c3 > $topvalue3*10000)) || ($auc4b == $aucshouhin)) {

	    if($auc4b == $aucshouhin) {

		    $auc0 = $island->{'auc0'};
		    $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
		    $shuppin3 = $auc0a;
		    $avalue3 = $auc0b;
		    $auc4c++;

		    $auc5 = $island->{'auc5'};
		    $auc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($auc5a, $auc5b, $auc5c, $auc5d, $auc5e) = ($1, $2, $3, $4, $5);

	    } else {

		    $shouhiauc9 = $auc9c2 - $topvalue3;

		    if($shouhiauc9 < 0) {
			$island->{'money'} -= ($topvalue3-$auc9c2)*10000;
			$auc9c2 = 0;
			$auc9c = $auc9c%10000;
			$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
			$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
		    } else {
			$auc9c -= $topvalue3*10000;
			$auc9c2 = int($auc9c/10000);
			$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
			$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
		    }

		    if($shuppin3 != 30) {
			$auc6 = $island->{'auc6'};
			$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
			($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
			$auc6a = 1;
			$island->{'auc6'} = "$auc6a,$auc6x,$auc6y";
		    }

		    $aucflag3 += $topvalue3;

		    $auc0 = $island->{'auc0'};
		    $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
		    if($topvalue3 > $auc0c) {
		    $island->{'auc0'} = "$shuppin3,$avalue3,$topvalue3,$hcturn,$auc0e";
		    }

	    }

	    if($shuppin3 == 0) {
		    $ac = '����';
		} elsif($shuppin3 == 1) {
		    $ac = '����';
		} elsif($shuppin3 == 2) {
		    $ac = 'ɹ��';
		} elsif($shuppin3 == 3) {
		    $ac = '����';
		} elsif($shuppin3 == 4) {
		    $ac = '����';
		} elsif($shuppin3 == 5) {
		    $ac = '����';
		} elsif($shuppin3 == 6) {
		    $ac = 'ŷ�ȥߥ�����';
		} elsif($shuppin3 == 7) {
		    $ac = '�������������ԥ���';
		} elsif($shuppin3 == 8) {
		    $ac = '���饤��쥸�����';
		} elsif($shuppin3 == 9) {
		    $ac = "�����$avalue3��";
		} elsif($shuppin3 == 10) {
		    $avalue3s = $avalue3 * 1000;
		    $ac = "�����ߤ�$avalue3s�͵���";
		} elsif($shuppin3 == 11) {
		    $avalue3s = $avalue3 * 1000;
		    $ac = "����$avalue3s�͵���";
		} elsif($shuppin3 == 12) {
		    $ac = "������$avalue3�����";
		} elsif($shuppin3 == 13) {
		    $ac = '����';
		} elsif($shuppin3 == 14) {
		    $ac = '��������';
		} elsif($shuppin3 == 15) {
		    $ac = '���襹�ơ������';
		} elsif($shuppin3 == 16) {
		    $ac = '����Υ���ǥ�';
		} elsif($shuppin3 == 17) {
		    $avalue3s = $avalue3 * 1000;
		    $ac = "�⻳$avalue3s�͵���";
		} elsif($shuppin3 == 18) {
		    $avalue3s = $avalue3 * 1000;
		    $ac = "�ܿ���$avalue3s�͵���";
		} elsif($shuppin3 == 19) {
		    $ac = '��¤����f02';
		} elsif($shuppin3 == 20) {
		    $ac = '�Ⲧ������';
		} elsif($shuppin3 == 21) {
		    $ac = 'unknown';
		} elsif($shuppin3 == 22) {
		    $ac = "���å�����������1.$avalue3��";
		} elsif($shuppin3 == 23) {
		    $ac = "��ʪ���ǽ��1.$avalue3��";
		} elsif($shuppin3 == 24) {
		    $ac = "��ʪ��طи���$avalue3";
		} elsif($shuppin3 == 25) {
		    $ac = '��';
		} elsif($shuppin3 == 26) {
		    $ac = '��ʪ���';
		} elsif($shuppin3 == 27) {
		    $ac = "����$avalue3�����";
		} elsif($shuppin3 == 28) {
		    $ac = "�Х����ޥ�$avalue3�����";
		} elsif($shuppin3 == 29) {
		    $ac = '����Ϥ��٤�';
		} elsif($shuppin3 == 30) {
		    my($island, $j, $name, $id, $ii);
		    for($ii = 0; $ii < $HislandNumber; $ii++) {
			$j = $ii + 1;
			$island = $Hislands[$ii];
			$id = $island->{'id'};
				if($avalue3 == $island->{'id'}) {
				    $dashiname = $island->{'auc7'};
				}
			}
		    $ac = "$dashiname";
		} else {
		    $ac = '��';
		}

	    if(($shuppin3 == 6) || ($shuppin3 == 7) || ($shuppin3 == 8) || ($shuppin3 == 19) || ($shuppin3 == 20) || ($shuppin3 == 21)) {

		my($i,$sx,$sy);
		my($zlv) = (0);
		for($i = 0; $i < $HpointNumber; $i++){
		    $sx = $Hrpx[$i];
		    $sy = $Hrpy[$i];
			if($land->[$sx][$sy] == $HlandZoo){
			    $zlv += $landValue->[$sx][$sy];
			}
		}

		$etc6 = $island->{'etc6'};
		$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

			if(($zlv > $zookazu) && ($island->{'zoo'} > 0)) {

				if($shuppin3 == 6) {
				    $ack = 13;
				} elsif($shuppin3 == 7) {
				    $ack = 22;
				} elsif($shuppin3 == 8) {
				    $ack = 14;
				} elsif($shuppin3 == 19) {
				    $ack = 17;
				} elsif($shuppin3 == 20) {
				    $ack = 21;
				} elsif($shuppin3 == 21) {
				    $ack = 23;
				}

				if($auc4b == $aucshouhin) {
				    logPrizeAuc2($id, $name, $ac, $topvalue3);
				    $island->{'auc4'} = "$auc4a,0,$auc4c";
					    if($auc4c >= $aucdendou) {
						if($auc0c > $auc5c) {
						    $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					    }
				} else {
				    logMonsCome2($id, $name, $ac, $topvalue3);
				}

				$z->{"$ack"}++;
				$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

			}

		} elsif($shuppin3 == 9) {

		    $etc8 = $island->{'etc8'};
		    $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
		    $toto2 += $avalue3;
		    $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

			if($auc4b == $aucshouhin) {
			    logPrizeAuc2($id, $name, $ac, $topvalue3);
			    $island->{'auc4'} = "$auc4a,0,$auc4c";
					    if($auc4c >= $aucdendou) {
						if($auc0c > $auc5c) {
						    $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					    }
			} else {
			    logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 14) {

		    $island->{'eis1'} = 200;
		    $island->{'eis2'} = 200;
		    $island->{'eis3'} = 200;
		    $island->{'eis4'} = 200;
		    $island->{'eis5'} = 200;
		    $island->{'eis6'} = 200;

			if($auc4b == $aucshouhin) {
			    logPrizeAuc2($id, $name, $ac, $topvalue3);
			    $island->{'auc4'} = "$auc4a,0,$auc4c";
					    if($auc4c >= $aucdendou) {
						if($auc0c > $auc5c) {
						    $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					    }
			} else {
			    logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 15) {

		    $island->{'eis7'} = 100099;

			if($auc4b == $aucshouhin) {
			    logPrizeAuc2($id, $name, $ac, $topvalue3);
			    $island->{'auc4'} = "$auc4a,0,$auc4c";
					    if($auc4c >= $aucdendou) {
						if($auc0c > $auc5c) {
						    $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					    }
			} else {
			    logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 22) {

		    $eisei4 = $island->{'eisei4'};
		    $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
		    $sto += int($sto * $avalue3 / 10);
		    $std += int($std * $avalue3 / 10);
		    $stk += int($stk * $avalue3 / 10);
		    $island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

			if($auc4b == $aucshouhin) {
			    logPrizeAuc2($id, $name, $ac, $topvalue3);
			    $island->{'auc4'} = "$auc4a,0,$auc4c";
					    if($auc4c >= $aucdendou) {
						if($auc0c > $auc5c) {
						    $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					    }
			} else {
			    logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 23) {

		    $eisei5 = $island->{'eisei5'};
		    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		    $msap += int($msap * $avalue3 / 10);
		    $msdp += int($msdp * $avalue3 / 10);
		    $mssp += int($mssp * $avalue3 / 10);
		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

			if($auc4b == $aucshouhin) {
			    logPrizeAuc2($id, $name, $ac, $topvalue3);
			    $island->{'auc4'} = "$auc4a,0,$auc4c";
					    if($auc4c >= $aucdendou) {
						if($auc0c > $auc5c) {
						    $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					    }
			} else {
			    logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 24) {

		    $eisei5 = $island->{'eisei5'};
		    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		    $msexe += $avalue3;
		    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

			if($auc4b == $aucshouhin) {
			    logPrizeAuc2($id, $name, $ac, $topvalue3);
			    $island->{'auc4'} = "$auc4a,0,$auc4c";
					    if($auc4c >= $aucdendou) {
						if($auc0c > $auc5c) {
						    $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					    }
			} else {
			    logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} else {

		    # �ɤ��˸���뤫����
		    my($bx, $by, $i);
		    for($i = 0; $i < $HpointNumber; $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if(($land->[$bx][$by] == $HlandPlains) ||
			   ($land->[$bx][$by] == $HlandPlains2)) {

				if($shuppin3 == 0) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 74;
				} elsif($shuppin3 == 1) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 75;
				} elsif($shuppin3 == 2) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 76;
				} elsif($shuppin3 == 3) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 77;
				} elsif($shuppin3 == 4) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 78;
				} elsif($shuppin3 == 5) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 79;
				} elsif($shuppin3 == 10) {
				    $land->[$bx][$by] = $HlandUmiamu;
				    $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 11) {
				    $land->[$bx][$by] = $HlandFoodim;
				    $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 12) {
				    $land->[$bx][$by] = $HlandEneCs;
				    $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 13) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = 74;
				} elsif($shuppin3 == 16) {
				    $land->[$bx][$by] = $HlandConden3;
				    $landValue->[$bx][$by] = 0;
				} elsif($shuppin3 == 17) {
				    $land->[$bx][$by] = $HlandGold;
				    $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 18) {
				    $land->[$bx][$by] = $HlandNursery;
				    $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 25) {
				    $land->[$bx][$by] = $HlandMonument;
				    $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 26) {
				    $land->[$bx][$by] = $HlandCollege;
				    $landValue->[$bx][$by] = 4;
				} elsif($shuppin3 == 27) {
				    $land->[$bx][$by] = $HlandEneWd;
				    $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 28) {
				    $land->[$bx][$by] = $HlandEneBo;
				    $landValue->[$bx][$by] = $avalue3;
				} elsif(($shuppin3 == 30) && ($auc4b != $aucshouhin)) {
				    my($tn) = $HidToNumber{$avalue3};
				    if($tn eq '') {

				    } else {
				    my($tIsland) = $Hislands[$tn];
				    my($tName) = $tIsland->{'name'};
				    my($tLand) = $tIsland->{'land'};
				    my($tLandValue) = $tIsland->{'landValue'};
					$tauc6 = $tIsland->{'auc6'};
					$tauc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc6a, $tauc6x, $tauc6y) = ($1, $2, $3);
					$tIsland->{'auc6'} = "0,0,0";
				    my($tx, $ty);
					$tx = $tauc6x;
					$ty = $tauc6y;
				    my($tL) = $tLand->[$tx][$ty];
				    my($tLv) = $tLandValue->[$tx][$ty];
				    my($tLname) = landName($tL, $tLv);
					$island->{'stocklandkind'} = $tLand->[$tx][$ty];
					$island->{'stocklandvalue'} = $tLandValue->[$tx][$ty];
					$tLand->[$tx][$ty] = $HlandPlains;
					$tLandValue->[$tx][$ty] = 0;
					$land->[$bx][$by] = $island->{'stocklandkind'};
					$landValue->[$bx][$by] = $island->{'stocklandvalue'};

					$tauc9 = $tIsland->{'auc9'};
					$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
					$tauc9c += $topvalue3*10000;
					$tauc9c2 = int($tauc9c/10000);
					$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
					$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";

					$island->{'auc8'} = "$tName����ʤ�$tLname";

					$aucland = $tL * $tLv;

						if($aucland != $topid3) {
							$tIsland->{'auc6'} = "77,0,0";
						}
				    }

				} elsif(($shuppin3 == 30) && ($auc4b == $aucshouhin)) {
					$ac="�ʤ�";
				}

			    # ��å�����
				if($auc4b == $aucshouhin) {
				    logPrizeAuc2($id, $name, $ac, $topvalue3);
				    $island->{'auc4'} = "$auc4a,0,$auc4c";
					    if($auc4c >= $aucdendou) {
						if($auc0c > $auc5c) {
						    $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					    }
				} else {
				    logMonsCome2($id, $name, $ac, $topvalue3);
				}
			    last;
			}
		    }
		}
	    }

	$island->{'auc1'} = 0;
	$island->{'auc2'} = 0;
	$island->{'auc3'} = 0;

    }



    if($s01 > $s02) {$s02 += 1;}
    if($s02 > $s01+10) {$s02 -= 2;}
    if($s03 > $s04) {$s04 += 1;}
    if($s04 > $s03+5) {$s04 -= 3;}
    if($s05 > $s06) {$s06 += 2;}
    if($s06 > $s05+15) {$s06 -= 1;}
    if($s07 > $s08) {$s08 += 2;}
    if($s08 > $s07+20) {$s08 -= 1;}
    if($s09 > $s10) {$s10 += 5;}
    if($s10 > $s09+50) {$s10 -= 1;}
    if($s11 > $s12) {$s12 += 5;}
    if($s12 > $s11+1) {$s12 -= 5;}

    $island->{'money'} -= ($s01+$s03+$s05+$s07+$s09+$s11+$s13+$s15+$s17+$s19+$s21+$s23+$s25+$s27+$s29)*10000;

    $island->{'etc5'} = "$s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";


    $s12b = int($s12/5)+1;
    if($s12b > 10) {$s12b = 10;}

    # ���������դ�Ƥ��鴹��
    if($island->{'food'} > 99999*$s12b) {
	$island->{'money'} += int(($island->{'food'} - 99999*$s12b) / 10);
	$island->{'food'} = 99999*$s12b;
    } 

    # ���������å�
    $island->{'pika'} = $island->{'money'} - $island->{'oldMoney'};

    # �⤬���դ�Ƥ����ڤ�Τ�
    if(($island->{'money'} > 999999*$s12b) && ($anothermood != 1)) {

        if($island->{'tai'} > 0) {
	$kifu = "";
	$kifukin = int(($island->{'money'}-999999*$s12b)/$island->{'tai'});
	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    if($landKind == $HlandTaishi) {
		$ttlv = $landValue->[$x][$y];
		my($tn) = $HidToNumber{$ttlv};
			if($tn eq '') {
			    # �������åȤ����Ǥˤʤ�
			    $land->[$x][$y] = $HlandPlains;
			    $landValue->[$x][$y] = 0;
			}else{
			my($tIsland) = $Hislands[$tn];
			my($tName) = $tIsland->{'name'};
			my($tLand) = $tIsland->{'land'};
			$tIsland->{'money'} += $kifukin;
			$kifu .= "$tName�硢";
        	}
            }
        }
	logKifu($id, $tId, $name, $tName, $kifu, "$kifukin����");
        }
	$island->{'money'} = 999999*$s12b;
    }


    $anotherkifu = 0;
    if(($anothermood == 1) && ($island->{'amarimoney'} > 0) && ($anotherkifu < 10)) {
        if($island->{'tai'} > 0) {
	$kifu = "";
	$kifukin = int($island->{'amarimoney'}/$island->{'tai'}/10);
	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    if($landKind == $HlandTaishi) {
		$ttlv = $landValue->[$x][$y];
		my($tn) = $HidToNumber{$ttlv};
			if($tn eq '') {
			    # �������åȤ����Ǥˤʤ�
			    $land->[$x][$y] = $HlandPlains;
			    $landValue->[$x][$y] = 0;
			}else{
			my($tIsland) = $Hislands[$tn];
			my($tName) = $tIsland->{'name'};
			my($tLand) = $tIsland->{'land'};
			$tIsland->{'money'} += $kifukin;
			$kifu .= "$tName�硢";
        	}
            }
        }
	logKifu($id, $tId, $name, $tName, $kifu, "$kifukin����");
	$anotherkifu++;
        }
    }


    # �Ƽ���ͤ�׻�
    estimate($number);

    # �˱ɡ������
    $pop = $island->{'pop'};
    my($damage) = $island->{'oldPop'} - $pop;
    my($prize) = $island->{'prize'};
    $prize =~ /([0-9]*),([0-9]*),(.*)/;
    my($flags) = $1;
    my($monsters) = $2;
    my($turns) = $3;

    $island->{'hamu'} = $island->{'pop'} - $island->{'oldPop'};
    $island->{'monta'} = $island->{'pts'} - $island->{'oldPts'};

    # �˱ɾ�
    if((!($flags & 1)) &&  $pop >= 3000){
	$flags |= 1;
	logPrize($id, $name, $Hprize[1]);
	    if($island->{'sin'} > 0) {
	    my($value, $str);
	    $value = random(3001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logSinMoney($id, $name, $str);
	    }
	    if($island->{'jin'} > 0) {
	    my($value, $str);
	    $value = random(3001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logJinMoney($id, $name, $str);
	    }
    } elsif((!($flags & 2)) &&  $pop >= 5000){
	$flags |= 2;
	logPrize($id, $name, $Hprize[2]);
	    if($island->{'sin'} > 0) {
	    my($value, $str);
	    $value = random(4001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logSinMoney($id, $name, $str);
	    }
	    if($island->{'jin'} > 0) {
	    my($value, $str);
	    $value = random(4001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logJinMoney($id, $name, $str);
	    }
    } elsif((!($flags & 4)) &&  $pop >= 10000){
	$flags |= 4;
	logPrize($id, $name, $Hprize[3]);
	    if($island->{'sin'} > 0) {
	    my($value, $str);
	    $value = random(5001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logSinMoney($id, $name, $str);
	    }
	    if($island->{'jin'} > 0) {
	    my($value, $str);
	    $value = random(5001);
	    $island->{'money'} += $value;
	    $str = "$value$HunitMoney";
	    # ��������
	    logJinMoney($id, $name, $str);
	    }
    }

    # �����
    if((!($flags & 64)) &&  $damage >= 500){
	$flags |= 64;
	logPrize($id, $name, $Hprize[7]);
    } elsif((!($flags & 128)) &&  $damage >= 1000){
	$flags |= 128;
	logPrize($id, $name, $Hprize[8]);
    } elsif((!($flags & 256)) &&  $damage >= 2000){
	$flags |= 256;
	logPrize($id, $name, $Hprize[9]);
    }

    $island->{'prize'} = "$flags,$monsters,$turns";
}


sub islandSortPop {
my($flag, $i, $tmp);

# �͸���Ʊ���Ȥ���ľ���Υ�����ν��֤Τޤ�
my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'pop'} <=> $Hislands[$a]->{'pop'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortFarm {
my($flag, $i, $tmp);

# ���ȵ��Ϥ�Ʊ���Ȥ���ľ���Υ�����ν��֤Τޤ�
my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'farm'} <=> $Hislands[$a]->{'farm'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortFactory {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'factoryt'} <=> $Hislands[$a]->{'factoryt'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortMountain {

my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'mountain'} <=> $Hislands[$a]->{'mountain'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortMonument {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'kei'} <=> $Hislands[$a]->{'kei'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortLive {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'monsterlive2'} <=> $Hislands[$a]->{'monsterlive2'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortRena {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'rena'} <=> $Hislands[$a]->{'rena'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortKill {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'taiji'} <=> $Hislands[$a]->{'taiji'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortFore {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'fore'} <=> $Hislands[$a]->{'fore'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortTare {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'tare'} <=> $Hislands[$a]->{'tare'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortZipro {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'zipro'} <=> $Hislands[$a]->{'zipro'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortLeje {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'leje'} <=> $Hislands[$a]->{'leje'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortForce {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'force'} <=> $Hislands[$a]->{'force'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortEisei2 {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'eisei2'} <=> $Hislands[$a]->{'eisei2'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortUni {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'uni'} <=> $Hislands[$a]->{'uni'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthck {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'ene'} <=> $Hislands[$a]->{'ene'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthckt {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'etc0'} <=> $Hislands[$a]->{'etc0'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthcr {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'shoritu'} <=> $Hislands[$a]->{'shoritu'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthcy {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'styusho'} <=> $Hislands[$a]->{'styusho'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthct {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'teamforce'} <=> $Hislands[$a]->{'teamforce'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}


sub islandSortHC {
my($flag, $i, $tmp);
my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'kachiten'} <=> $Hislands[$a]->{'kachiten'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortac4 {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'auc0c'} <=> $Hislands[$a]->{'auc0c'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

# Point��˥�����
sub islandSort {
    my($flag, $i, $tmp);

    # �͸���Ʊ���Ȥ���ľ���Υ�����ν��֤Τޤ�
    my @idx = (0..$#Hislands);
    @idx = sort { $Hislands[$b]->{'pts'} <=> $Hislands[$a]->{'pts'} || $a <=> $b } @idx;
    @Hislands = @Hislands[@idx];
}

# �����ﳲ�롼����
sub wideDamage {
    my($id, $name, $land, $landValue, $x, $y) = @_;
    my($sx, $sy, $i, $landKind, $landName, $lv, $point);

    for($i = 0; $i < 19; $i++) {
	$sx = $x + $ax[$i];
	$sy = $y + $ay[$i];

	# �Ԥˤ�����Ĵ��
	if((($sy % 2) == 0) && (($y % 2) == 1)) {
	    $sx--;
	}
    
	$landKind = $land->[$sx][$sy];
	$lv = $landValue->[$sx][$sy];
	$landName = landName($landKind, $lv);
	$point = "($sx, $sy)";

	# �ϰϳ�Ƚ��
	if(($sx < 0) || ($sx >= $HislandSize) ||
	   ($sy < 0) || ($sy >= $HislandSize)) {
	    next;
	}

	# �ϰϤˤ��ʬ��
	if($i < 7) {
	    # �濴�������1�إå���
	    if($landKind == $HlandSea) {
		$landValue->[$sx][$sy] = 0;
		next;
	    } elsif(($landKind == $HlandSbase) ||
		    ($landKind == $HlandSeacity) ||
		    ($landKind == $HlandSeatown) ||
		    ($landKind == $HlandUmishuto) ||
		    ($landKind == $HlandFune) ||
		    ($landKind == $HlandIce) ||
		    ($landKind == $HlandFrocity) ||
		    ($landKind == $HlandUmiamu) ||
		    ($landKind == $HlandOil)) {
		logWideDamageSea2($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandSea;
		$landValue->[$sx][$sy] = 0;
	    } else {
		if($landKind == $HlandMonster) {
	            my($mKind, $mName, $mHp) = monsterSpec($lv);
			if((($mKind == 20)&&($i == 0))||(($mKind == 21)&&($i == 0))){next;}
		    logWideDamageMonsterSea($id, $name, $landName, $point);
		} else {
		    logWideDamageSea($id, $name, $landName, $point);
		}
		$land->[$sx][$sy] = $HlandSea;
		if($i == 0) {
		    # ��
		    $landValue->[$sx][$sy] = 0;
		} else {
		    # ����
		    $landValue->[$sx][$sy] = 1;
		}
	    }
	} else {
	    # 2�إå���
	    if(($landKind == $HlandSea) ||
	       ($landKind == $HlandIce) ||
	       ($landKind == $HlandOil) ||
	       ($landKind == $HlandWaste) ||
	       ($landKind == $HlandMountain) ||
	       ($landKind == $HlandGold) ||
	       ($landKind == $HlandOnsen) ||
	       ($landKind == $HlandSeacity) ||
	       ($landKind == $HlandUmishuto) ||
	       ($landKind == $HlandSeatown) ||
	       ($landKind == $HlandFune) ||
	       ($landKind == $HlandFrocity) ||
	       ($landKind == $HlandUmiamu) ||
	       ($landKind == $HlandSbase)) {
		next;
	    } elsif($landKind == $HlandMonster) {
		logWideDamageMonster($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	    } else {
		logWideDamageWaste($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	    }
	}
    }
}

# �����ﳲ�롼���󡦥ߥ�
sub wideDamageli {
my($target, $tName, $tLand, $tLandValue, $tx, $ty) = @_;
my($sx, $sy, $i, $landKind, $landName, $lv, $point);

for($i = 0; $i < 19; $i++) {
$sx = $tx + $ax[$i];
$sy = $ty + $ay[$i];

# �Ԥˤ�����Ĵ��
if((($sy % 2) == 0) && (($ty % 2) == 1)) {
$sx--;
}

$landKind = $tLand->[$sx][$sy];
$lv = $tLandValue->[$sx][$sy];
$landName = landName($landKind, $lv);
$point = "($sx, $sy)";

# �ϰϳ�Ƚ��
if(($sx < 0) || ($sx >= $HislandSize) ||
($sy < 0) || ($sy >= $HislandSize)) {
next;
}
if(($landKind == $HlandSea) ||
($landKind == $HlandOil) ||
($landKind == $HlandWaste) ||
($landKind == $HlandIce) ||
($landKind == $HlandSeacity) ||
($landKind == $HlandSeatown) ||
($landKind == $HlandUmishuto) ||
($landKind == $HlandFune) ||
($landKind == $HlandFrocity) ||
($landKind == $HlandUmiamu) ||
($landKind == $HlandSbase)) {
next;
} elsif($landKind == $HlandMonster) {
logWideDamageMonster($target, $tName, $landName, $point);
$tLand->[$sx][$sy] = $HlandWaste;
$tLandValue->[$sx][$sy] = 0;
} elsif($landKind == $HlandTown) {
logWideDamageWaste($target, $tName, $landName, $point);
$tLand->[$sx][$sy] = $HlandWaste;
$tLandValue->[$sx][$sy] = 0;
} else {
logWideDamageWaste($target, $tName, $landName, $point);
$tLand->[$sx][$sy] = $HlandWaste;
$tLandValue->[$sx][$sy] = 0;
}
}
}


# �����ؤν���
# ��1����:��å�����
# ��2����:������
# ��3����:���
# �̾����
sub logOut {
    push(@HlogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# �ٱ����
sub logLate {
    push(@HlateLogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# ��̩����
sub logSecret {
    push(@HsecretLogPool,"1,$HislandTurn,$_[1],$_[2],$_[0]");
}

# ��Ͽ����
sub logHistory {
    open(HOUT, ">>${HdirName}/hakojima.his");
    print HOUT "$HislandTurn,$_[0]\n";
    close(HOUT);
}

# ��Ͽ����Ĵ��
sub logHistoryTrim {
    open(HIN, "${HdirName}/hakojima.his");
    my(@line, $l, $count);
    $count = 0;
    while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
	$count++;
    }
    close(HIN);

    if($count > $HhistoryMax) {
	open(HOUT, ">${HdirName}/hakojima.his");
	my($i);
	for($i = ($count - $HhistoryMax); $i < $count; $i++) {
	    print HOUT "$line[$i]\n";
	}
	close(HOUT);
    }
}

# Hakoniwa Cup����
sub logHcup {
    open(COUT, ">>${HdirName}/hakojima.lhc");
    print COUT "$HislandTurn,$_[0]\n";
    close(COUT);
}

# Hakoniwa Cup����Ĵ��
sub logHcupTrim {
    open(CIN, "${HdirName}/hakojima.lhc");
    my(@line, $l, $count);
    $count = 0;
    while($l = <CIN>) {
	chomp($l);
	push(@line, $l);
	$count++;
    }
    close(CIN);

    if($count > $HhcMax) {
	open(COUT, ">${HdirName}/hakojima.lhc");
	my($i);
	for($i = ($count - $HhcMax); $i < $count; $i++) {
	    print COUT "$line[$i]\n";
	}
	close(COUT);
    }
}

# Hakoniwa Auction����
sub logAuc {
    open(AOUT, ">>${HdirName}/hakojima.auc");
    print AOUT "$HislandTurn,$_[0]\n";
    close(AOUT);
}

# Hakoniwa Auction����Ĵ��
sub logAucTrim {
    open(AIN, "${HdirName}/hakojima.auc");
    my(@line, $l, $count);
    $count = 0;
    while($l = <AIN>) {
	chomp($l);
	push(@line, $l);
	$count++;
    }
    close(AIN);

    if($count > 10) {
	open(AOUT, ">${HdirName}/hakojima.auc");
	my($i);
	for($i = ($count - 10); $i < $count; $i++) {
	    print AOUT "$line[$i]\n";
	}
	close(AOUT);
    }
}

# �����񤭽Ф�
sub logFlush {
    open(LOUT, ">${HdirName}/hakojima.log0");

    # �����ս�ˤ��ƽ񤭽Ф�
    my($i);
    for($i = $#HsecretLogPool; $i >= 0; $i--) {
	print LOUT $HsecretLogPool[$i];
	print LOUT "\n";
    }
    for($i = $#HlateLogPool; $i >= 0; $i--) {
	print LOUT $HlateLogPool[$i];
	print LOUT "\n";
    }
    for($i = $#HlogPool; $i >= 0; $i--) {
	print LOUT $HlogPool[$i];
	print LOUT "\n";
    }
    close(LOUT);
}

#----------------------------------------------------------------------
# �����ƥ�ץ졼��
#----------------------------------------------------------------------
# ���­��ʤ�
sub logNoMoney {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ������­�Τ�����ߤ���ޤ�����",$id);
}

sub logNoMoney2 {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ������­�Τ�����ߤ���ޤ�����",$id);
}

# ����­��ʤ�
sub logNoFood {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ����߿�����­�Τ�����ߤ���ޤ�����",$id);
}

# �����ʤ�
sub logNoEisei {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�����ο͹��������ʤ�������ߤ���ޤ�����",$id);
}

# �����ʤ���
sub logNesEisei {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ɬ�פʿ͹��������ʤ�������ߤ���ޤ�����",$id);
}

# ���Ĥ���ʤ�
sub logForbidden {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ��¹Ԥ����Ĥ���ޤ���Ǥ�����",$id);
}

# Ȣ��Ϣ�緳
sub logNiwaren {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�ϡ�<B>Ȣ��Ϣ�緳</B>��${HtagDisaster_}����${H_tagDisaster}����ޤ�����",$id);
}

# Ȣ��Ϣ�緳��
sub logNiwaren2 {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagComName_}$comName${H_tagComName}�ϡ�${HtagDisaster_}�����${H_tagDisaster}���ʧ���Ϥ�ˤʤ�ޤ�����",$id);
}

# Ȣ��Ϣ�緳��
sub logNiwaren3 {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�<B>����ͷ�ε��Ĥ����Ƥʤ�</B>������ߤ���ޤ�����",$id);
}

# ���ԤǤ�
sub logShuto {
    my($id, $name, $lName, $sName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϡ�<B>����$sName</B>�Ȥ�������濴Ū�ԻԤؤȤʤ�ޤ�����",$id);
    logHistory("${HtagName_}${name}��${H_tagName}��<B>����$sName</B>������ޤ�����");
END
}

# �о��Ϸ��μ���ˤ�뼺��
sub logLandFail {
    my($id, $name, $comName, $kind, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ͽ���Ϥ�${HtagName_}$point${H_tagName}��<B>$kind</B>���ä�������ߤ���ޤ�����",$id);
END
}

# �о��Ϸ��ξ��ˤ�뼺��
sub logJoFail {
    my($id, $name, $comName, $kind, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ͽ���Ϥ�${HtagName_}$point${H_tagName}�������������Ƥ��ʤ�<B>$kind</B>�Τ�����ߤ���ޤ�����",$id);
END
}

# �о��Ϸ��ξ��ˤ�뼺��2
sub logJo2Fail {
    my($id, $name, $comName, $kind, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�Ǥ������ޤ��ϡ���ʬ�ʼ��¤��뤿���<B>������</B>����ݤ��ޤ��礦��",$id);
END
}

# �ԻԤμ���ˤ�뼺��
sub logBokuFail {
    my($id, $name, $comName, $kind, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ͽ���Ϥ�${HtagName_}$point${H_tagName}���������������ԻԤǤʤ��ä�������ߤ���ޤ�����",$id);
END
}

# ���äε��ݤˤ�뼺��
sub logBokuFail2 {
    my($id, $name, $comName, $kind, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ͽ����${HtagName_}$point${H_tagName}��<b>$kind</b>�������򤷤�������ߤ���ޤ�����",$id);
END
}

# �����Φ���ʤ������Ω�Ƽ���
sub logNoLandAround {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ͽ���Ϥ�${HtagName_}$point${H_tagName}�μ��դ�Φ�Ϥ��ʤ��ä�������ߤ���ޤ�����",$id);
END
}

# ����˹����ʤ���������
sub logNoLandAroundm {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ͽ���Ϥ�${HtagName_}$point${H_tagName}�μ��դ˹�Į���ʤ��ä�������ߤ���ޤ�����",$id);
END
}

# ����˹����ʤ���������
sub logNoLandArounde {
    my($id, $name, $comName, $point, $lName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ͽ���Ϥ�${HtagName_}$point${H_tagName}�μ��դ�<B>$lName</B>���ʤ��ä�������ߤ���ޤ�����",$id);
END
}

# �����Į���ʤ������Ω�Ƽ���
sub logNoTownAround {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}$comName${H_tagComName}�ϡ�ͽ���Ϥ�${HtagName_}$point${H_tagName}�μ��դ˿͸������ʤ��ä�������ߤ���ޤ�����",$id);
END
}

# ���Ϸ�����
sub logLandSuc {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ�����",$id);
END
}

# ���Ϸ�������
sub logLandSucmini {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ�����",$id);
END
}

# ��������
sub logNoRoke {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}${comName}${H_tagComName}�ϥ����åȤ�­��ʤ�������ߤ���ޤ�����",$id);
END
}

# ���ơ����������­
sub logNoRokeCst {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagDisaster_}�����å���­${H_tagDisaster}�ˤ��<B>���襹�ơ������</B>�˿��������٤ޤ��󡪡�",$id);
END
}

# �������Բ�
sub logNoTech {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}${comName}${H_tagComName}�Ϸ������Ѥ�­��ʤ�������ߤ���ޤ�����",$id);
END
}

# ��������
sub logEiseifail {
    my($id, $name, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ�����${HtagComName_}${comName}${H_tagComName}��${HtagDisaster_}����${H_tagDisaster}�����褦�Ǥ���",$id);
END
}

# ����ȯ��
sub logOilFound {
    my($id, $name, $point, $comName, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$str</B>��ͽ����Ĥ������${HtagComName_}${comName}${H_tagComName}���Ԥ�졢<B>���Ĥ��������Ƥ��ޤ���</B>��",$id);
END
}

# ����ȯ��
sub logHotFound {
    my($id, $name, $point, $comName, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$str</B>��ͽ����Ĥ������${HtagComName_}${comName}${H_tagComName}���Ԥ�졢<B>�������������Ƥ��ޤ���</B>��",$id);
END
}

# ����ȯ���ʤ餺
sub logOilFail {
    my($id, $name, $point, $comName, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$str</B>��ͽ����Ĥ������${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ����������Ĥϸ��Ĥ���ޤ���Ǥ�����",$id);
END
}

# ����ȯ���ʤ餺
sub logHotFail {
    my($id, $name, $point, $comName, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$str</B>��ͽ����Ĥ������${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ������������ϸ��Ĥ���ޤ���Ǥ�����",$id);
END
}

# ���Ĥ���μ���
sub logOilMoney {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>���顢<B>$str</B>�μ��פ��夬��ޤ�����",$id);
END
}

# ���Ĥ���μ���
sub logOilMoney2 {
    my($id, $name, $lName, $point, $str, $str2) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>���顢<B>$str</B>�μ��פ��夬��ޤ�����(����<B>$str2</B>����)",$id);
END
}

# ���¤���μ���
sub logSinMoney {
    my($id, $name, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>����</B>�ǽˤ��κפ꤬�Ԥ�졢<B>$str</B>�μ��פ��夬��ޤ�����",$id);
END
}

# ���Ҥ���μ���
sub logJinMoney {
    my($id, $name, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>����</B>�ǽˤ��κפ꤬�Ԥ�졢<B>$str</B>�μ��פ��夬��ޤ�����",$id);
END
}

# ���ĸϳ�
sub logOilEnd {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϸϳ餷���褦�Ǥ���",$id);
END
}

# �ؽ꤫��μ���
sub logSekiMoney {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>���顢<B>$str</B>�δ��Ǽ��פ��夬��ޤ�����",$id);
END
}

# ��ϳ�
sub logGoldEnd {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>����⤬�Τ�ʤ��ʤä��褦�Ǥ���",$id);
END
}
# �żָξ�
sub logTrainEnd {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϸξ㤷���褦�Ǥ���",$id);
END
}
# �żָξ�2
sub logTrainEnd2 {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϲ��Ǥ����褦�Ǥ���",$id);
END
}
# ͷ���Ϥ���μ���
sub logParkMoney {
    my($id, $name, $str, $point, $lName) = @_;
    logOut("${HtagName_}${name}���$point����${H_tagName}��<B>$lName</B>���顢<B>���$str</B>�μ��פ��夬��ޤ�����",$id);
END
}

# ͷ���ϤΥ��٥��
sub logParkEvent {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ǥ��٥�Ȥ����Ť��졢<B>$str</B>�ο��������񤵤�ޤ�����",$id);
END
}

# ͷ���Ϥ��ı�
sub logParkEnd {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϻ��ߤ�Ϸ�ಽ���������������ޤ�����",$id);
END
}

# ���û�����
sub logSiire {
    my($id, $name, $lName, $mName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>$mName</B>�����٤��������Ǥ��ޤ���",$id);
END
}

# �ݸ�����μ���
sub logHoken {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�λ��Τˤ�ꡢ<B>$str</B>���ݸ�������ޤ�����",$id);
END
}

# �ڻ�����μ���
sub logMiyage {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName��ǰ�����</B>�Τ��ڻ������󤫤�<B>$str</B>�μ���������ޤ�����",$id);
END
}

# �ϼҤ���μ���
sub logMiyage2 {
    my($id, $name, $lName, $point, $dName) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName��</B>�ϡ�<B>$dName</B>��ȯ���ޤ�����",$id);
END
}

# �ϼҤ���μ���
sub logMiyage2b {
    my($id, $name, $lName, $str, $dName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$lName��</B>����ͭ����<B>$dName</B>����ȯŪ����졢<B>$str</B>�ηкѸ��̤�⤿�餷�ޤ�����",$id);
END
}

# �ϼҤ���μ���
sub logMiyage2c {
    my($id, $name, $lName, $str, $dName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$lName��</B>����ͭ����<B>$dName</B>����ȯŪ����졢<B>$str</B>�ηкѸ��̤�⤿�餷�ޤ��������ʤߤ���������ڤ�ޤ�����",$id);
END
}

# ͥ������μ���
sub logYusho {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�����������${HtagName_}$point${H_tagName}��<B>$lName</B>�ǹԤ�줿Ȣ���꡼���辡��Ǥߤ���ͥ������<B>$str</B>�ηкѸ��̤�������ޤ�����",$id);
END
}

# ��������μ���
sub logParkMoneyf {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>���顢<B>$str</B>�δѸ��������夬��ޤ�����",$id);
END
}

# ��������μ���
sub logTitanicEnd {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�����פϱǲ貽���졢¿���οͤ��ޤ�ή���ޤ�����(<B>$str</B>�����׼���)",$id);
END
}

# ����õ������μ���
sub logTansaku {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��������ȯ����<B>$str</B>�β��ͤ����뤳�Ȥ��狼��ޤ�����",$id);
END
}

# ����õ��������
sub logTansakuoil {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�����Ĥ�ȯ����",$id);
END
}

# ����⤫��μ���
sub logEnjo {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("��ȯ�ʹ԰Ѱ��񤫤�${HtagName_}${name}��${H_tagName}��<B>$str</B>�α���⤬�ٵ뤵�줿�褦�Ǥ���",$id);
END
}

# ����Ϸ�ಽ
sub logParkEndf {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϻ��Τ������פ��ޤ�����",$id);
END
}

# TITANIC����
sub logTitanic {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��ɹ���˷��ͤ�������Ĥˤʤ����פ��ޤ�����",$id);
END
}

# ����
sub logOilMoneyt {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>����Ȥ���������<B>$str</B>���ͤ��դ��ޤ�����",$id);
END
}

# ������
sub logParkEventt {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>���⤿�餷��˭��ˤ�ꡢ�����<B>$str</B>�ο���������ޤ�����",$id);
END
}

# ���μ���
sub logParkEventf {
    my($id, $name, $lName, $point, $str) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϡ�<B>$str</B>�ο��������ޤ�����",$id);
END
}

# �ɱһ��ߡ��������å�
sub logBombSet {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>�������֤����å�</B>����ޤ�����",$id);
END
}

# �ɱһ��ߡ�������ư
sub logBombFire {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}�������ֺ�ư����${H_tagDisaster}",$id);
END
}

# ����𤬿���
sub logKuralupin {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}����𤬿��������褦�Ǥ�����${H_tagDisaster}",$id);
END
}

# ��ǰ�ꡢȯ��
sub logMonFly {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>�첻�ȤȤ������Ω���ޤ���</B>��",$id);
END
}

# ��ǰ�ꡢ�
sub logMonDamage {
    my($id, $name, $point) = @_;
    logOut("<B>�����ȤƤĤ�ʤ����</B>��${HtagName_}${name}��$point${H_tagName}����������ޤ�������",$id);
}

# ����or�ߥ��������
sub logPBSuc {
    my($id, $name, $comName, $point) = @_;
    logSecret("${HtagName_}${name}��$point${H_tagName}��${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ�����",$id);
    logOut("�������ʤ�����${HtagName_}${name}��${H_tagName}��<B>��</B>���������褦�Ǥ���",$id);
END
}

# �ϥ�ܥ�
sub logHariSuc {
    my($id, $name, $comName, $comName2, $point) = @_;
    logSecret("${HtagName_}${name}��$point${H_tagName}��${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ�����",$id);
    logLandSuc($id, $name, $comName2, $point);
END
}

# �ߥ������Ȥ��Ȥ���(or �����ɸ����褦�Ȥ���)���������åȤ����ʤ�
sub logMsNoTarget {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}${comName}${H_tagComName}�ϡ���ɸ����˿ͤ���������ʤ�������ߤ���ޤ�����",$id);
END
}

# �ߥ������Ȥ��Ȥ���(or �����ɸ����褦�Ȥ���)�����Ϥ����ʤ�
sub logMsNoEne {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}${comName}${H_tagComName}�ϡ����Ϥ���­���Ƥ���Τˤȡ���̱�������ޤ���Ǥ�����",$id);
END
}

# �ߥ������Ȥ��Ȥ���(or �����ɸ����褦�Ȥ���)�����Ϥ����ʤ�
sub logMsNoEne2 {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���<B>��ͥ��åĻ���</B>�ϡ����Ϥ���­�����ǽ�������뤿����ߤ��ޤ�����",$id);
END
}

# �ߥ������Ȥ��Ȥ���(or �����ɸ����褦�Ȥ���)�����Ϥ����ʤ�
sub logMsNoEne3 {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}${comName}${H_tagComName}�Ͻ��ʸ������ʤ�������ߤȤʤ�ޤ�����",$id);
END
}

# �ߥ������Ȥ��Ȥ���(or �����ɸ����褦�Ȥ���)�����Ϥ����ʤ�
sub logMsNoEne4 {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}${comName}${H_tagComName}�Ͻ����Ȥ������Ƥʤ�������ߤȤʤ�ޤ�����",$id);
END
}

# ��ѻշ�Ȥ��Ȥ�������ˡ���ä��ʤ�
sub logMagicNoTarget {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}${comName}${H_tagComName}�ϡ���ˡ�ع����ʤ����ᵶ�Ԥ��ɸ����Ƥߤޤ�����",$id);
END
}

# �ߥ������Ȥ��Ȥ��������Ϥ��ʤ�
sub logMsNoBase {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͽ�ꤵ��Ƥ���${HtagComName_}${comName}${H_tagComName}�ϡ�<B>�ߥ�������������ͭ���Ƥ��ʤ�</B>����˼¹ԤǤ��ޤ���Ǥ�����",$id);
END
}

# �ߥ������ä����ϰϳ�
sub logMsOut {
    my($id, $tId, $name, $tName, $comName, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������<B>�ΰ賰�γ�</B>����������ͤǤ���",$id, $tId);
}

# �����˲�����
sub logEiseiAtts {
    my($id, $tId, $name, $tName, $comName, $tEiseiname) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��${H_tagName}�˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���<B>$tEiseiname</B>��̿�档<B>$tEiseiname</B>���׷���ʤ��ä����Ӥޤ�����",$id, $tId);
}

# ���襹�ơ�������˲�����
sub logEiseiAttcst {
    my($id, $tId, $name, $tName, $comName, $tEiseiname, $tdmg) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��${H_tagName}�˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���<B>$tEiseiname</B>��̿�档<B>$tdmg%</B>��»����Ϳ���ޤ�����",$id, $tId);
}

# �����˲�����
sub logEiseiAttf {
    my($id, $tId, $name, $tName, $comName, $tEiseiname) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��${H_tagName}��<B>$tEiseiname</B>�˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ����������ˤ�̿�椻������������ؤ����ӵ�äƤ��ޤ��ޤ�������",$id, $tId);
}

# ���ƥ륹�ߥ������ä����ϰϳ�
sub logMsOutS {
    my($id, $tId, $name, $tName, $comName, $point) = @_;
    logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������<B>�ΰ賰�γ�</B>����������ͤǤ���",$id, $tId);
    logLate("<B>���Ԥ�</B>��${HtagName_}${tName}��$point${H_tagName}�ظ�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������<B>�ΰ賰�γ�</B>����������ͤǤ���",$tId);
}

# �ߥ������ä����ɱһ��ߤǥ���å�
sub logMsCaught {
    my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��������ˤ��Ͼ��ª����졢<B>������ȯ</B>���ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ������ä����ɱһ��ߤǥ���å�
sub logMsCaughtS {
    my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
    logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��������ˤ��Ͼ��ª����졢<B>������ȯ</B>���ޤ�����",$id, $tId);
    logLate("<B>���Ԥ�</B>��${HtagName_}${tName}��$point${H_tagName}�ظ�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��������ˤ��Ͼ��ª����졢<B>������ȯ</B>���ޤ�����",$tId);
}

# �ߥ������ä����ɱұ����ǥ���å�
sub logMsCaughtE {
    my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������<B>�ɱұ���</B>�˷����Ȥ���ޤ�����",$id, $tId);
}

# �ߥ������ä������̤ʤ�
sub logMsNoDamage {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��������Τ��ﳲ������ޤ���Ǥ�����",$id, $tId);
}

# ���ƥ륹�ߥ������ä������̤ʤ�
sub logMsNoDamageS {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��������Τ��ﳲ������ޤ���Ǥ�����",$id, $tId);

    logLate("<B>���Ԥ�</B>��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��������Τ��ﳲ������ޤ���Ǥ�����",$tId);
}

# Φ���˲��ơ�����̿��
sub logMsLDMountain {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�档<B>$tLname</B>�Ͼä����ӡ����ϤȲ����ޤ�����",$id, $tId);
}

# Φ���˲��ơ�������Ϥ�̿��
sub logMsLDSbase {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��������ȯ��Ʊ�����ˤ��ä�<B>$tLname</B>���׷���ʤ��᤭���Ӥޤ�����",$id, $tId);
}

# Φ��δ���ơ�������Ϥ�̿��
sub logMsLRSbase {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��������ȯ��Ʊ�����ˤ��ä�<B>$tLname</B>��δ�����������ˤʤ�ޤ�����",$id, $tId);
}

# Φ���˲��ơ����ä�̿��
sub logMsLDMonster {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}�����Ƥ���ȯ��Φ�Ϥ�<B>$tLname</B>����Ȥ���פ��ޤ�����",$id, $tId);
}

# Φ��δ���ơ����ä�̿��
sub logMsLRMonster {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}�����Ƥ���ȯ��Φ�Ϥ�<B>$tLname</B>����Ȥ�δ������������ޤ�����",$id, $tId);
}

# Φ���˲��ơ�������̿��
sub logMsLDSea1 {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�����ơ����줬�������ޤ�����",$id, $tId);
}

# Φ��δ���ơ�������̿��
sub logMsLRSea1 {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�����ơ�δ�������ϤȤʤ�ޤ�����",$id, $tId);
}

# Φ���˲��ơ�����¾���Ϸ���̿��
sub logMsLDLand {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�����ơ�Φ�ϤϿ��פ��ޤ�����",$id, $tId);
}

# Φ��δ���ơ�����¾���Ϸ���̿��
sub logMsLRLand {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�����ơ�δ������������ޤ�����",$id, $tId);
}

# �̾�ߥ����롢���Ϥ�����
sub logMsWaste {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>������ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ����롢���Ϥ�����
sub logMsWasteS {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>������ޤ�����",$id, $tId);
    logLate("<B>���Ԥ�</B>��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>������ޤ�����",$tId);
}

# �˥ߥ����롢����
sub logMsSS {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�����Ƥ�����ȯ���ޤ�����",$id, $tId);
}

# �̾�ߥ����롢���ä�̿�桢�Ų���ˤ�̵��
sub logMsMonNoDamage {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢�������Ų����֤��ä�������̤�����ޤ���Ǥ�����",$id, $tId);
}

# ���ƥ륹�ߥ����롢���ä�̿�桢�Ų���ˤ�̵��
sub logMsMonNoDamageS {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢�������Ų����֤��ä�������̤�����ޤ���Ǥ�����",$id, $tId);
    logOut("<B>���Ԥ�</B>��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢�������Ų����֤��ä�������̤�����ޤ���Ǥ�����",$tId);
}

# �̾�ߥ����롢���ä�̿�桢����
sub logMsMonKill {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�档<B>$tLname</B>���ϿԤ����ݤ�ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ����롢���ä�̿�桢����
sub logMsMonKillS {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logSecret("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�档<B>$tLname</B>���ϿԤ����ݤ�ޤ�����",$id, $tId);
    logLate("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�档<B>$tLname</B>���ϿԤ����ݤ�ޤ�����", $tId);
}

# �̾�ߥ����롢���ä�̿�桢���᡼��
sub logMsMonster {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�档<B>$tLname</B>�϶줷��������Ӭ���ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ����롢���ä�̿�桢���᡼��
sub logMsMonsterS {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�档<B>$tLname</B>�϶줷��������Ӭ���ޤ�����",$id, $tId);
    logLate("<B>���Ԥ�</B>��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�档<B>$tLname</B>�϶줷��������Ӭ���ޤ�����",$tId);
}

# ���äλ���
sub logMsMonMoney {
    my($tId, $mName, $value) = @_;
    logOut("<B>$mName</B>�λĳ��ˤϡ�<B>$value$HunitMoney</B>���ͤ��դ��ޤ�����",$tId);
}

# �ߥ�����ޤȤ����
sub logMsTotal {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $count, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}$countȯ��${comName}${H_tagComName}��Ԥ��ޤ�����<br>${HtagNumber_}������${HislandTurn}${H_tagNumber}��${HtagName_}���${H_tagName}��(̵��$mukouȯ/�ɱ�$boueiȯ/�����껦$kaijumukouȯ/����̿��$kaijuhitȯ/��ȯ��$fuhatuȯ)",$id, $tId);
}

# ���ƥ륹�ߥ�����ޤȤ����
sub logMsTotalS {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $count, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu) = @_;
    logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}$countȯ��${comName}${H_tagComName}��Ԥ��ޤ�����<br>${HtagNumber_}������${HislandTurn}${H_tagNumber}��${HtagName_}���${H_tagName}��(̵��$mukouȯ/�ɱ�$boueiȯ/�����껦$kaijumukouȯ/����̿��$kaijuhitȯ/��ȯ��$fuhatuȯ)",$id, $tId);
    logLate("<B>���Ԥ�</B>��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}$countȯ��${comName}${H_tagComName}��Ԥ��ޤ�����<br>${HtagNumber_}������${HislandTurn}${H_tagNumber}��${HtagName_}���${H_tagName}��(̵��$mukouȯ/�ɱ�$boueiȯ/�����껦$kaijumukouȯ/����̿��$kaijuhitȯ)",$id, $tId);
}

# �̾�ߥ������̾��Ϸ���̿��
sub logMsNormal {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢���Ӥ����Ǥ��ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ������̾��Ϸ���̿��
sub logMsNormalS {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logSecret("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢���Ӥ����Ǥ��ޤ�����",$id, $tId);
    logLate("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢���Ӥ����Ǥ��ޤ�����",$tId);
}

# �ߥ�������̱����
sub logMsBoatPeople {
    my($id, $name, $achive) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�ˤɤ�����Ȥ�ʤ�<B>$achive${HunitPop}�����̱</B>��ɺ�夷�ޤ�����${HtagName_}${name}��${H_tagName}�ϲ����������줿�褦�Ǥ���",$id);
}

# ���ƥ륹�ߥ����롢���äˤ�������Ȥ����
sub logMsMonsCautS {
  my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
  logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�ˤ�������Ȥ���ޤ�����",$id, $tId);
}

# �̾�ߥ����롢���äˤ�������Ȥ����(���ƥ륹�ʳ�)
sub logMsMonsCaut {
  my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�ˤ�������Ȥ���ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ����롢ŷ�Ȥˤ�������Ȥ����
sub logMsMonsCauttS {
  my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
  logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>���Ǥ��ä���ޤ�����",$id, $tId);
}

# �̾�ߥ����롢ŷ�Ȥˤ�������Ȥ����(���ƥ륹�ʳ�)
sub logMsMonsCautt {
  my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>���Ǥ��ä���ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ����롢���饤��ˤ�������Ȥ����
sub logMsMonsCautlS {
  my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
  logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�˰��߹��ޤ�ޤ�����",$id, $tId);
}

# �̾�ߥ����롢���饤��ˤ�������Ȥ����(���ƥ륹�ʳ�)
sub logMsMonsCautl {
  my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�˰��߹��ޤ�ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ����롢�ᥫ�ˤ�������Ȥ����
sub logMsMonsCautmS {
  my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
  logSecret("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�ˤ��޷�ߥ�����˷�����ޤ�����",$id, $tId);
}

# �̾�ߥ����롢�ᥫ�ˤ�������Ȥ����(���ƥ륹�ʳ�)
sub logMsMonsCautm {
  my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�������${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�ˤ��޷�ߥ�����˷�����ޤ�����",$id, $tId);
}

# ���ä����⤹��
sub logMonsAttack {
  my($id, $name, $mName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�˸����äƱ���Ǥ��Ĥ��ޤ�����",$id, $tId);
}

# ŷ�Ȥ����⤹��
sub logMonsAttackt {
  my($id, $name, $mName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�򹶷⤷�ޤ�����",$id, $tId);
}

# ���Ԥ򹶷⤹��
sub logMonsAttacks {
  my($id, $name, $lName, $point) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϲ��ä�${HtagDisaster_}����${H_tagDisaster}�����ﳲ������ޤ�����",$id);
}

# ����ǽϳ��
sub logAtAttacks {
  my($id, $name, $lName, $point) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�Ǥ�${HtagDisaster_}����ǽϳ��${H_tagDisaster}�������졢�ն�ν�̱�ؤ��԰¤������äƤޤ���",$id);
}

# ���줬���⤹��
sub logIreAttackt {
  my($id, $name, $mName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�򹶷⤷${HtagDisaster_}$point${H_tagDisaster}�Υ��᡼����Ϳ���ޤ�����",$id, $tId);
}

# ��ѻդ����⤹��
sub logIreAttackt2 {
  my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>��������������<B>$maName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>��${HtagDisaster_}$point${H_tagDisaster}�Υ��᡼����Ϳ���ޤ�����",$id, $tId);
}

# ��ѻդ����⤹��
sub logIreAttackt3 {
  my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>��������������<B>$maName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>����ˡ�",$id, $tId);
}

# ��ѻդ����⤹��
sub logIreAttackt4 {
  my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>��������������<B>$maName</B>��${HtagDisaster_}$point${H_tagDisaster}�����<B>$tName</B>��$tPoint�ޤ�����",$id, $tId);
}

# ��ѻդ����⤹��
sub logIreAttackt5 {
  my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>�����äƤ���<B>$maName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�򥲥åȡ�",$id, $tId);
}

# ��ѻդ����⤹��
sub logIreAttackt6 {
  my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>�����äƤ���<B>$maName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>����ͤ˼��ԡ�",$id, $tId);
}

# ��ѻդ����⤹��
sub logIreAttackt7 {
  my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>�����äƤ���<B>$maName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�򥲥åȡ��Ǥ��ޤ�����ưʪ��ˤϤ���ʾ�����ޤ���",$id, $tId);
}

# �ޥ����åȤ����⤹��
sub logMsAttackt {
  my($id, $name, $mName, $point, $cPoint, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�򹶷⤷${HtagDisaster_}$point${H_tagDisaster}�Υ��᡼����Ϳ��${HtagDisaster_}$cPoint${H_tagDisaster}�Υ��᡼��������ޤ�����",$id, $tId);
}

# �ߥ�����������
sub logMsAttackmika {
  my($id, $name, $mName, $point, $cPoint, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>��<B>$tName</B>���襤������Ȥʤꡢ��̱��<B>��ʡ�ν�����</B>���¤���ޤ�����",$id, $tId);
}

# ����Ǽ�Ϥ�
sub logItiAttack {
  my($id, $name, $mName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�μ����ͤޤ�����",$id, $tId);
}

# ����Ǽ�Ϥ�
sub logItiAttackms {
  my($id, $name, $mName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>��¤�Ĥ��ޤ�����",$id, $tId);
}


# ɹ�Ƕ��ɤ�
sub logIceAttack {
  my($id, $name, $mName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��ȯ����ɹ�����${HtagName_}$tPoint${H_tagName}��<B>$tName</B>���濴��Ӥ��ޤ�����",$id, $tId);
}

# �إ�ե�����
sub logHellAttack {
  my($id, $name, $mName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>�θƤӵ��������Ϲ��α��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>��Ƥ��Ԥ����ޤ�����",$id, $tId);
}

# �Ͼ�ǲ��ä�����
sub logBariaAttack {
  my($id, $name, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$tPoint${H_tagName}��<B>$tName</B>��<B>���Ϥ��Ͼ�</B>�˲����٤���ޤ�����",$id, $tId);
}

# �������Ϥ����⤹��
sub logFuneAttack {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��¿��Ƭ�ߥ������ȯ�ͤ���<B>$tName</B>��̿�椷�ޤ�����",$id, $tId);
}

# ŷ���뤬���⤹��
sub logFuneAttackSSS3 {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$lName</B>��<B>���ͥ륮��ˤ</B>��ȯ�ͤ���${HtagName_}$tPoint${H_tagName}��<B>$tName</B>��̿�档�׷���ʤ��᤭���Ӥޤ�����",$id, $tId);
}

# �������Ϥ����⤹��
sub logFuneAttackSSS {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>���ͥ륮��ˤ</B>��ȯ�ͤ���<B>$tName</B>��̿�椷�ޤ�����",$id, $tId);
}

# �������Ϥ����⤹��
sub logFuneAttackSSSR {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$tName</B>��<B>�ڤ�ü����</B>�ˤʤ�ޤ�����",$id, $tId);
}

# �������Ϥ����⤹��
sub logFuneAttackSSST {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��${H_tagName}��<B>$tName</B>��<B>�ڤ�ü����</B>�ˤʤꡢ<B>$lName</B>��${HtagDisaster_}�����С��ҡ���${H_tagDisaster}�ˤ��${HtagDisaster_}����ȯ${H_tagDisaster}���ޤ�����",$id, $tId);
}

# ���ýֻ�
sub logFuneMonsterSea {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�Ͽ᤭���ӿ��פ��ޤ�����",$id);
}

# ���۲�
sub logEggBomb {
    my($id, $name, $lName, $mName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>����<B>$mName</B>���и����ޤ�����",$id);
}

# ��ˡ��ƥ�
sub logMgMeteo {
    my($id, $name, $mName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagDisaster_}�ؼ���ƥ�${H_tagDisaster}�򾧤��ޤ�����",$id);
}

# ��ˡ��������
sub logMgEarthquake {
    my($id, $name, $mName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagDisaster_}��������${H_tagDisaster}�򾧤��ޤ�����",$id);
}

# ��ˡ�ɥ쥤��
sub logMgDrain {
    my($id, $name, $mName, $tName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��<B>$tName</B>���Ф���${HtagDisaster_}�ɥ쥤��${H_tagDisaster}�򾧤��ޤ�����",$id);
}

# ����
sub logShoukan {
my($id, $name, $nName, $mName, $point) = @_;
logOut("<B>$nName</B>��${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagDisaster_}����${H_tagDisaster}���ޤ�����",$id);
}

# ����
sub logNige {
my($id, $name, $lName, $mName, $point) = @_;
logOut("${HtagName_}${name}��$point${H_tagName}��<B>ưʪ��</B>����<B>$mName</B>��${HtagDisaster_}æ��${H_tagDisaster}���ޤ�����",$id);
}

# ����
sub logNige2 {
my($id, $name, $lName, $mName, $point) = @_;
logOut("${HtagName_}${name}��$point${H_tagName}��<B>ưʪ��</B>����<B>$mName</B>��${HtagDisaster_}æ��${H_tagDisaster}�����ޤ�����",$id);
}

# �網��
sub logKyoukou {
    my($id, $name, $mName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagName_}${name}��${H_tagName}��${HtagDisaster_}�網��${H_tagDisaster}��⤿�餷�ޤ�����",$id);
}

# �忩
sub logFushoku {
    my($id, $name, $mName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagName_}${name}��${H_tagName}���ߤ��Ƥ���<B>����</B>��${HtagDisaster_}����${H_tagDisaster}�����Ƥ��ޤä��褦�Ǥ���",$id);
}

# big�޷⡩��
sub logEiseiBigcome {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>�޷����</B>��${HtagName_}${name}��${H_tagName}�˸����äƤ���${HtagDisaster_}�������${H_tagDisaster}������Ȥ����褦�Ǥ�����",$id);
}

# �޷⡩��
sub logEiseicome {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>�޷����</B>��${HtagName_}${name}��${H_tagName}�˸����äƤ���${HtagDisaster_}���${H_tagDisaster}������Ȥ����褦�Ǥ�����",$id);
}

# �������ǡ���
sub logEiseiEnd {
    my($id, $name, $tEiseiname) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$tEiseiname</B>��${HtagDisaster_}����${H_tagDisaster}�����褦�Ǥ�����",$id);
}

# �������ǣ�����
sub logEiseiEndNopop {
    my($id, $name, $tEiseiname) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$tEiseiname</B>��${HtagDisaster_}�ͤ����ʤ��ʤä�${H_tagDisaster}�褦�Ǥ�����",$id);
}

# �������
sub logUmlimit {
    my($id, $name, $mName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��<B>����</B>��${HtagDisaster_}���${H_tagDisaster}���Ƥ��ޤä��褦�Ǥ���",$id);
}

# ��������ﳲ
sub logUmlimitDamage {
    my($id, $name, $mName, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>$mName</B>��${HtagDisaster_}�������줿���ͥ륮��${H_tagDisaster}�ˤ����Ǥ��ޤ�����",$id);
}

# �����ﳲ
sub logEggDamage {
    my($id, $name, $landName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$landName</B>��${HtagDisaster_}��������ˤ�륨�ͥ륮��${H_tagDisaster}�ˤ����פ��ޤ�����",$id);
}

# ���ꥨ��Υ���åȡ�
sub logUrieruMeteo {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�������󤻤�${HtagDisaster_}�����${H_tagDisaster}��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>��������Ӥ����Ǥ��ޤ�����",$id, $tId);
}

# �ᥫ�Υߥ�����
sub logMekaNmiss {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��ȯ�ͤ����ߥ����뤬${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�����Ƥ����Ӥ����Ǥ��ޤ�����",$id, $tId);
}

# �ᥫ�Υ��᡼���ʤ�
sub logMekaNdamage {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��ȯ�ͤ����ߥ����뤬${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�����Ƥ��ޤ�����",$id, $tId);
}

# �ᥫ��¿��Ƭ
sub logMekaSmiss {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��ȯ�ͤ���${HtagDisaster_}¿��Ƭ�ߥ�����${H_tagDisaster}��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�����Ƥ��ޤ�����",$id, $tId);
}

# �ᥫ�Υ��ȥߥå��ܥ�
sub logMekaAB {
  my($id, $name, $lName, $point, $tName, $tPoint) = @_;
  logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��ȯ�ͤ���${HtagDisaster_}���ȥߥå����ܥ�${H_tagDisaster}��${HtagName_}$tPoint${H_tagName}��<B>$tName</B>�����Ƥ�����ȯ���ޤ�����",$id, $tId);
}

# �峤�����ޤ줿
sub logRottenSeaBorn {
    my($id, $name, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>���</B>����<B>�峤</B>�����ޤ�ޤ�����",$id);
}

# �峤�˰��߹��ޤ줿
sub logRottenSeaGrow {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>�峤</B>�˰��߹��ޤ�ޤ�����",$id);
}

# ���Τ�з�
sub logMstakeon {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>�����༣</B>�˸������ޤ�����",$id);
}

# ���Τ鵢��
sub logMstakeokaeri {
    my($id, $name, $lName, $point, $tName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$lName</B>��${HtagName_}$point${H_tagName}��<B>$tName</B>�˵��äƤ��ޤ��������Ĥ��줵�ޡ�",$id);
}

# ���Τ�Ƚ�
sub logMstakeiede {
    my($id, $name, $lName, $point, $tName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$lName</B>�ϵ���٤��Ȥ��ʤ������ι�˽Фޤ�����",$id);
}

# ���Τ��������
sub logMstakeoff {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>�ޥ����åȤ��Τ�</B>»���Τ��᱿�ĺ���ˤʤ�ޤ�����",$id);
}

# �ۼ���ʻ
sub logOwnFac {
    my($id, $name, $lName, $point, $sName) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϼ��Ϥλ��ߤ�ۼ�����<B>$sName��</B>�Ȥʤ�ޤ�����",$id);
}

# �ۼ���ʻ2
sub logOwnFac2 {
    my($id, $name, $lName, $lName2, $point, $sName) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$sName��</B>��<B>$lName2</B>��ۼ���ʻ���ޤ�����",$id);
}

# æ�餷�Ƥߤ�
sub logNuginugi {
    my($id, $name, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>���</B>��æ�餷�ޤ�����",$id);
}

# Φ���˲��ơ��峤��̿��
sub logMsLDSeaRotten {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�����ơ��峤�ϳ������ߤޤ�����",$id, $tId);
}

# Φ��δ���ơ��峤��̿��
sub logMsLRSeaRotten {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>�����ơ��峤��δ�������ˤʤ�ޤ�����",$id, $tId);
}

# ���ƥ륹�ߥ������峤��̿��
sub logMsNormalSRotten {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logSecret("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢�峤�ϾƤ�ʧ���ޤ�����",$id, $tId);
    logLate("{HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢�峤�ϾƤ�ʧ���ޤ�����",$tId);
}

# �̾�ߥ������峤��̿��
sub logMsNormalRotten {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}$tPoint${H_tagName}��<B>$tLname</B>��̿�桢�峤�ϾƤ�ʧ���ޤ�����",$id, $tId);
}

# �졼����̿��
sub logLzrhit {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���<B>$tLname</B>��̿�桢<B>$tLname</B>�ϾƤ�ʧ���ޤ�����",$id, $tId);
}

# �졼����̿��Ǥ⡢��
sub logLzrefc {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ���<B>$tLname</B>��̿�桢<B>$tLname</B>���Ȥ����ʤ�ޤ�����",$id, $tId);
}

# ��ȴۤǤ⡢��
sub logTaishi {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�����",$id, $tId);
}

# ��ѻա���
sub logTaishi2 {
    my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $magickind) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��$point${H_tagName}�����˸�����${HtagComName_}${magickind}${H_tagComName}��Ԥ��ޤ�����",$id, $tId);
}

# ��ȴۤǤ⡢��
sub logKifu {
    my($id, $tId, $name, $tName, $kifu, $kifukin) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�ϻ�������ʤ��ä�<B>$kifukin</B>��${HtagName_}$kifu��ȴ�${H_tagName}�˴��դ��ޤ�����",$id, $tId);
}

# �����ɸ�
sub logMonsSend {
    my($id, $tId, $name, $tName, $mName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>��æ��������${HtagName_}${tName}��${H_tagName}�����ꤳ�ߤޤ�����",$id, $tId);
}

# �����ɸ�
sub logMonsSend2 {
    my($id, $tId, $name, $tName, $mName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>�ϡ�${HtagName_}${tName}��${H_tagName}���ɸ�����ޤ�����",$id, $tId);
}

# ��ⷫ��
sub logDoNothing {
    my($id, $name, $comName) = @_;
#    logOut("${HtagName_}${name}��${H_tagName}��${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ�����",$id);
}

# ͢��
sub logSell {
    my($id, $name, $comName, $value) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$value$HunitFood</B>��${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�����",$id);
}

# ���
sub logAid {
    my($id, $tId, $name, $tName, $comName, $str) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagName_}${tName}��${H_tagName}��<B>$str</B>��${HtagComName_}${comName}${H_tagComName}��Ԥ��ޤ�����",$id, $tId);
}

# Ͷ�׳�ư
sub logPropaganda {
    my($id, $name, $comName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagComName_}${comName}${H_tagComName}���Ԥ��ޤ�����",$id);
}

# ����
sub logGiveup {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}���������졢<B>̵����</B>�ˤʤ�ޤ�����",$id);
    logHistory("${HtagName_}${name}��${H_tagName}����������<B>̵����</B>�Ȥʤ롣");
}

# ����
sub logDead {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}����ͤ����ʤ��ʤꡢ<B>̵����</B>�ˤʤ�ޤ�����",$id);
    logHistory("${HtagName_}${name}��${H_tagName}���ͤ����ʤ��ʤ�<B>̵����</B>�Ȥʤ롣");
}

# ȯ��
sub logDiscover {
    my($name) = @_;
    logHistory("${HtagName_}${name}��${H_tagName}��ȯ������롣");
}

# ̾�����ѹ�
sub logChangeName {
    my($name1, $name2) = @_;
    logHistory("${HtagName_}${name1}��${H_tagName}��̾�Τ�${HtagName_}${name2}��${H_tagName}���ѹ����롣");
}

# ����
sub logStarve {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagDisaster_}��������­${H_tagDisaster}���Ƥ��ޤ�����",$id);
}

# ���ϵ���
sub logStarve2 {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagDisaster_}���Ϥ���­${H_tagDisaster}���Ƥ��ޤ�����",$id);
}

# ���ϵ����ż�
sub logStarve3 {
    my($id, $name, $tname, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$tname</B>��${HtagDisaster_}������­${H_tagDisaster}�ˤ����ߤ��ޤ�������",$id);
}

# ���ǵե���
sub logKire {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>����</B>����̱��${HtagDisaster_}����${H_tagDisaster}�ޤ�������",$id);
}

# �����ѡ���
sub logStarvefood {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>�������ȴ�����ʪ</B>��${HtagDisaster_}������${H_tagDisaster}�����ä��褦�Ǥ�����",$id);
}

# �Էʵ�����
sub logFukeiki {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagDisaster_}�Էʵ�${H_tagDisaster}�ˤ����Ĺ�����ڵ�̣�Τ褦�Ǥ�����",$id);
}

# ˦�ҡ���
sub logRotsick {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>�峤</B>�����߽Ф���<B>˦��</B>��${HtagName_}${name}��${H_tagName}��${HtagDisaster_}����${H_tagDisaster}��⤿�餷���褦�Ǥ�����",$id);
}

# ���¡���
sub logSatansick {
    my($id, $name) = @_;
    logOut("<B>�Ⲧ������</B>��${HtagName_}${name}��${H_tagName}��<B>����</B>��${HtagDisaster_}����${H_tagDisaster}������${HtagName_}${name}��${H_tagName}�Ǥ�${HtagDisaster_}����${H_tagDisaster}��ή�ԤäƤ���褦�Ǥ�����",$id);
}

# ���ø���
sub logMonsCome {
    my($id, $name, $mName, $point, $lName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$mName</B>�и�����${HtagName_}$point${H_tagName}��<B>$lName</B>��Ƨ�߹Ӥ餵��ޤ�����",$id);
}

# ���ø���
sub logMonsCome2 {
    $hcturn = int($HislandTurn/100)*100;
    my($id, $name, $ac, $topvalue) = @_;
    logAuc("${HtagName_}${name}����${H_tagName}��<B>Hakoniwa Auction$hcturn </B>�ˤ�<FONT COLOR=\"MEDIUMSEAGREEN\"><B>$ac</B></font>��<B>$topvalue����</B>�Ǥ��㤤�夲���꤬�Ȥ��������ޤ���",$id);
}

# ���ø���
sub logPrizeAuc2 {
    my($id, $name, $ac, $topvalue) = @_;
    logAuc("${HtagName_}${name}����${H_tagName}��<FONT COLOR=\"royalblue\"><B>$aucshouhinϢ³��󥭥󥰣��̡�</B></font>�ʾ��� <FONT COLOR=\"MEDIUMSEAGREEN\"><B>$ac</B></font>)",$id);
}

# ���ø���
sub logPrizeAuc {
    $hcturn = int($HislandTurn/100)*100;
    my($id, $name, $pName, $value) = @_;
    logAuc("${HtagName_}${name}����${H_tagName}��<B>Hakoniwa Auction$hcturn ������󥭥󥰣��̡�</B>�ʾ޶�<B>$value</B>)",$id);
}

# ���ø���(������)
sub logMonsComemagic {
    my($id, $name, $mName, $point, $lName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}���˲����줿<B>������</B>����<B>$mName</B>�и�����",$id);
}

# ��������
sub logMonsFree {
    my($id, $name, $mName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>����������֤��ޤ�����",$id);
}

# ����ư��
sub logMonsMove {
    my($id, $name, $lName, $point, $mName) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>$mName</B>��Ƨ�߹Ӥ餵��ޤ�����",$id);
}

# ���饤�बʬ������
sub lognewMonsterBorn {
my($id, $name, $point) = @_;
logOut("${HtagName_}${name}��$point${H_tagName}��<B>���饤��</B>��ʬ�����ޤ�����",$id);
}

# �����Ƥ��
sub lognewKaiju {
my($id, $name, $mName, $point) = @_;
logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>����������ޤ�����",$id);
}

# ���á������Ǥ�
sub logMonsBomb {
    my($id, $name, $lName, $point, $mName) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$mName</B>��${HtagDisaster_}���ȥ�����${H_tagDisaster}�򵯤����������ޤ�����",$id);
}

# ���á����Ϥ�Ƥ��Ԥ���
sub logMonsFire {
    my($id, $name, $lName, $point, $mName) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>$mName</B>�ˤ��׷��Ȥǲ��Ǥ��ޤ�����",$id);
}

# ����ǥ󥵤��ä�
sub logConsFire {
    my($id, $name, $lName, $point, $comName) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagComName_}$comName${H_tagComName}��;�ä�����ˤ���å����ܤ���ޤ�����",$id);
}

# ���á����Ϥ���ƿԤ���
sub logMonsCold {
    my($id, $name, $lName, $point, $mName) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>$mName</B>���괬���䵤�ˤ����ƤĤ��ޤ�����",$id);
}

# ���á��ɱһ��ߤ�Ƨ��
sub logMonsMoveDefence {
    my($id, $name, $lName, $point, $mName) = @_;
    logOut("<B>$mName</B>��${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>����ã��<B>${lName}�μ������֤���ư����</B>",$id);
}

# ���á������Ƨ��ǻ�˴�����Τʤ�
sub logMonsMineKill {
    my($id, $name, $lName, $point, $mName) = @_;
    logOut("<B>����$mName</B>��${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��Ƨ�����ȯ��<B>����$mName</B>�Ͼä����Ӥޤ�����",$id);
}

# ���á������Ƨ��ǻ�˴�����Τ���
sub logMonsMineDead {
    my($id, $name, $lName, $point, $mName) = @_;
    logOut("<B>����$mName</B>��${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��Ƨ�����ȯ��<B>����$mName</B>���ϿԤ����ݤ�ޤ�����",$id);
}

# ���á������Ƨ��ǥ��᡼��
sub logMonsMineHit {
    my($id, $name, $lName, $point, $mName) = @_;
    logOut("<B>����$mName</B>��${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��Ƨ�����ȯ��<B>����$mName</B>�϶줷��������Ӭ���ޤ�����",$id);
}

# �к�
sub logFire {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}�к�${H_tagDisaster}�ˤ����Ǥ��ޤ�����",$id);
}
# ϳ��
sub logRouden {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}ϳ��${H_tagDisaster}�򤷤Ƥ���褦�Ǥ���",$id);
}
# ϳ��2
sub logRouden2 {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}���ͥ륮���Х�󥹤��Զѹ�${H_tagDisaster}�ˤʤäƤ���褦�Ǥ���",$id);
}
# �к�̤��
sub logFirenot {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}�к�${H_tagDisaster}�ˤ���ﳲ������ޤ�����",$id);
}

# ��¢��
sub logMaizo {
    my($id, $name, $comName, $value) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�Ǥ�${HtagComName_}$comName${H_tagComName}��ˡ�<B>$value$HunitMoney�����¢��</B>��ȯ������ޤ�����",$id);
}

# ���
sub logGold {
    my($id, $name, $comName, $value) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�Ǥ�${HtagComName_}$comName${H_tagComName}��ˡ�<B>���</B>��ȯ������<B>$value$HunitMoney</B>�����פ�������ޤ�����",$id);
}

# ��
sub logEggFound {
    my($id, $name, $comName, $value) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�Ǥ�${HtagComName_}$comName${H_tagComName}��ˡ�<B>��������</B>��ȯ������${HtagComName_}$comName�ȼ�${H_tagComName}�ˤ��˲���̵���ʤΤ����֤��뤳�Ȥˤ��ޤ�����",$id);
}

# ����
sub logIsekiFound {
    my($id, $name, $comName, $value) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�Ǥ�${HtagComName_}$comName${H_tagComName}��ˡ�<B>�������</B>��ȯ������<B>��ν�����¢ʸ����</B>�˻��ꤵ��ޤ�����",$id);
}

# �Ͽ�ȯ��
sub logEarthquake {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}���絬�Ϥ�${HtagDisaster_}�Ͽ�${H_tagDisaster}��ȯ������",$id);
}

# �����
sub logOmamori {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��ͭ��<B>�����</B>�Τ����Ǥ��礦����${HtagDisaster_}�ﳲ${H_tagDisaster}�����ʤ��ä��褦�Ǥ�����",$id);
}

# ����Хꥢ
sub logOmamori2 {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}���괬��<B>�Хꥢ</B>�Τ�����${HtagDisaster_}�ﳲ${H_tagDisaster}�����ʤ��ä��褦�Ǥ�����",$id);
}

# �Ͽ��ﳲ
sub logEQDamage {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}�Ͽ�${H_tagDisaster}�ˤ����Ǥ��ޤ�����",$id);
}

# �Ͽ��ﳲ̤��
sub logEQDamagenot {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}�Ͽ�${H_tagDisaster}�ˤ���ﳲ������ޤ�����",$id);
}

# ������­�ﳲ
sub logSvDamage {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>��������ƽ�̱������</B>��<B>$lName</B>�ϲ��Ǥ��ޤ�����",$id);
}

# �����ﳲ
sub logKireDamage {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}˽�����̱${H_tagDisaster}�ˤ�ä�${HtagDisaster_}�˲�${H_tagDisaster}����ޤ�����",$id);
}

# ����ȯ��
sub logTsunami {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�ն��${HtagDisaster_}����${H_tagDisaster}ȯ������",$id);
}

# �����ﳲ
sub logTsunamiDamage {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}����${H_tagDisaster}�ˤ���������ޤ�����",$id);
}

# ����ȯ��
sub logTyphoon {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagDisaster_}����${H_tagDisaster}��Φ����",$id);
}

# �����ﳲ
sub logTyphoonDamage {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}����${H_tagDisaster}�����Ф���ޤ�����",$id);
}

# �����ﳲ����
sub logTyphoonHason {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}����${H_tagDisaster}�ˤ�ä���»���ޤ�����",$id);
}

# ��С���
sub logMeteoSea {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}���${H_tagDisaster}������ޤ�����",$id);
}

# ��С���
sub logMeteoMountain {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}���${H_tagDisaster}�����<B>$lName</B>�Ͼä����Ӥޤ�����",$id);
}

# ��С��������
sub logMeteoSbase {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��${HtagDisaster_}���${H_tagDisaster}�����<B>$lName</B>���������ޤ�����",$id);
}

# ��С�����
sub logMeteoMonster {
    my($id, $name, $lName, $point) = @_;
    logOut("<B>$lName</B>������${HtagName_}${name}��$point${H_tagName}������${HtagDisaster_}���${H_tagDisaster}�����Φ�Ϥ�<B>$lName</B>����Ȥ���פ��ޤ�����",$id);
}

# ��С�����
sub logMeteoSea1 {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������${HtagDisaster_}���${H_tagDisaster}��������줬�������ޤ�����",$id);
}

# ��С�����¾
sub logMeteoNormal {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������<B>$lName</B>��${HtagDisaster_}���${H_tagDisaster}��������Ӥ����פ��ޤ�����",$id);
}

# ��С�����¾
sub logHugeMeteo {
    my($id, $name, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������${HtagDisaster_}�������${H_tagDisaster}�������",$id);
}
# ��С�����¾
sub logMidMeteo {
    my($id, $name, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������${HtagDisaster_}������${H_tagDisaster}�������",$id);
}
# ��С�����¾
sub logMidMeteo2 {
    my($id, $name, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������${HtagDisaster_}������${H_tagDisaster}����������ޤ����������Ϥ�<b>�ɱһ��ߡ���</b>���ɱҤ����褦�Ǥ���",$id);
}
# ��С�����¾
sub logMidMeteo3 {
    my($id, $name, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������${HtagDisaster_}���${H_tagDisaster}����������ޤ����������Ϥ�<b>�ɱһ��ߡ���</b>���ɱҤ����褦�Ǥ���",$id);
}
# ��С�����¾
sub logHugeMeteo4 {
    my($id, $name, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������${HtagDisaster_}���${H_tagDisaster}�������",$id);
}

# ʮ��
sub logEruption {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������${HtagDisaster_}�л���ʮ��${H_tagDisaster}��<B>��</B>������ޤ�����",$id);
}

# ʮ�С�����
sub logEruptionSea1 {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������<B>$lName</B>�ϡ�${HtagDisaster_}ʮ��${H_tagDisaster}�αƶ���Φ�Ϥˤʤ�ޤ�����",$id);
}

# ʮ�С���or����
sub logEruptionSea {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������<B>$lName</B>�ϡ�${HtagDisaster_}ʮ��${H_tagDisaster}�αƶ��ǳ��줬δ���������ˤʤ�ޤ�����",$id);
}

# ʮ�С�����¾
sub logEruptionNormal {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}������<B>$lName</B>�ϡ�${HtagDisaster_}ʮ��${H_tagDisaster}�αƶ��ǲ��Ǥ��ޤ�����",$id);
}

# ��������ȯ��
sub logFalldown {
    my($id, $name) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��${HtagDisaster_}��������${H_tagDisaster}��ȯ�����ޤ�������",$id);
}

# ���������ﳲ
sub logFalldownLand {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϳ���������ߤޤ�����",$id);
}

# �����ﳲ������
sub logWideDamageSea {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>����</B>���ޤ�����",$id);
}

# �����ﳲ�����η���
sub logWideDamageSea2 {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>���׷���ʤ��ʤ�ޤ�����",$id);
}

# �����ﳲ�����ÿ���
sub logWideDamageMonsterSea {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��Φ�Ϥ�<B>$lName</B>����Ȥ���פ��ޤ�����",$id);
}

# �����ﳲ������
sub logWideDamageMonster {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�Ͼä����Ӥޤ�����",$id);
}

# �����ﳲ������
sub logWideDamageWaste {
    my($id, $name, $lName, $point) = @_;
    logOut("${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>�ϰ�֤ˤ���<B>����</B>�Ȳ����ޤ�����",$id);
}

# ����
sub logPrize {
    my($id, $name, $pName) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$pName</B>����ޤ��ޤ�����",$id);
    logHistory("${HtagName_}${name}��${H_tagName}��<B>$pName</B>�����");
}

# ����
sub logPrizet {
    my($id, $name, $pName, $value) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��<B>$pName</B>����ޤ��ޤ�����",$id);
    logHistory("${HtagName_}${name}��${H_tagName}��<B>$pName</B>����ޡʾ޶�<B>$value</B>)");
}

# Ȣ�����å�
sub logHC {
    my($id, $name, $stsanka) = @_;
    logHistory("${HtagName_}Hakoniwa Cup$HislandTurn${H_tagName}���š����ÿ�$stsanka�硪");
    logHcup("${HtagName_}Hakoniwa Cup$HislandTurn${H_tagName}���š����ÿ�$stsanka�硪");
}

# Ȣ�����å׳���
sub logHCstart {
    my($id, $name, $str) = @_;
    logHistory("${HtagName_}${name}��${H_tagName}��<B>Hakoniwa Cup����</B>���Ԥʤ�졢<B>$str</B>�ηкѸ��̤򴬤��������ޤ�����",$id);
    logHcup("${HtagName_}${name}��${H_tagName}��<B>Hakoniwa Cup����</B>���Ԥʤ�졢<B>$str</B>�ηкѸ��̤򴬤��������ޤ�����",$id);
}

# Ȣ�����å׻��
sub logHCgame {
    my($id, $tId, $name, $tName, $lName, $gName, $goal, $tgoal) = @_;
    logLate("${HtagName_}${name}��${H_tagName}��<B>$gName</B>���Ԥ��ޤ�����${HtagName_}${name}����ɽ${H_tagName}<B>VS</B>${HtagName_}${tName}����ɽ${H_tagName} �� <B>$goal��$tgoal</B>",$id, $tId);
    logHcup("${HtagName_}${gName}${H_tagName}��${HtagName_}${name}����ɽ${H_tagName}<B>VS</B>${HtagName_}${tName}����ɽ${H_tagName} �� <B>$goal��$tgoal</B>",$id, $tId);
}

# Ȣ�����å׾���
sub logHCwin {
    my($id, $name, $cName, $str) = @_;
    logLate("${HtagName_}${name}����ɽ${H_tagName}�ϡ�<B>$str</B>��������ޤ�����",$id);
}

# Ȣ�����å�ͥ��
sub logHCwintop {
    my($id, $name, $cName) = @_;
    logHistory("${HtagName_}${name}����ɽ${H_tagName}��<B>Hakoniwa Cup$cNameͥ����</B>",$id);
    logHcup("${HtagName_}${name}����ɽ${H_tagName}��<B>Hakoniwa Cup$cNameͥ����</B>",$id);
}

# Ȣ�����å����ﾡ
sub logHCantiwin {
    my($id, $name, $gName) = @_;
    logLate("${HtagName_}${name}����ɽ${H_tagName}��<B>���������</B>�����ʤ�����<B>$gName</B>�Ȥʤ�ޤ�����",$id);
    logHcup("${HtagName_}${name}����ɽ${H_tagName}��<B>���������</B>�����ʤ�����<B>$gName</B>��",$id);
}

# Ȣ�����å�
sub logHCsin {
    my($id, $name, $stsin) = @_;
    logHistory("${HtagName_}Hakoniwa Cup�辡�ȡ��ʥ��ȿʽ���!!${H_tagName}<br><font size=\"-1\"><B>$stsin</B></font>");
    logHcup("${HtagName_}Hakoniwa Cup�辡�ȡ��ʥ��ȿʽ���!!${H_tagName}<br><font size=\"-1\"><B>$stsin</B></font>");
}

# �礬���äѤ��ʾ��
sub tempNewIslandFull {
    out(<<END);
${HtagBig_}����������ޤ����礬���դ���Ͽ�Ǥ��ޤ��󡪡�${H_tagBig}$HtempBack
END
}

# ������̾�����ʤ����
sub tempNewIslandNoName {
    out(<<END);
${HtagBig_}���Ϥ��Խ�ʬ�Ǥ���${H_tagBig}$HtempBack
END
}

# ������̾���������ʾ��
sub tempNewIslandBadName {
    out(<<END);
${HtagBig_}',?()<>\$'�Ȥ����äƤ��ꡢ��̵����פȤ����ä��Ѥ�̾���Ϥ��ޤ��礦���${H_tagBig}$HtempBack
END
}

# ���Ǥˤ���̾�����礬������
sub tempNewIslandAlready {
    out(<<END);
${HtagBig_}������ʤ餹�Ǥ�ȯ������Ƥ��ޤ���${H_tagBig}$HtempBack
END
}

# ���Ǥ�Ʊ���ɣФ��礬������
sub tempIPIslandAlready {
    out(<<END);
${HtagBig_}���ʤ���Ʊ���ɣФ��礬���Ǥ�ȯ������Ƥ��ޤ���<br>��ʣ��Ͽ�ɻߤˤ����Ϥ���������${H_tagBig}$HtempBack
END
}

# �ѥ���ɤ��ʤ����
sub tempNewIslandNoPassword {
    out(<<END);
${HtagBig_}�ѥ���ɤ�ɬ�פǤ���${H_tagBig}$HtempBack
END
}

# ���ȯ�����ޤ���!!
sub tempNewIslandHead {
    out(<<END);
<CENTER>
${HtagBig_}���ȯ�����ޤ�������${H_tagBig}<BR>
${HtagBig_}${HtagName_}��${HcurrentName}���${H_tagName}��̿̾���ޤ���${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}

# �Ϸ��θƤ���
sub landName {
    my($land, $lv) = @_;

    if($land == $HlandSea) {
	if($lv == 1) {
            return '����';
        } else {
            return '��';
	}
    } elsif($land == $HlandIce) {
	if($lv > 0) {
            return 'ŷ���������Ⱦ�';
        } else {
            return 'ɹ��';
	}
    } elsif($land == $HlandWaste) {
	return '����';
    } elsif($land == $HlandPlains) {
	return 'ʿ��';
    } elsif($land == $HlandPlains2) {
	return '��ȯͽ����';
    } elsif($land == $HlandTown) {
	if($lv < 30) {
	    return '¼';
	} elsif($lv < 100) {
	    return 'Į';
	} else {
	    return '�Ի�';
	}
    } elsif($land == $HlandProcity) {
	return '�ɺ��Ի�';
    } elsif($land == $HlandNewtown) {
	return '�˥塼������';
    } elsif($land == $HlandBigtown) {
	return '�����Ի�';
    } elsif($land == $HlandBettown) {
	return '�������Ի�';
    } elsif($land == $HlandSkycity) {
	return '�����Ի�';
    } elsif($land == $HlandUmicity) {
	return '���Ի�';
    } elsif($land == $HlandSeatown) {
	return '���쿷�Ի�';
    } elsif($land == $HlandRizort) {
	return '�꥾������';
    } elsif($land == $HlandKajino) {
	return '������';
    } elsif($land == $HlandBigRizort) {
	return '�׳��꥾���ȥۥƥ�';
    } elsif($land == $HlandShuto) {
	return '����';
    } elsif($land == $HlandUmishuto) {
	return '�������';
    } elsif($land == $HlandForest) {
	return '��';
    } elsif($land == $HlandFarm) {
	return '����';
    } elsif($land == $HlandEneAt) {
	return '������ȯ�Ž�';
    } elsif($land == $HlandEneFw) {
	return '����ȯ�Ž�';
    } elsif($land == $HlandEneWt) {
	return '����ȯ�Ž�';
    } elsif($land == $HlandEneWd) {
	return '����ȯ�Ž�';
    } elsif($land == $HlandEneBo) {
	return '�Х����ޥ�ȯ�Ž�';
    } elsif($land == $HlandEneSo) {
	return '�����顼ȯ�Ž�';
    } elsif($land == $HlandEneCs) {
	return '������ȯ�Ž�';
    } elsif($land == $HlandConden) {
	return '����ǥ�';
    } elsif($land == $HlandConden2) {
	return '����ǥ󥵡���';
    } elsif($land == $HlandConden3) {
	return '����Υ���ǥ�';
    } elsif($land == $HlandConden4) {
	if($lv == 3) {
	    return '����Υ���ǥ�(ϳ����)';
	} elsif($lv == 2) {
	    return '����ǥ󥵡���(ϳ����)';
	} elsif($lv == 99) {
	    return '��ͻ��ȯ�Ž�';
	} else {
	    return '����Υ���ǥ�(ϳ����)';
	}
    } elsif($land == $HlandFoodka) {
	return '���ʲù�����';
    } elsif($land == $HlandFoodim) {
	if($lv < 480) {
	    return '��ʪ�����';
	} else {
	    return '�ɺҷ���ʪ�����';
	}
    } elsif($land == $HlandFarmchi) {
	return '�ܷܾ�';
    } elsif($land == $HlandFarmpic) {
	return '���ھ�';
    } elsif($land == $HlandFarmcow) {
	return '�Ҿ�';
    } elsif($land == $HlandYakusho) {
	return '�����';
    } elsif($land == $HlandCollege) {
	if($lv == 0) {
	    return '�������';
	} elsif($lv == 1) {
	    return '�������';
	} elsif($lv == 2) {
	    return '�������';
	} elsif($lv == 3) {
	    return '�������';
	} elsif($lv == 4) {
	    return '��ʪ���(�Ե���)';
	} elsif($lv == 98) {
	    return '��ʪ���(�Ե���)';
	} elsif($lv == 96) {
	    return '��ʪ���(�ж���)';
	} elsif($lv == 97) {
	    return '��ʪ���(�ж���)';
	} elsif($lv == 99) {
	    return '��ʪ���(��ư��)';
	} elsif($lv == 5) {
	    return '�������';
	} elsif($lv == 6) {
	    return '�к����';
	} elsif($lv == 7) {
	    return '��ˡ�ع�';
	} elsif($lv == 8) {
	    return '�Ź����';
	} elsif($lv == 77) {
	    return 'ʸ���ʳؾ�';
	} elsif($lv == 78) {
	    return 'ʸ���ʳؾ�';
	} elsif($lv == 79) {
	    return 'ʸ���ʳؾ�';
	} elsif($lv == 80) {
	    return 'ʸ���ʳؾ�';
	} elsif($lv == 95) {
	    return '�к����(������)';
	} else {
	    return '�������';
	}
    } elsif($land == $HlandHouse) {
	if($lv == 0) {
	    return '����';
	} elsif($lv == 1) {
	    return '�ʰ׽���';
	} elsif($lv == 2) {
	    return '����';
	} elsif($lv == 3) {
	    return '��齻��';
	} elsif($lv == 4) {
	    return '��š';
	} elsif($lv == 5) {
	    return '���š';
	} elsif($lv == 6) {
	    return '����š';
	} elsif($lv == 7) {
	    return '��';
	} elsif($lv == 8) {
	    return '���';
	} else {
	    return '�����';
	}
    } elsif($land == $HlandTrain) {
	if($lv == 0) {
	    return '��';
	} elsif($lv < 10) {
	    return '��ϩ';
	} elsif($lv == 10) {
	    return '��(�����ż������)';
	} elsif($lv < 20) {
	    return '�����ż�';
	} elsif($lv == 20) {
	    return '��(��ʪ��������)';
	} elsif($lv < 30) {
	    return '��ʪ���';
	}
    } elsif($land == $HlandTaishi) {
	return '��ȴ�';
    } elsif($land == $HlandKura) {
	return '�Ҹ�';
    } elsif($land == $HlandKuraf) {
	return '�Ҹ�';
    } elsif($land == $HlandFactory) {
	return '����';
    } elsif($land == $HlandHTFactory) {
	return '�ϥ��ƥ�¿���Ҵ��';
    } elsif($land == $HlandSHTF) {
	return '�ϥ��ƥ�¿���Ҵ�ȡ���';
    } elsif($land == $HlandOWNF) {
	return '��Ĵ��';
    } elsif($land == $HlandBase) {
	return '�ߥ��������';
    } elsif($land == $HlandDefence) {
	if($lv == 77) {
	    return '�ɱһ��ߡ���';
	} else {
	    return '�ɱһ���';
	}
    } elsif($land == $HlandMountain) {
	return '��';
    } elsif($land == $HlandGold) {
	return '�⻳';
    } elsif($land == $HlandOnsen) {
	return '������';
    } elsif($land == $HlandMonster) {
	my($kind, $name, $hp) = monsterSpec($lv);
	return $name;
    } elsif($land == $HlandSbase) {
	return '�������';
    } elsif($land == $HlandSeacity) {
	return '�����Ի�';
    } elsif($land == $HlandOil) {
	return '��������';
    } elsif($land == $HlandMonument) {
	return $HmonumentName[$lv];
    } elsif($land == $HlandHaribote) {
	return '�ϥ�ܥ�';
    } elsif($land == $HlandPark) {
        return 'ͷ����';
    } elsif($land == $HlandMinato) {
	return '��Į';
    } elsif($land == $HlandFune) {
	return $HfuneName[$lv];
    } elsif($land == $HlandFrocity) {
	return '�����Ի�';
    } elsif($land == $HlandSunahama) {
	return '����';
    } elsif($land == $HlandMine) {
        return '����';
    } elsif($land == $HlandNursery) {
        return '�ܿ���';
    } elsif($land == $HlandKyujo) {
        return '����';
    } elsif($land == $HlandKyujokai) {
        return '¿��Ū����������';
    } elsif($land == $HlandZoo) {
        return 'ưʪ��';
    } elsif($land == $HlandUmiamu) {
        return '�����ߤ�';
    } elsif($land == $HlandSeki) {
	return '�ؽ�';
    } elsif($land == $HlandRottenSea) {
	if($lv < 20) {
	    return '�峤';
	} else {
	    return '�ϻ೤';
	}
    }
}

# �͸�����¾���ͤ򻻽�
sub estimate {
    my($number) = $_[0];
    my($island);
    my($pop, $area, $farm, $mountain) = (0, 0, 0, 0);
    my($factory1, $factory2) = (0, 0);
    my($monslive, $monslivetype) = (0, 0);
    my($kei, $rena, $fore, $tare, $zipro, $leje) = (0, 0, 0, 0, 0, 0);
    my($oil) = (0);
    my($bas) = (0);
    my($kyu) = (0);
    my($amu) = (0);
    my($par) = (0);
    my($riz) = (0);
    my($fim) = (0);
    my($rot) = (0);
    my($sci) = (0);
    my($sba) = (0);
    my($pro) = (0);
    my($kin) = (0);
    my($nto) = (0);
    my($m26) = (0);
    my($m27) = (0);
    my($m17) = (0);
    my($c11) = (0);
    my($c13) = (0);
    my($c21) = (0);
    my($c28) = (0);
    my($c23) = (0);
    my($co0) = (0);
    my($co1) = (0);
    my($co2) = (0);
    my($co3) = (0);
    my($co4) = (0);
    my($co5) = (0);
    my($co6) = (0);
    my($co7) = (0);
    my($co8) = (0);
    my($co99) = (0);
    my($co77) = (0);
    my($co78) = (0);
    my($co79) = (0);
    my($co80) = (0);
    my($yaku) = (0);
    my($co01) = (0);
    my($co95) = (0);
    my($tet) = (0);
    my($hot) = (0);
    my($hou) = (0);
    my($shu) = (0);
    my($sin) = (0);
    my($jin) = (0);
    my($m74) = (0);
    my($m75) = (0);
    my($m76) = (0);
    my($m77) = (0);
    my($m78) = (0);
    my($m79) = (0);
    my($m84) = (0);
    my($m93) = (0);
    my($m96) = (0);
    my($m97) = (0);
    my($m98) = (0);
    my($m99) = (0);
    my($m100) = (0);
    my($m101) = (0);
    my($m73) = (0);
    my($gyo) = (0);
    my($ky2) = (0);
    my($zoo) = (0);
    my($htf) = (0);
    my($shtf) = (0);
    my($ownf) = (0);
    my($tai) = (0);
    my($tra) = (0);
    my($tra1) = (0);
    my($tra2) = (0);
    my($ene) = (0);
    my($h10) = (0);
    my($h11) = (0);
    my($con99) = (0);
    my($choki2) = (0);
    my($ownfe) = (0);

    # �Ϸ������
    $island = $Hislands[$number];
    my($land) = $island->{'land'};
    my($landValue) = $island->{'landValue'};

    $etc5 = $island->{'etc5'};
    $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

    if ($island->{'fukeikimoney'} < $island->{'money'}) {
	$island->{'fukeikimoney'} = $island->{'money'};
    }

    # ������
    my($x, $y, $kind, $value);
    for($y = 0; $y < $HislandSize; $y++) {
	for($x = 0; $x < $HislandSize; $x++) {
	    $kind = $land->[$x][$y];
	    $value = $landValue->[$x][$y];
	    my($mKind, $mName, $mHp) = monsterSpec($value);
	    if(($kind != $HlandSea) &&
	       ($kind != $HlandIce) &&
	       ($kind != $HlandSbase) &&
	       ($kind != $HlandFune) &&
	       ($kind != $HlandFrocity) &&
	       ($kind != $HlandUmicity) &&
               ($kind != $HlandNursery) &&
               ($kind != $HlandUmiamu) &&
               ($kind != $HlandSeacity) &&
               ($kind != $HlandSeatown) &&
               ($kind != $HlandUmishuto) &&
	       ($kind != $HlandOil)){
		$area++;
		if(($kind == $HlandTown) ||
		   ($kind == $HlandProcity) ||
		   ($kind == $HlandOnsen) ||
		   ($kind == $HlandShuto) ||
		   ($kind == $HlandMinato)) {
		    # Į
		    $pop += $value;
		} elsif(($kind == $HlandFarm) ||
			($kind == $HlandFoodim)) {
		    # ����
		    $farm += $value;
		} elsif(($kind == $HlandFoodka) && ($value > 0)) {
		    $factory1 += $value*200;
		    $farm += $value*200;
		} elsif($kind == $HlandFarmchi) {
		    $tare += $value;
		    $factory1 += int($value/100)+1;
		} elsif($kind == $HlandFarmpic) {
		    $zipro += $value;
		    $factory1 += int($value/80)+1;
		} elsif($kind == $HlandFarmcow) {
		    $leje += $value;
		    $factory1 += int($value/50)+1;
		} elsif(($kind == $HlandFactory) ||
			($kind == $HlandHTFactory) ||
			($kind == $HlandPark)) {
		    # ����
		    $factory1 += $value;
		} elsif($kind == $HlandSHTF) {
		    $factory2 += $value;
		} elsif($kind == $HlandOWNF) {
		    $ownfe = int($value/1000);
		    $factory2 += int($value/100)%10*250;
		    $factory1 += int($value%100/10)*250;
		    $farm += $value%10*250;
		} elsif(($kind == $HlandMountain) ||
			($kind == $HlandGold)) {
		    # ��
		    $mountain += $value;
		} elsif($kind == $HlandForest) {
		    $fore += $value;
		} elsif($kind == $HlandNewtown) {
		    # �˥塼������
		    $pop += $value;
		    $nwork =  int($value/15);
		    $factory1 += $nwork;
		} elsif($kind == $HlandBigtown) {
		    # �����Ի�
		    $pop += $value;
		    $mwork =  int($value/20);
		    $lwork =  int($value/30);
		    $factory1 += $mwork;
		    $farm += $lwork;
		} elsif($kind == $HlandBettown) {
		    # �������Ի�
		    $pop += $value;
		} elsif($kind == $HlandSkycity) {
		    # �����Ի�
		    $pop += $value;
		    $factory2 += int($value/60);
		    $farm += int($value/60);
		    $island->{'shouhi'} += int($value/2*(100-$s02)/100);
		} elsif($kind == $HlandRizort) {
		    # �꥾������
		    $pop += $value;
		} elsif($kind == $HlandKajino) {
		    # �꥾������
		    $pop += $value;
		    $island->{'shouhi'} += int($value/10*(100-$s02)/100);
		} elsif($kind == $HlandBigRizort) {
		    # �꥾������
		    $pop += $value;
		} elsif($kind == $HlandBase) {
		    # ����
		    $bas += $value;
		    $rena += $value;
		    $island->{'shouhi'} += int($value/4*(100-$s02)/100);
		}
            } elsif ($kind == $HlandNursery) {
                # �ܿ��������ΰ��
                $farm += $value;
            } elsif ($kind == $HlandUmiamu) {
                $factory1 += $value;
            } elsif ($kind == $HlandSeacity) {
                $pop += $value;
            } elsif ($kind == $HlandFrocity) {
                $pop += $value;
            } elsif ($kind == $HlandUmicity) {
                $pop += $value;
		$factory2 += int($value/60);
		$farm += int($value/60);
		$island->{'shouhi'} += int($value/2*(100-$s02)/100);
            } elsif ($kind == $HlandUmishuto) {
                $pop += $value;
            } elsif ($kind == $HlandSeatown) {
                $pop += $value;
		    $owork =  int($value/40);
		    $factory1 += $owork;
		    $farm += $owork;
            } elsif ($kind == $HlandSbase) {
                $bas += $value;
		$rena += $value;
		$island->{'shouhi'} += int($value/2*(100-$s02)/100);
	    }

            $oil++ if ($kind == $HlandOil);
            $htf++ if ($kind == $HlandHTFactory);
            $shtf++ if ($kind == $HlandSHTF);
            $ownf++ if ($kind == $HlandOWNF);
            $kei++ if ($kind == $HlandMonument);
            $kyu++ if ($kind == $HlandKyujo);
            $kyu++ if ($kind == $HlandKyujokai);
            $ky2++ if ($kind == $HlandKyujokai);
            $zoo++ if ($kind == $HlandZoo);
            $amu++ if ($kind == $HlandUmiamu);
            $par++ if ($kind == $HlandPark);
            $riz++ if ($kind == $HlandRizort);
            $riz++ if ($kind == $HlandKajino);
            $fim++ if (($kind == $HlandFoodim) && ($value < 480));
            $rot++ if (($kind == $HlandRottenSea) && ($value < 20));
            $sci++ if ($kind == $HlandSeacity);
            $sci++ if ($kind == $HlandSeatown);
            $sci++ if ($kind == $HlandSeatown);
            $sba++ if ($kind == $HlandSbase);
            $pro++ if ($kind == $HlandProcity);
            $pro++ if ($kind == $HlandFrocity);
            $kin++ if ($kind == $HlandGold);
            $nto++ if ($kind == $HlandNewtown);
            $m73++ if (($kind == $HlandMonument) && ($value == 73));
            $m96++ if (($kind == $HlandMonument) && ($value == 96));
            $m97++ if (($kind == $HlandMonument) && ($value == 97));
            $m98++ if (($kind == $HlandMonument) && ($value == 98));
            $m99++ if (($kind == $HlandMonument) && ($value == 99));
            $m100++ if (($kind == $HlandMonument) && ($value == 100));
            $m101++ if (($kind == $HlandMonument) && ($value == 101));
            $m26++ if (($kind == $HlandMonument) && ($value == 86));
            $m27++ if (($kind == $HlandMonument) && ($value == 87));
            $m74++ if (($kind == $HlandMonument) && ($value == 74));
            $m75++ if (($kind == $HlandMonument) && ($value == 75));
            $m76++ if (($kind == $HlandMonument) && ($value == 76));
            $m77++ if (($kind == $HlandMonument) && ($value == 77));
            $m78++ if (($kind == $HlandMonument) && ($value == 78));
            $m79++ if (($kind == $HlandMonument) && ($value == 79));
            $m84++ if (($kind == $HlandMonument) && ($value == 84));
            $m93++ if (($kind == $HlandHouse) && ($value == 10));
            $m93++ if (($kind == $HlandHouse) && ($value == 11));
            $h10++ if (($kind == $HlandHouse) && ($value == 10));
            $h11++ if (($kind == $HlandHouse) && ($value == 11));
            $m17++ if (($kind == $HlandMonument) && ($value == 17));
            $m17++ if ($kind == $HlandEneCs);
            $sin++ if (($kind == $HlandMonument) && ($value == 26));
            $jin++ if (($kind == $HlandMonument) && ($value == 27));
            $c11++ if (($kind == $HlandMonster) && ($mKind == 11));
            $c13++ if (($kind == $HlandMonster) && ($mKind == 13));
            $c13++ if (($kind == $HlandMonument) && ($value == 93));
            $c21++ if (($kind == $HlandMonster) && ($mKind == 21));
            $c28++ if (($kind == $HlandMonster) && ($mKind == 28));
            $c28++ if (($kind == $HlandMonster) && ($mKind == 30));
            $c23++ if (($kind == $HlandMonster) && ($mKind == 23));
            $co0++ if (($kind == $HlandCollege) && ($value == 0));
            $co1++ if (($kind == $HlandCollege) && ($value == 1));
            $co01++ if (($kind == $HlandCollege) && ($value == 1));
            $co1++ if (($kind == $HlandCollege) && ($value == 8));
            $co2++ if (($kind == $HlandCollege) && ($value == 2));
            $co1++ if (($kind == $HlandCollege) && ($value == 2));
            $co0++ if (($kind == $HlandCollege) && ($value == 2));
            $co3++ if (($kind == $HlandCollege) && ($value == 3));
            $co4++ if (($kind == $HlandCollege) && ($value == 4));
            $co4++ if (($kind == $HlandCollege) && ($value == 98));
            $co4++ if (($kind == $HlandCollege) && ($value == 97));
            $co4++ if (($kind == $HlandCollege) && ($value == 96));
            $co99++ if (($kind == $HlandCollege) && ($value == 99));
            $co5++ if (($kind == $HlandCollege) && ($value == 5));
            $co6++ if (($kind == $HlandCollege) && ($value == 6));
            $co6++ if (($kind == $HlandCollege) && ($value == 95));
            $co95++ if (($kind == $HlandCollege) && ($value == 95));
            $co7++ if (($kind == $HlandCollege) && ($value == 7));
            $co8++ if (($kind == $HlandCollege) && ($value == 8));
            $co77++ if (($kind == $HlandCollege) && ($value == 77));
            $co77++ if (($kind == $HlandCollege) && ($value == 78));
            $co77++ if (($kind == $HlandCollege) && ($value == 79));
            $co77++ if (($kind == $HlandCollege) && ($value == 80));
            $co78++ if (($kind == $HlandCollege) && ($value == 78));
            $co79++ if (($kind == $HlandCollege) && ($value == 79));
            $co80++ if (($kind == $HlandCollege) && ($value == 80));
            $yaku++ if ($kind == $HlandYakusho);
            $tet++ if (($kind == $HlandCollege) && ($value == 98));
            $tet++ if (($kind == $HlandCollege) && ($value == 97));
            $tet++ if (($kind == $HlandMonster) && ($mKind == 30));
            $hot++ if ($kind == $HlandOnsen);
            $hou++ if ($kind == $HlandHouse);
            $tai++ if ($kind == $HlandTaishi);
            $shu++ if ($kind == $HlandShuto);
            $shu++ if ($kind == $HlandUmishuto);
            $gyo++ if (($kind == $HlandFune) && ($value == 1));
            $gyo++ if (($kind == $HlandFune) && ($value == 2));
            $gyo++ if (($kind == $HlandFune) && ($value == 5));
            $gyo++ if (($kind == $HlandFune) && ($value == 6));
            $gyo++ if (($kind == $HlandFune) && ($value == 11));
            $tra++ if ($kind == $HlandTrain);
            $tra1++ if (($kind == $HlandTrain) && (($value == 10) || ($value == 11) || ($value == 12) || ($value == 13) || ($value == 14) || ($value == 15) || ($value == 16) || ($value == 17) || ($value == 18) || ($value == 19)));
            $tra2++ if (($kind == $HlandTrain) && (($value == 20) || ($value == 21) || ($value == 22) || ($value == 23) || ($value == 24) || ($value == 25) || ($value == 26) || ($value == 27) || ($value == 28) || ($value == 29)));

	    if($kind == $HlandEneAt) {
		    $ene += $value;
	    }
	    if($kind == $HlandEneBo) {
		    $ene += $value;
	    }
	    if($kind == $HlandEneWt) {
		    $ene += int($value*(random(80)+70)/100);
			if($island->{'Typhoonflag'} == 1) {
			$ene += int($value*(random(80)+70)/100);
			}
	    }
	    if(($kind == $HlandEneSo) && ($island->{'Typhoonflag'} != 1)) {
		    $ene += int($value*(random(25)+75)/100);
	    }
	    if($kind == $HlandEneWd) {
		    $ene += int($value*(random(75)+50)/100);
			if($island->{'Typhoonflag'} == 1) {
			$ene += int($value*(random(75)+50)/100);
			}
	    }
	    if(($kind == $HlandEneFw) && ($island->{'oil'} > 0)) {
		    $ene += $value;
		    $ene += $value;
	    } elsif(($kind == $HlandEneFw) && ($island->{'mountain'} > 0)) {
		    $ene += $value;
	    }
	    if(($kind == $HlandEneCs) && ($island->{'eis7'} > 0)) {
		    $ene += $value;
	    }
	    if(($kind == $HlandConden4) && ($value == 99)) {
		    $con99++;
	    }
	    if($kind == $HlandConden) {
		    $ene += $value;
		    $landValue->[$x][$y] = 0;
	    }
	    if($kind == $HlandConden2) {
		    $ene += $value;
		    $landValue->[$x][$y] = 0;
	    }
	    if($kind == $HlandConden3) {
		    $ene += $value;
		    $ene += $value;
		    $landValue->[$x][$y] = 0;
	    }

            if ($kind == $HlandMonster) {
                my($mKind, $mName, $mHp) = monsterSpec($value);
                $monslive++;
                $monslivetype |= (2 ** $mKind);
            }

            if ($kind == $HlandTaishi) {
	    my($tn) = $HidToNumber{$value};
	    my($tIsland) = $Hislands[$tn];
	        if ($tIsland->{'money'} > $island->{'money'}) {
		    $island->{'fukeikimoney'} = $tIsland->{'money'};
	        }
            }

            if ($kind == $HlandKura) {
		$seq = int($value/100);
		$choki = $value%100;
		$choki2 += $choki;
            }

	}
    }


    if($con99 > 0) {
	    $magicl = $m79 + int($m100/2);
	    $magica = $m75 + int($m98/2);
		if ($island->{'h10'} > 0) {
		    $magicf += 10;
		    $magici += 10;
		    $magica += 10;
		    $magicw += 10;
		    $magicd += 10;
		}
		if ($island->{'h11'} > 0) {
		    $magicl += 10;
		}
	    if($magica != $magicl) {
		$ene += random($magicl*15000+50000);
		$ene -= int(random($magicl*15000+50000) * (50-$s02)/50);
	    } else {
		$ene += $magicl*15000+50000+$s02*1000;
	    }
    }


    if($island->{'eis7'} >= 1) {
	$eis7 = $island->{'eis7'};
	$cstpop = int($eis7/100);
	$csten = $eis7%100;
	$pop += $cstpop;
    }


    # ����
    $island->{'pop'}      = $pop;
    $island->{'area'}     = $area;
    $island->{'farm'}     = $farm;
    $island->{'factory'}  = "$factory1,$factory2,$co0,$co1,$htf,$shtf,$co95,$co95,$co95,$co95";
    $island->{'factory1'}  = $factory1;
    $island->{'factory2'}  = $factory2;
    $island->{'factoryt'}  = $factory1+$factory2;
    $island->{'mountain'} = $mountain;

    $island->{'oil'}      = $oil;
    $island->{'bas'}      = $bas;
    $island->{'kyu'}      = $kyu;
    $island->{'ky2'}      = $ky2;
    $island->{'zoo'}      = $zoo;
    $island->{'amu'}      = $amu;
    $island->{'par'}      = $par;
    $island->{'riz'}      = $riz;
    $island->{'fim'}      = $fim;
    $island->{'rot'}      = $rot;
    $island->{'sci'}      = $sci;
    $island->{'sba'}      = $sba;
    $island->{'pro'}      = $pro;
    $island->{'kin'}      = $kin;
    $island->{'nto'}      = $nto;
    $island->{'m26'}      = $m26;
    $island->{'m27'}      = $m27;
    $island->{'m17'}      = $m17;
    $island->{'c11'}      = $c11;
    $island->{'c13'}      = $c13;
    $island->{'c21'}      = $c21;
    $island->{'c28'}      = $c28;
    $island->{'c23'}      = $c23;
    $island->{'co0'}      = $co0;
    $island->{'co1'}      = $co1;
    $island->{'co01'}      = $co01;
    $island->{'co2'}      = $co2;
    $island->{'co3'}      = $co3;
    $island->{'co4'}      = $co4;
    $island->{'co5'}      = $co5;
    $island->{'co6'}      = $co6;
    $island->{'co7'}      = $co7;
    $island->{'co8'}      = $co8;
    $island->{'co99'}      = $co99;
    $island->{'co77'}      = $co77;
    $island->{'co78'}      = $co78;
    $island->{'co79'}      = $co79;
    $island->{'co80'}      = $co80;
    $island->{'yaku'}      = $yaku;
    $island->{'tet'}      = $tet;
    $island->{'hot'}      = $hot;
    $island->{'hou'}      = $hou;
    $island->{'tai'}      = $tai;
    $island->{'shu'}      = $shu;
    $island->{'sin'}      = $sin;
    $island->{'jin'}      = $jin;
    $island->{'m96'}      = $m96;
    $island->{'m97'}      = $m97;
    $island->{'m98'}      = $m98;
    $island->{'m99'}      = $m99;
    $island->{'m100'}      = $m100;
    $island->{'m101'}      = $m101;
    $island->{'m74'}      = $m74;
    $island->{'m75'}      = $m75;
    $island->{'m76'}      = $m76;
    $island->{'m77'}      = $m77;
    $island->{'m78'}      = $m78;
    $island->{'m79'}      = $m79;
    $island->{'m84'}      = $m84;
    $island->{'m93'}      = $m93;
    $island->{'m73'}      = $m73;
    $island->{'h10'}      = $h10;
    $island->{'h11'}      = $h11;
    $island->{'gyo'}      = $gyo;
    $island->{'htf'}      = $htf;
    $island->{'shtf'}      = $shtf;
    $island->{'ownf'}      = $ownf;
    $island->{'tra'}      = $tra;
    $island->{'tra1'}      = $tra1;
    $island->{'tra2'}      = $tra2;
    $island->{'etc0'}      = $tra+int($island->{'trainmoney'}/1000)+int($island->{'trainmoney2'}/500);
    $island->{'ownfe'}     = $ownfe;

    $ene = int($ene*(1+$island->{'co8'}/10));
    if($ene < 0) {
	$ene = 0;
    }

    $island->{'shouhi'} += int($pop/200*(100-$s02)/100)+int($factory1/20*(100-$s02)/100)+int($factory2/10*(100-$s02)/100);
    $island->{'shouhi'} += int($island->{'pts'}/300*(100-$s02)/100);
    $island->{'shouhi'} += int($island->{'rena'}/30*(100-$s02)/100);
    $island->{'shouhi'} += int($island->{'rena'}/30*(100-$s02)/100);
    $island->{'sabun'} = $ene-$island->{'shouhi'};
    $island->{'eisei3'}    = "$ene,$island->{'shouhi'},$island->{'shouhi'},$ene,$ene";

    $island->{'ene'}      = $ene;
    $island->{'con99'}      = $con99;

    if($island->{'pts'} > $HouseLevel9) {
	$enekeisu = 2.5;
    } elsif($island->{'pts'} > $HouseLevel8) {
	$enekeisu = 2.35;
    } elsif($island->{'pts'} > $HouseLevel7) {
	$enekeisu = 2.2;
    } elsif($island->{'pts'} > $HouseLevel6) {
	$enekeisu = 2.15;
    } elsif($island->{'pts'} > $HouseLevel5) {
	$enekeisu = 1.9;
    } elsif($island->{'pts'} > $HouseLevel4) {
	$enekeisu = 1.75;
    } elsif($island->{'pts'} > $HouseLevel3) {
	$enekeisu = 1.6;
    } elsif($island->{'pts'} > $HouseLevel2) {
	$enekeisu = 1.45;
    } elsif($island->{'pts'} > $HouseLevel1) {
	$enekeisu = 1.2;
    } else {
	$enekeisu = 1;
    }

    if($HislandSize < 16) {
	$enekeisu = 1;
    }

    $enepoint = int($ene/(10*$enekeisu));

    $magicf = $m78 + int($m96/2);
    $magici = $m76 + int($m97/2);
    $magica = $m75 + int($m98/2);
    $magicw = $m77 + int($m99/2);
    $magicl = $m79 + int($m100/2);
    $magicd = $m74 + int($m101/2);

    if ($island->{'h10'} > 0) {
    $magicf += 10;
    $magici += 10;
    $magica += 10;
    $magicw += 10;
    $magicd += 10;
    }
    if ($island->{'h11'} > 0) {
    $magicl += 10;
    }
    $island->{'etc9'} = "$co7,$magicf,$magici,$magica,$magicw,$magicl,$magicd";

    if ($island->{'sabun'} > 0) {
	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	    $x = $Hrpx[$i];
	    $y = $Hrpy[$i];
	    $landKind = $land->[$x][$y];
	    $lv = $landValue->[$x][$y];
	    if(($landKind == $HlandConden) && ($lv < 2000)) {

                    $n = int((2000 - $lv) / 2);
                    $n = min(int($n + $n), $island->{'sabun'});
                    $island->{'sabun'} -= $n;
                    $landValue->[$x][$y] += $n;
		if ($value > 2000) {
                    $landValue->[$x][$y] = 2000;
		}

	    }
 	    if(($landKind == $HlandConden2) && ($lv < 4000)) {

                    $n = int((4000 - $lv) / 10);
                    $n = min(int($n*9 + rand($n)), $island->{'sabun'});
                    $island->{'sabun'} -= $n;
                    $landValue->[$x][$y] += $n;
		if ($value > 4000) {
                    $landValue->[$x][$y] = 4000;
		}

	    }
	    if(($landKind == $HlandConden3) && ($lv < 7000)) {

                    $n = int((7000 - $lv) / 2);
                    $n = min(int($n + $n), $island->{'sabun'});
                    $island->{'sabun'} -= $n/2;
                    $landValue->[$x][$y] += $n/2;
		if ($value > 7000) {
                    $landValue->[$x][$y] = 7000;
		}

	    }

                last if ($island->{'sabun'} <= 0);
	}
    }

    # ���β�Ƚ��
    if($island->{'hou'} == 0) {
	$island->{'eisei1'} = 0;
    }

    # ����Ƚ��
    if($island->{'shu'} == 0) {
	$island->{'totoyoso2'} = 555;
    } elsif($island->{'totoyoso2'} == 555) {
	my($onm);
	$onm = $island->{'onm'};
	$island->{'totoyoso2'} = "$onm���ƥ���";
    }

    # �̻��Ѹ���
    if($island->{'eisei2'} < 0) {
	$island->{'eisei2'} = 0;
    }

    $eisei4 = $island->{'eisei4'};
    $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
    $kachiten = $stwin*3 + $stdrow;
    $island->{'kachiten'} = $kachiten;

    if($island->{'ky2'} == 0) {
	$island->{'eisei4'} = "$sto,$std,$stk,0,0,0,$stwint,$stdrowt,$stloset,$styusho,0";
    }


    if(($island->{'co77'} == 0) || ($island->{'etc5'} == 0)) {
	$island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
    }


    $etc5 = $island->{'etc5'};
    $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

    $island->{'etc5'} = "$co77,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";


    if($island->{'zoo'} == 0) {
	$island->{'etc6'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
    }

    $etc6 = $island->{'etc6'};
    $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($z00,$z01,$z02,$z03,$z04,$z05,$z06,$z07,$z08,$z09,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
    $zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

    $island->{'etc6'} = "$z00,$z01,$z02,$z03,$z04,$z05,$z06,$z07,$z08,$z09,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30";

    $island->{'monsterlive'} = $monslive; # ���ýи���
    $island->{'monsterlivetype'} = $monslivetype; # ���ýи�����
    $monsterlive2 = $monslive + $zookazu;
    $island->{'monsterlive2'} = $monsterlive2; # ���ýи���

    $island->{'kei'} = $kei;
	$eisei5 = $island->{'eisei5'};
	$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
    $island->{'rena'} = $rena + $co2*100 + $co3*500 + $msexe;
    $island->{'fore'} = $fore;
    $island->{'tare'} = $tare;
    $island->{'zipro'} = $zipro;
    $island->{'leje'} = $leje;

    # �ޥ����å�Ƚ��
    if(($island->{'co4'} == 0) &&
	($island->{'co99'} == 0) &&
	($island->{'c28'} == 0)) {
    $island->{'eisei5'} = "0,0,0,0,0,0,0";
    }

    $eisei5 = $island->{'eisei5'};
    $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
    $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

    $island->{'eisei6'} = "$c13,$shu,$m26,$m27,$m74,$m75,$m76,$m77,$m78,$m79,$m84,$m93";

    # ���ȼԿ�
    $island->{'unemployed'} = $pop - ($farm + $factory1 + $factory2 + $mountain) * 10;


    my($eiseip1) = (0);
    my($eiseip2) = (0);
    my($eiseip3) = (0);
    my($eiseip4) = (0);
    my($eiseip5) = (0);
    my($eiseip6) = (0);


    if($island->{'eis1'} >= 1) {
	$eiseip1 = 100 + $island->{'eis1'}*2;
    }
    if($island->{'eis2'} >= 1) {
	$eiseip2 = 300 + $island->{'eis2'}*2;
    }
    if($island->{'eis3'} >= 1) {
	$eiseip3 = 500 + $island->{'eis3'}*2;
    }
    if($island->{'eis4'} >= 1) {
	$eiseip4 = 900 + $island->{'eis4'}*2;
    }
    if($island->{'eis5'} >= 1) {
	$eiseip5 = 1500 + $island->{'eis5'}*2;
    }
    if($island->{'eis6'} >= 1) {
	$eiseip6 = 2000 + $island->{'eis6'}*2;
    }


    $etc8 = $island->{'etc8'};
    $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
    $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

    $totoyoso2 = $island->{'totoyoso2'};
    $island->{'totoyoso2'} = "$totoyoso2";
    $totoyoso = $island->{'totoyoso'};
    $island->{'totoyoso'} = "$totoyoso";

    $auc1 = $island->{'auc1'};
    $island->{'auc1'} = "$auc1";
    $auc2 = $island->{'auc2'};
    $island->{'auc2'} = "$auc2";
    $auc3 = $island->{'auc3'};
    $island->{'auc3'} = "$auc3";

    $auc4 = $island->{'auc4'};
    $auc4 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
    ($auc4a, $auc4b, $auc4c) = ($1, $2, $3);
    $island->{'auc4'} = "$auc4a,$auc4b,$auc4c";

    $auc0 = $island->{'auc0'};
    $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
    $island->{'auc0'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc0e";
    $island->{'auc0c'} = $auc0c;

    $auc5 = $island->{'auc5'};
    $auc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($auc5a, $auc5b, $auc5c, $auc5d, $auc5e) = ($1, $2, $3, $4, $5);
    $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
    $island->{'auc5c'} = $auc5c;

    $auc6 = $island->{'auc6'};
    $auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
    ($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
    $island->{'auc6'} = "$auc6a,$auc6x,$auc6y";

    if($auc6a == 1) {
	$oyasumiritu++;
    }

    $auc7 = $island->{'auc7'};
    $island->{'auc7'} = $auc7;
    $auc8 = $island->{'auc8'};
    $island->{'auc8'} = $auc8;

    $auc9 = $island->{'auc9'};
    $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

    $auc9c2 = int($auc9c/10000);

    $auc9b = $co95*25+$choki2;

    $auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;

    $island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";

    $auc0es = (11-$auc0e)*500;
    if($auc0c == 0) {
	$auc0es = 0;
    }
    if($auc0es < 0) {
	$auc0es = 0;
    }


    if($AnkeitoOnOff == 0) {
	$island->{'anflag'} = 0;
    }


    $etc5 = $island->{'etc5'};
    $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
    ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

    $s12b = int($s12/5)+1;
    if($s12b > 10) {$s12b = 10;}

    if($island->{'money'} > 999999*$s12b) {
	$moneypts = 9999*$s12b + (($island->{'money'}-999999*$s12b)/100)**0.75;
    } else {
	$moneypts = $island->{'money'}/100;
    }

    # ����Point
    $island->{'pts'} = int($pop + $moneypts + $island->{'food'}/100 + ($farm*2 + $factory1 + $factory2*2 + $mountain*2) + $bas + $area*5 + int($fore/15) + $sci*30 + $pro*20 + $sba*10 + $amu*10 + $oil*500 + $kin*500 + $m26*500 + $m27*500 + $m74*750 + $m75*750 + $m76*750 + $m77*750 + $m78*750 + $m79*750 + $m93*2000 + int($tare/15) + int($zipro/12) + int($leje/10) + int($island->{'rena'}/10) + $eiseip1 + $eiseip2 + $eiseip3 + $eiseip4 + $eiseip5 + $eiseip6 + $hou*500 + $enepoint + $tra1*150 + $tra2*150 + $auc0es);

	$eisei4 = $island->{'eisei4'};
	$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
	$kachiten = $stwin*3 + $stdrow;
	$kachitent = $stwint*3 + $stdrowt;
	$siaisu = $stwint + $stdrowt + $stloset;
	if($siaisu == 0) {
	    $siaisu = 1;
	}
	$shoritu = int($stwint / $siaisu * 100);
	$teamforce = $sto + $std + $stk;

	$island->{'kachitent'} = $kachitent;
	$island->{'shoritu'} = $shoritu;
	$island->{'styusho'} = $styusho;
	$island->{'teamforce'} = $teamforce;

	$eisei5 = $island->{'eisei5'};
	$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
	$force = $mshp+$msap+$msdp+$mssp;
	$island->{'force'} = $force;

	$eisei6 = $island->{'eisei6'};
	$eisei6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($unimika, $unishuto, $unimeka, $unioumu, $unianseki, $unitiseki, $unihyouseki, $unifuseki, $unienseki, $unikouseki, $uniiseki, $uniden) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12);

	$unimika3 = ($unimika == 0) ? "0" : "1";
	$unishuto3 = ($unishuto == 0) ? "0" : "1";
	$unimeka3 = ($unimeka == 0) ? "0" : "1";
	$unioumu3 = ($unioumu == 0) ? "0" : "1";
	$unianseki3 = ($unianseki == 0) ? "0" : "1";
	$unitiseki3 = ($unitiseki == 0) ? "0" : "1";
	$unihyouseki3 = ($unihyouseki == 0) ? "0" : "1";
	$unifuseki3 = ($unifuseki == 0) ? "0" : "1";
	$unienseki3 = ($unienseki == 0) ? "0" : "1";
	$unikouseki3 = ($unikouseki == 0) ? "0" : "1";
	$uniiseki3 = ($uniiseki == 0) ? "0" : "1";
	$uniden3 = ($uniden == 0) ? "0" : "1";

	$tuni = $unimika+$unishuto+$unimeka+$unioumu+$unianseki+$unitiseki+$unihyouseki+$unifuseki+$unienseki+$unikouseki+$uniiseki+$uniden;
	$uni = $unimika3+$unishuto3+$unimeka3+$unioumu3+$unianseki3+$unitiseki3+$unihyouseki3+$unifuseki3+$unienseki3+$unikouseki3+$uniiseki3+$uniden3;
	$island->{'uni'} = $uni;
	$island->{'tuni'} = $tuni;

    $island->{'pts'} += $island->{'bumon'}*100*$HislandNumber;

    if($anothermood == 1) {
    $island->{'money'} += $island->{'bumon'}*100*$HislandNumber + $auc0es;
    $island->{'pts'} = $island->{'money'}+$island->{'incomemoney'};
    }


    if($island->{'hou'} > 0) {
	    my($x, $y, $i);
	    for($i = 0; $i < $HpointNumber; $i++) {
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		my($landKind) = $land->[$x][$y];
		my($lv) = $landValue->[$x][$y];

			if($landKind == $HlandHouse) {
				$etc8 = $island->{'etc8'};
				$etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);

			        if(($island->{'pts'} > $HouseLevel9) && ($island->{'m75'} > 0) && ($island->{'m76'} > 0) && ($island->{'m77'} > 0) && ($island->{'m78'} > 0) && ($island->{'c13'} > 0) && ($island->{'shu'} > 0) && ($island->{'m26'} > 0) && ($island->{'m27'} > 0) && ($island->{'m84'} > 0) && ($toto2 > 0)) {
					if(($island->{'m74'} > 0) || ($island->{'m79'} > 0)) {
					$landValue->[$x][$y] = 11;
						if($island->{'m74'} >= $island->{'m79'}) {
						$landValue->[$x][$y] = 10;
						}
					}
			        } elsif($island->{'pts'} > $HouseLevel9) {
			 	    $landValue->[$x][$y] = 9;
			        } elsif($island->{'pts'} > $HouseLevel8) {
			 	    $landValue->[$x][$y] = 8;
			        } elsif($island->{'pts'} > $HouseLevel7) {
				    $landValue->[$x][$y] = 7;
			        } elsif($island->{'pts'} > $HouseLevel6) {
			 	    $landValue->[$x][$y] = 6;
			        } elsif($island->{'pts'} > $HouseLevel5) {
				    $landValue->[$x][$y] = 5;
			        } elsif($island->{'pts'} > $HouseLevel4) {
			 	    $landValue->[$x][$y] = 4;
			        } elsif($island->{'pts'} > $HouseLevel3) {
				    $landValue->[$x][$y] = 3;
			        } elsif($island->{'pts'} > $HouseLevel2) {
			 	    $landValue->[$x][$y] = 2;
			        } elsif($island->{'pts'} > $HouseLevel1) {
				    $landValue->[$x][$y] = 1;
			        } else {
				    $landValue->[$x][$y] = 0;
			        }
			}
		}
	}


	# ����Ƚ��2
	if($island->{'dead'} == 1) {
	    $island->{'pop'} = 0;
	    $island->{'pts'} = 0;
	} elsif($island->{'pop'} == 0) {
	    $island->{'dead'} = 1;
	    $island->{'pts'} = 0;
	}

}


# �ϰ�����Ϸ��������
sub countAround {
    my($land, $x, $y, $kind, $range) = @_;
    my($i, $count, $sx, $sy);
    $count = 0;
    for($i = 0; $i < $range; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # �Ԥˤ�����Ĵ��
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	     $sx--;
	 }

	 if(($sx < 0) || ($sx >= $HislandSize) ||
	    ($sy < 0) || ($sy >= $HislandSize)) {
	     # �ϰϳ��ξ��
	     if($kind == $HlandSea) {
		 # ���ʤ�û�
		 $count++;
	     }
	 } else {
	     # �ϰ���ξ��
	     if($land->[$sx][$sy] == $kind) {
		 $count++;
	     }
	 }
    }
    return $count;
}
# �ϰ�����Ϸ��������
sub countAround {
    my($land, $x, $y, $kind, $range) = @_;
    my($i, $count, $sx, $sy);
    $count = 0;
    for($i = 0; $i < $range; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # �Ԥˤ�����Ĵ��
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	     $sx--;
	 }

	 if(($sx < 0) || ($sx >= $HislandSize) ||
	    ($sy < 0) || ($sy >= $HislandSize)) {
	     # �ϰϳ��ξ��
	     if($kind == $HlandSea) {
		 # ���ʤ�û�
		 $count++;
	     }
	 } else {
	     # �ϰ���ξ��
	     if($land->[$sx][$sy] == $kind) {
		 $count++;
	     }
	 }
    }
    return $count;
}

# 0����(n - 1)�ޤǤο��������ŤĽФƤ���������
sub randomArray {
    my($n) = @_;
    my(@list, $i);

    # �����
    if($n == 0) {
	$n = 1;
    }
    @list = (0..$n-1);

    # ����åե�
    for ($i = $n; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; };
	@list[$i,$j] = @list[$j,$i];
    }

    return @list;
}

# ̾���ѹ�����
sub tempChangeNothing {
    out(<<END);
${HtagBig_}̾�����ѥ���ɤȤ�˶���Ǥ�${H_tagBig}$HtempBack
END
}

# ̾���ѹ����­�ꤺ
sub tempChangeNoMoney {
    out(<<END);
${HtagBig_}�����­�Τ����ѹ��Ǥ��ޤ���${H_tagBig}$HtempBack
END
}

# ̾���ѹ�����
sub tempChange {
    out(<<END);
${HtagBig_}�ѹ���λ���ޤ���${H_tagBig}$HtempBack
END
}

# ���ȼԤ��ǥ�
sub logUnemployedDemo {
    my($id, $name, $pop) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�ǻŻ������<B>$pop${HunitPop}</B>���ǥ�Կʤ�Ԥ��ޤ�����",$id);
}

# ���ȼԤ�˽ư
sub logUnemployedRiot {
    my($id, $name, $lName, $pop, $point) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�ǻŻ������<B>$pop${HunitPop}</B>��˽ư�򵯤�����${HtagName_}$point${H_tagName}������<B>$lName</B>��<B>����</B>��<B>$lName</B>�ϲ��Ǥ��ޤ�����",$id);
}

# ���ȼԤ���̱
sub logUnemployedMigrate {
    my($id, $tId, $name, $tName, $pop) = @_;
    logOut("${HtagName_}${name}��${H_tagName}����${HtagName_}${tName}��${H_tagName}�ػŻ������<B>$pop${HunitPop}</B>�ΰ�̱�����夷�ޤ�����${HtagName_}${tName}��${H_tagName}�ϲ����������줿�褦�Ǥ���",$id, $tId);
}

# �Ѹ����꤬�Ȥ��������ޤ�
sub logKankouMigrate {
    my($id, $tId, $name, $lName, $tName, $point, $pop) = @_;
    logOut("${HtagName_}${tName}��${H_tagName}����${HtagName_}${name}��$point${H_tagName}��<B>$lName</B>��<B>$pop${HunitPop}</B>�δѸ��Ԥ���Ƥ���ޤ��������꤬�Ȥ��������ޤ���",$id, $tId);
}

# ���ȼԤ���̱
sub logUnemployedMigrate2 {
    my($id, $tId, $name, $tName, $pop) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�Υ꥾���Ȼ��ߤ�̥����­�ˤ�ꡢ${HtagName_}${tName}��${H_tagName}��<B>$pop${HunitPop}</B>�δѸ��Ԥ��ܤ�ޤ�����",$id, $tId);
}

# ���ȼԤ���̱
sub logUnemployedMigrate3 {
    my($id, $tId, $name, $tName, $pop) = @_;
    logOut("${HtagName_}${name}��${H_tagName}�Υ꥾���Ȼ��ߤ�̥����­�ˤ�ꡢ${HtagName_}${tName}��${H_tagName}��<B>$pop${HunitPop}</B>�δѸ��Ԥ����äƤ��ޤ�������������ʤ�����",$id, $tId);
}

# ��̱���䡼��
sub logUnemployedReturn {
    my($id, $tId, $name, $lName, $tName, $pop) = @_;
    logOut("${HtagName_}${name}��${H_tagName}����${HtagName_}${tName}��${H_tagName}�ػŻ������<B>$pop${HunitPop}</B>�ΰ�̱�����夷�ޤ�������${HtagName_}${tName}��${H_tagName}��<B>$lName</B>�ϼ����������ݤ����褦�Ǥ���",$id, $tId);
}

# ��̱���䡼��
sub logUnemployedReturn2 {
    my($id, $tId, $name, $lName, $tName, $pop) = @_;
    logOut("${HtagName_}${name}��${H_tagName}��˰����<B>$pop${HunitPop}</B>�δѸ��Ԥ�${HtagName_}${tName}��${H_tagName}�شѸ��ˤ��ޤ�����������${HtagName_}${tName}��${H_tagName}��<B>$lName</B>�ϼ����������ݤ����褦�Ǥ���",$id, $tId);
}

1;
